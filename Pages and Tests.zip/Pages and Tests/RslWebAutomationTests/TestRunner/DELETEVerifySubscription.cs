﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RslWebAutomation;
using RslWebAutomation.PageActions;

namespace RslWebAutomationTests.TestRunner
{
    /// <summary>
    /// Summary description for VerifySubscription
    /// </summary>
    [TestClass]
    public class DELETEVerifySubscription
    {


        [TestInitialize]
        public void MyAccountBrowserInit()
        {

            Driver.Initialize();

            MyAccountPage.OpenPreviewMyAccountPage();


        }

        [TestMethod]
        public void updateNewSubSc()
        {

            String NewSubSc = "$50";

            SignInPage.SigningIn("test", "password");

            SignInPage.Button("Sign in");

            MyAccountPage.navigation("subscription");

            MyAccountPage.SelectSubscription(NewSubSc);

            Driver.Wait(TimeSpan.FromSeconds(1));

            MyAccountPage.UpdateBtn("subscription");

            Driver.Wait(TimeSpan.FromSeconds(1));

            MyAccountPage.alertUpdatedBox();

            Driver.Wait(TimeSpan.FromSeconds(1));

            MyAccountPage.navigation("subscription");

            Console.WriteLine(MyAccountPage.validateSelectedSubSc(NewSubSc));

            Driver.Close();


        }
    }
}
