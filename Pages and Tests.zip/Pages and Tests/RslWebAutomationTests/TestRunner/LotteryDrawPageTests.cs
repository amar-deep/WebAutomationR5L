﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RslWebAutomation;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.Events;
using OpenQA.Selenium.Support;
using RslWebAutomation.Utility;


namespace RslWebAutomationTests.TestRunner
{
    [TestClass]
    public class LotteryDrawPageTests
    {
        //IWebDriver Instance = null;
        public LotteryDrawPageGallery GalleryPageObject;

       // The below code is used for runsettings
       // private static TestContext testContextInstance;

        //public TestContext TestContext
        //{
        //    get { return testContextInstance; }
        //    set { testContextInstance = value; }
        //}


        public string browsernamevalue = "chrome";

    

        [TestInitialize]
        public void LotteryDrawPageIntializeBrowser()
        {
            
            //string browserType = TestContext.Properties["webBrowserType"].ToString();
            //Console.WriteLine("BrowserType is " + browserType);

            Driver.Initialize();
            LotteryDrawPageGallery.OpenSapientPreviewPage();
            LotteryDrawPageGallery.OpenLotteryDrawPage();
            LotteryDrawPageGallery.OpenGallerySection();
            Driver.Instance.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(20);
        }

        //[]
        //public void SetPreCondition(TestContext tc)
        //{


        //}
        /*
        [TestMethod]
        public void VerifyLoadGalleryComponent()
        {
            bool status = LotteryDrawPageGallery.OpenGallerySection();
            Console.WriteLine("value of status is " + status);
            Assert.AreEqual(status, true);
            Console.WriteLine("First preview page test");

        }

        [TestMethod]
        public void VerifyRightArrow()
        {
            bool arrowVisibleStatus = LotteryDrawPageGallery.ClickRightArrow();
            Assert.AreEqual(arrowVisibleStatus, true);
            Console.WriteLine("RightArrow button is visible and working");
        }

        [TestMethod]
        public void VerifyPhotoGallery()
        {

            bool photoGalleryStatus = LotteryDrawPageGallery.ClickPhotoGallery();
            Console.WriteLine("PhotoGallery button is visible and working");
            Console.WriteLine("PhotogalleryStatus is  : " + photoGalleryStatus);
            Assert.IsTrue(photoGalleryStatus);
        }

        [TestMethod]
        public void VerifyVideoGallery()
        {
            bool status = LotteryDrawPageGallery.ClickVideoGallery();
            Console.WriteLine("VideoGallery button is visible and working");
            Assert.IsTrue(status);
        }

        [TestMethod]
        public void VerifyVirtualTourGallery()
        {
            bool virtualGalleryStatus = LotteryDrawPageGallery.ClickVitualTourGallery();
            Console.WriteLine("Virtual Tour Gallery button is visible and working");
            Assert.IsTrue(virtualGalleryStatus);
        }

        [TestMethod]
        public void VerifyFloorPlanGallery()
        {
            bool floorplanGalleryStatus = LotteryDrawPageGallery.ClickFloorPlanGallery();
            Console.WriteLine("Floor Plan Gallery button is visible and working");
            Assert.IsTrue(floorplanGalleryStatus);
        }

    */

        [TestCleanup]
        public void Cleanup()
        {
            //Driver.Instance.Quit();
            Driver.Close();

        }
    }
}
