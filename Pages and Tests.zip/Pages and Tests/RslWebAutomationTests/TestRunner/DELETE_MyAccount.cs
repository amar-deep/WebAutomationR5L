﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RslWebAutomation;
using RslWebAutomation.PageActions;

namespace RslWebAutomationTests.TestRunner
{
    /// <summary>
    /// Summary description for MyAccount
    /// </summary>
    [TestClass]
    public class DELETE_MyAccount
    {

        [TestInitialize]
        public void MyAccountBrowserInit()
        {

            Driver.Initialize();
            MyAccountPage.OpenPreviewMyAccountPage();

            
        }

        [TestMethod]
        public void MyAccountNavigationMenu()
        {

            SignInPage.SigningIn("test", "test@gmail.com");

            SignInPage.Button("Sign in");

            MyAccountPage.navigation("overview");

            MyAccountPage.navigation("my details");

            MyAccountPage.navigation("payment method");

            MyAccountPage.navigation("password");

            MyAccountPage.navigation("subscription");

            MyAccountPage.navigation("order history");

            MyAccountPage.navigation("sign out");


        }


        


    }
}
