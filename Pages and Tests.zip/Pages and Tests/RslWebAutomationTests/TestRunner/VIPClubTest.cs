﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RslWebAutomation;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.Events;
using OpenQA.Selenium.Support;
using RslWebAutomation.Utility;
using RslWebAutomation.PageActions;
using System.Collections.Generic;

namespace RslWebAutomationTests.TestRunner
{
    [TestClass]
    public class VIPClubTest : WebsiteTest
    {

        [ClassInitialize]
        public static void VIPClassInit(TestContext context)
        {
        }

        [TestInitialize]
        public void vipInit()
        {
            TestData.CreateTestDrawData();
            TestData.CreateNewCustomerData();
            TestData.CreateCreditCardData();
            TestData.CreateExistingCustomerData();
        }

        [TestMethod]
        [TestCategory("Navigate")]
        public void TestNavigation()
        {
            //This test case can be moved to other generic scenarios like navigation checks and links check on page
            JoinVIPPage.NavigateAllPages();            
        }

        // Join VIP Club for new customer   ----1-----
        [TestMethod]
        [TestCategory("Smoke"), TestCategory("VIP"), TestCategory("Visa")]
        public void New_Customer_Visa()
        {
            //*************************    Test Data   ******************************************            
            string pay_method = "v";            
            //Declare which subscription to select
            string subscription = "50";            
            //***********************************************************************************

            //Buy tickets as new customer
            FunctionLibrary.Join_VIP_Club_NewCustomer(subscription, pay_method, TestContext.TestName);
            //Verify payment method stored in my account
            TopNavigation.SelectSubMenu("Hi", "Your Details");
            //MyAccountPage.ValidateStoredPaymentMethod(pay_method, stored_payment);
            //Buy tickets as existing customer already logged in
            //FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        // Join VIP Club for existing customer with storedPayment   ----2-----
        [TestMethod]
        [TestCategory("VIP"), TestCategory("Visa")]
        public void Existing_Customer_Remember_Payment_Visa()
        {
            //First step:  Create new Customer with remember payment details yes
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = false;
            bool is_gift_details_section = false;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "v";
            //Declare which subscription to select
            string subscription = "50";
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "5");
            tickets_to_book.Add(TestData.draws_preorder[0], "100");
            //***********************************************************************************

            //Buy tickets as new customer
            FunctionLibrary.BuyTicktes_NewCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, pay_method, TestContext.TestName);

            //Second step: Join VIP Club as existing Customer           
            FunctionLibrary.Join_VIP_Club_ExistingCustomer(subscription, pay_method,stored_payment, TestContext.TestName);
            //Verify payment method stored in my account
            TopNavigation.SelectSubMenu("Hi", "Your Details");            
        }

        // Join VIP Club for existing customer with storedPayment   ----3-----
        [TestMethod]
        [TestCategory("VIP"), TestCategory("Visa")]
        public void Existing_Customer_Dont_Remember_Payment_Visa()
        {
            //First step:  Create new Customer with remember payment details yes
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = false;
            bool is_gift_details_section = false;
            bool remember_payment_details = false;
            bool stored_payment = false;
            string pay_method = "v";
            //Declare which subscription to select
            string subscription = "100";
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "5");
            tickets_to_book.Add(TestData.draws_preorder[0], "100");
            //***********************************************************************************

            //Buy tickets as new customer
            FunctionLibrary.BuyTicktes_NewCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, pay_method, TestContext.TestName);

            //Second step: Join VIP Club as existing Customer                        
            FunctionLibrary.Join_VIP_Club_ExistingCustomer(subscription, pay_method, stored_payment, TestContext.TestName);
            //Verify payment method stored in my account
            TopNavigation.SelectSubMenu("Hi", "Your Details");            
        }

        // Join VIP Club for existing customer with storedPayment   ----2-----
        [TestMethod]
        [TestCategory("VIP"), TestCategory("Master")]
        public void Existing_Customer_Remember_Payment_Master()
        {
            //First step:  Create new Customer with remember payment details yes
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = false;
            bool is_gift_details_section = false;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "m";
            //Declare which subscription to select
            string subscription = "50";

            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "5");
            tickets_to_book.Add(TestData.draws_preorder[0], "100");
            //***********************************************************************************

            //Buy tickets as new customer
            FunctionLibrary.BuyTicktes_NewCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, pay_method, TestContext.TestName);

            //Second step: Join VIP Club as existing Customer           
            FunctionLibrary.Join_VIP_Club_ExistingCustomer(subscription, pay_method, stored_payment, TestContext.TestName);
            //Verify payment method stored in my account
            TopNavigation.SelectSubMenu("Hi", "Your Details");
        }

        // Join VIP Club for existing customer with storedPayment   ----3-----
        [TestMethod]
        [TestCategory("VIP"), TestCategory("Paypal")]

        public void Existing_Customer_Dont_Remember_Payment_Paypal()
        {
            //First step:  Create new Customer with remember payment details yes
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = false;
            bool is_gift_details_section = false;
            bool remember_payment_details = false;
            bool stored_payment = false;
            string pay_method = "p";
            //Declare which subscription to select
            string subscription = "100";

            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "5");
            tickets_to_book.Add(TestData.draws_preorder[0], "100");
            //***********************************************************************************

            //Buy tickets as new customer
            FunctionLibrary.BuyTicktes_NewCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, pay_method, TestContext.TestName);

            //Second step: Join VIP Club as existing Customer                        
            FunctionLibrary.Join_VIP_Club_ExistingCustomer(subscription, pay_method, stored_payment, TestContext.TestName);
            //Verify payment method stored in my account
            TopNavigation.SelectSubMenu("Hi", "Your Details");
        }


        //**********************************************************


        [TestCleanup]
        public void TestCleanup()
        {
            Console.WriteLine("   Entered Test Cleanup");
            Console.WriteLine(TestContext.CurrentTestOutcome);
            if (TestContext.CurrentTestOutcome == UnitTestOutcome.Failed)
            {
                Console.WriteLine("   Entered if statement");
                FunctionLibrary.ScreenGrab(TestContext.TestName);

            }
            Console.WriteLine("   Finished Test Cleanup");
        }

        //***********************************************************************



        /*

        [TestMethod]
        public void JoinVIPClubNewCustAmexCredit()
        {
            //Once the test env is ready uncomment this line and take out the prototype
            //JoinVIPPage.Goto();

            //for the time being opening the prototype page
            LotteryDrawPageGallery.OpenSapientPreviewPage();
            Driver.Instance.Navigate().GoToUrl("http://preview.sapientnitro.com.au/rsl/checkout-vip.html");
            
            //select Subscription date
            //To pass the draw date
            JoinVIPPage.SelectSubscription(2);

            //Select the ticket value
            //TestData.orderDetails["Value"] = "$30";
            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$50";            

            bool firstOrderStatus = JoinVIPPage.SelectOrder(TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            Driver.Wait(TimeSpan.FromSeconds(10));

            //Validate the amount per draw is populated on the top .
            Assert.IsTrue(firstOrderStatus, "The Subscription amount selected and the amount shown are different");

            //Click on Join Now button
            JoinVIPPage.Click_JoinNow();
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Select Customer New or Existing
            //CheckoutPage.FeedNewCustomerDetails("Test1", "test@testemail.com");
            CheckoutPage.FeedNewCustomerNameAndEmail();
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Select Payment method Amex Credit card
            //CheckoutPage.CreditCardPaymentMethod("111122223333", "02/23", "RSLTestCreditCard");
            CheckoutPage.EnterPaymentDetails_CreditCard(TestData.CreditCardNumber[TestData.CreditCardNumbersKey.AmexCard], false);

            //Enter customer details
            //CheckoutPage.CustomerContactDetails("test", "lastname", "testemail@rsl.org", false);
            CheckoutPage.FeedNewCustomerContactDetails(false,false);
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Order Summary validation        
           
            string orderSummaryValue = CheckoutPage.VipOrderSummaryValue();
            string orderSummaryDrawDate = CheckoutPage.VipOrderSummaryDate();

            StringAssert.Contains(orderSummaryValue,TestData.orderDetails[TestData.OrderDetailsKey.TicketValue], "The ticket value in the summary page is  different to what it is selected" );
            StringAssert.Contains(orderSummaryDrawDate,TestData.orderDetails[TestData.OrderDetailsKey.DrawDate], "The ticket value in the summary page is different to what it is selected");
            
            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
            Assert.IsTrue(confirmOrderStatus);
            
            //Validate the order confirmation page
            string vipOrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();
            StringAssert.Contains(vipOrderConfirmationMessage,TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected " );      
        }


        [TestMethod]
        public void JoinVIPClubNewCustMasterCreditGift()
        {
            //Once the test env is ready uncomment this line and take out the prototype
            //JoinVIPPage.Goto();

            //for the time being opening the prototype page
            LotteryDrawPageGallery.OpenSapientPreviewPage();
            Driver.Instance.Navigate().GoToUrl("http://preview.sapientnitro.com.au/rsl/checkout-vip.html");

            //select Subscription date
            //To pass the draw date
            JoinVIPPage.SelectSubscription(2);

            //Select the ticket value
            //TestData.orderDetails["Value"] = "$30";
            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$30";

            bool firstOrderStatus = JoinVIPPage.SelectOrder(TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            Driver.Wait(TimeSpan.FromSeconds(10));

            //Validate the amount per draw is populated on the top .
            Assert.IsTrue(firstOrderStatus, "The Subscription amount selected and the amount shown are different");

            //Click on Join Now button
            JoinVIPPage.Click_JoinNow();
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Select Customer New Customer
            CheckoutPage.FeedNewCustomerNameAndEmail();
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Select Payment method
            CheckoutPage.EnterPaymentDetails_CreditCard(TestData.CreditCardNumber[TestData.CreditCardNumbersKey.MasterCard], false);

            //Enter customer details
            CheckoutPage.FeedNewCustomerContactDetails(true,true);
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Order Summary validation       

            string orderSummaryValue = CheckoutPage.VipOrderSummaryValue();
            string orderSummaryDrawDate = CheckoutPage.VipOrderSummaryDate();

            
            StringAssert.Contains(orderSummaryValue, TestData.orderDetails[TestData.OrderDetailsKey.TicketValue], "The ticket value in the summary page is  different to what it is selected");
            StringAssert.Contains(orderSummaryDrawDate, TestData.orderDetails[TestData.OrderDetailsKey.DrawDate], "The ticket value in the summary page is different to what it is selected");

            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
            Assert.IsTrue(confirmOrderStatus);

            //Validate the order confirmation page
            string vipOrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();
            StringAssert.Contains(vipOrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");            
        }

        [TestMethod]
        public void JoinVIPClubExistCustDefaultPay()
        {
            //Once the test env is ready uncomment this line and take out the prototype
            //JoinVIPPage.Goto();

            //for the time being opening the prototype page
            LotteryDrawPageGallery.OpenSapientPreviewPage();
            Driver.Instance.Navigate().GoToUrl("http://preview.sapientnitro.com.au/rsl/checkout-vip.html");

            //select Subscription date
            //To pass the draw date
            JoinVIPPage.SelectSubscription(2);

            //Select the ticket value
            //TestData.orderDetails["Value"] = "$30";
            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$500";

            bool firstOrderStatus = JoinVIPPage.SelectOrder(TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Validate the amount per draw is populated on the top .
            Assert.IsTrue(firstOrderStatus, "The Subscription amount selected and the amount shown are different");

            //Click on Join Now button
            JoinVIPPage.Click_JoinNow();
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Select Existing Customer 

            CheckoutPage.FeedExistCustomerDetails();
            Driver.Wait(TimeSpan.FromSeconds(3));

           //Order Summary validation        

            string orderSummaryValue = CheckoutPage.VipOrderSummaryValue();
            string orderSummaryDrawDate = CheckoutPage.VipOrderSummaryDate();

            StringAssert.Contains(orderSummaryValue, TestData.orderDetails[TestData.OrderDetailsKey.TicketValue], "The ticket value in the summary page is  different to what it is selected");
            StringAssert.Contains(orderSummaryDrawDate, TestData.orderDetails[TestData.OrderDetailsKey.DrawDate], "The ticket value in the summary page is different to what it is selected");

            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
            Assert.IsTrue(confirmOrderStatus);

            //Validate the order confirmation page
            string vipOrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();
            StringAssert.Contains(vipOrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");

            //Validate in the My Account Subscription            
        }

        [TestMethod]
        public void JoinVIPClubExistCustCredit()
        {
            //Once the test env is ready uncomment this line and take out the prototype
            //JoinVIPPage.Goto();

            //for the time being opening the prototype page
            LotteryDrawPageGallery.OpenSapientPreviewPage();
            Driver.Instance.Navigate().GoToUrl("http://preview.sapientnitro.com.au/rsl/checkout-vip.html");

            //select Subscription date
            //To pass the draw date
            JoinVIPPage.SelectSubscription(2);

            //Select the ticket value
            //TestData.orderDetails["Value"] = "$30";
            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$500";

            bool firstOrderStatus = JoinVIPPage.SelectOrder(TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Validate the amount per draw is populated on the top .
            Assert.IsTrue(firstOrderStatus, "The Subscription amount selected and the amount shown are different");

            //Click on Join Now button
            JoinVIPPage.Click_JoinNow();
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Select Existing Customer 

            CheckoutPage.FeedExistCustomerDetails();
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Modify Payment option to Credit card
            CheckoutPage.ModifyPaymentMethod();
            CheckoutPage.EnterPaymentDetails_CreditCard(TestData.CreditCardNumber[TestData.CreditCardNumbersKey.MasterCard], false);

            //Order Summary validation        

            string orderSummaryValue = CheckoutPage.VipOrderSummaryValue();
            string orderSummaryDrawDate = CheckoutPage.VipOrderSummaryDate();

            StringAssert.Contains(orderSummaryValue, TestData.orderDetails[TestData.OrderDetailsKey.TicketValue], "The ticket value in the summary page is  different to what it is selected");
            StringAssert.Contains(orderSummaryDrawDate, TestData.orderDetails[TestData.OrderDetailsKey.DrawDate], "The ticket value in the summary page is different to what it is selected");

            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
            Assert.IsTrue(confirmOrderStatus);

            //Validate the order confirmation page
            string vipOrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();
            StringAssert.Contains(vipOrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");

            //Validate in the My Account Subscription
        }

        [TestMethod]
        public void JoinVIPClubExistCustModifyDetails()
        {
            //Once the test env is ready uncomment this line and take out the prototype
            //JoinVIPPage.Goto();

            //for the time being opening the prototype page
            LotteryDrawPageGallery.OpenSapientPreviewPage();
            Driver.Instance.Navigate().GoToUrl("http://preview.sapientnitro.com.au/rsl/checkout-vip.html");

            //select Subscription date
            //To pass the draw date
            JoinVIPPage.SelectSubscription(2);

            //Select the ticket value
            //TestData.orderDetails["Value"] = "$30";
            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$500";

            bool firstOrderStatus = JoinVIPPage.SelectOrder(TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Validate the amount per draw is populated on the top .
            Assert.IsTrue(firstOrderStatus, "The Subscription amount selected and the amount shown are different");

            //Click on Join Now button
            JoinVIPPage.Click_JoinNow();
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Select Existing Customer 

            CheckoutPage.FeedExistCustomerDetails();
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Modify Personal Details 
            CheckoutPage.ModifyDetails();
            CheckoutPage.FeedNewCustomerContactDetails(false,false);

            //Order Summary validation        

            string orderSummaryValue = CheckoutPage.VipOrderSummaryValue();
            string orderSummaryDrawDate = CheckoutPage.VipOrderSummaryDate();

            StringAssert.Contains(orderSummaryValue, TestData.orderDetails[TestData.OrderDetailsKey.TicketValue], "The ticket value in the summary page is  different to what it is selected");
            StringAssert.Contains(orderSummaryDrawDate, TestData.orderDetails[TestData.OrderDetailsKey.DrawDate], "The ticket value in the summary page is different to what it is selected");

            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
            Assert.IsTrue(confirmOrderStatus);

            //Validate the order confirmation page
            string vipOrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();
            StringAssert.Contains(vipOrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");

            //Validate in the My Account Subscription
        }


        [TestMethod]
        public void JoinVIPClubFirstDrawNewCustCredit()
        {

            //Once the test env is ready uncomment this line and take out the prototype
            //JoinVIPPage.Goto();

            //for the time being opening the prototype page
            LotteryDrawPageGallery.OpenSapientPreviewPage();
            Driver.Instance.Navigate().GoToUrl("http://preview.sapientnitro.com.au/rsl/checkout-vip.html");

            //select Subscription date
            //To pass the draw date
            JoinVIPPage.SelectSubscription(1);

            //Select the ticket value
            //TestData.orderDetails["Value"] = "$30";
            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$200";

            bool firstOrderStatus = JoinVIPPage.SelectOrder(TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            Driver.Wait(TimeSpan.FromSeconds(5));

            //Validate the amount per draw is populated on the top .
            Assert.IsTrue(firstOrderStatus, "The Subscription amount selected and the amount shown are different");

            //Click on Join Now button
            JoinVIPPage.Click_JoinNow();
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Select Customer New or Existing
            CheckoutPage.FeedNewCustomerNameAndEmail();
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Select Payment method
            CheckoutPage.EnterPaymentDetails_CreditCard(TestData.CreditCardNumber[TestData.CreditCardNumbersKey.VisaCard], false);

            //Enter customer details
            CheckoutPage.FeedNewCustomerContactDetails(false,false);
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Order Summary validation        

            string orderSummaryValue = CheckoutPage.VipOrderSummaryValue();
            string orderSummaryDrawDate = CheckoutPage.VipOrderSummaryDate();

            StringAssert.Contains(orderSummaryValue, TestData.orderDetails[TestData.OrderDetailsKey.TicketValue], "The ticket value in the summary page is  different to what it is selected");
            StringAssert.Contains(orderSummaryDrawDate, TestData.orderDetails[TestData.OrderDetailsKey.DrawDate], "The ticket value in the summary page is different to what it is selected");

            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
            Assert.IsTrue(confirmOrderStatus);

            //Validate the order confirmation page
            string vipOrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();
            StringAssert.Contains(vipOrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");
        }


        [TestMethod]
        public void JoinVIPClubSecondDrawNewCustCreditGift()
        {

            //Once the test env is ready uncomment this line and take out the prototype
            //JoinVIPPage.Goto();

            //for the time being opening the prototype page
            LotteryDrawPageGallery.OpenSapientPreviewPage();
            Driver.Instance.Navigate().GoToUrl("http://preview.sapientnitro.com.au/rsl/checkout-vip.html");

            //select Subscription date
            //To pass the draw date
            JoinVIPPage.SelectSubscription(2);


            //Select the ticket value
            //TestData.orderDetails["Value"] = "$30";
            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$5";


            bool firstOrderStatus = JoinVIPPage.SelectOrder(TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            Driver.Wait(TimeSpan.FromSeconds(5));

            //Validate the amount per draw is populated on the top .
            Assert.IsTrue(firstOrderStatus, "The Subscription amount selected and the amount shown are different");

            //Click on Join Now button
            JoinVIPPage.Click_JoinNow();
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Select Customer New Customer
            CheckoutPage.FeedNewCustomerNameAndEmail();
            Driver.Wait(TimeSpan.FromSeconds(2));

            //Select Payment method
            CheckoutPage.EnterPaymentDetails_CreditCard(TestData.CreditCardNumber[TestData.CreditCardNumbersKey.DinersClubCard], false);

            //Enter customer details
            CheckoutPage.FeedNewCustomerContactDetails(true,true);
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Order Summary validation       

            string orderSummaryValue = CheckoutPage.VipOrderSummaryValue();
            string orderSummaryDrawDate = CheckoutPage.VipOrderSummaryDate();


            StringAssert.Contains(orderSummaryValue, TestData.orderDetails[TestData.OrderDetailsKey.TicketValue], "The ticket value in the summary page is  different to what it is selected");
            StringAssert.Contains(orderSummaryDrawDate, TestData.orderDetails[TestData.OrderDetailsKey.DrawDate], "The ticket value in the summary page is different to what it is selected");

            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
            Assert.IsTrue(confirmOrderStatus);

            //Validate the order confirmation page
            string vipOrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();
            StringAssert.Contains(vipOrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");
        }


        [TestMethod]
        public void JoinVIPClubThirdDrawExistCustCredit()
        {

            //Once the test env is ready uncomment this line and take out the prototype
            //JoinVIPPage.Goto();

            //for the time being opening the prototype page
            LotteryDrawPageGallery.OpenSapientPreviewPage();
            Driver.Instance.Navigate().GoToUrl("http://preview.sapientnitro.com.au/rsl/checkout-vip.html");

            //select Subscription date
            //To pass the draw date
            JoinVIPPage.SelectSubscription(3);

            //Select the ticket value
            //TestData.orderDetails["Value"] = "$30";
            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$10";

            bool firstOrderStatus = JoinVIPPage.SelectOrder(TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Validate the amount per draw is populated on the top .
            Assert.IsTrue(firstOrderStatus, "The Subscription amount selected and the amount shown are different");

            //Click on Join Now button
            JoinVIPPage.Click_JoinNow();
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Select Existing Customer 
            CheckoutPage.FeedExistCustomerDetails();
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Order Summary validation        

            string orderSummaryValue = CheckoutPage.VipOrderSummaryValue();
            string orderSummaryDrawDate = CheckoutPage.VipOrderSummaryDate();

            StringAssert.Contains(orderSummaryValue, TestData.orderDetails[TestData.OrderDetailsKey.TicketValue], "The ticket value in the summary page is  different to what it is selected");
            StringAssert.Contains(orderSummaryDrawDate, TestData.orderDetails[TestData.OrderDetailsKey.DrawDate], "The ticket value in the summary page is different to what it is selected");

            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
            Assert.IsTrue(confirmOrderStatus);

            //Validate the order confirmation page
            string vipOrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();
            StringAssert.Contains(vipOrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");

            //Validate in the My Account Subscription        
        }
        */



    }

}
