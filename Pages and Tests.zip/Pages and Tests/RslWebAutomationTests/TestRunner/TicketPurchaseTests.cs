﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RslWebAutomation;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.Events;
using OpenQA.Selenium.Support;
using RslWebAutomation.Utility;
using RslWebAutomation.PageActions;
using System.Collections.Generic;

namespace RslWebAutomationTests.TestRunner
{
    [TestClass]
    public class TicketPurchaseTests : WebsiteTest
    {
        [ClassInitialize]
        public static void PurchaseClassInit(TestContext context)
        {
        }

        [TestInitialize]
        public void PurchaseInit()
        {                        
        }

        //-----Test Cases which reuse existing ticket book methods in function library----------
        //******************  Visa Test Cases  ************************
        
        //Buy tickets as new customer first not remembering payment details. Validate Payment method in My Account page  ----11-----
        //Buy tickets as same customer then remembering payment details. Validate Payment method in My Account page
        [TestMethod]
        [TestCategory("Smoke"), TestCategory("Visa"), TestCategory("Book")]
        public void New_Customer_Stored_Funding_No_And_Then_Change_Stored_Funding_To_Yes_In_Next_Booking()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = false;
            bool is_gift_details_section = false;
            bool remember_payment_details = false;
            string pay_method = "v";
            //below variables for login are assigned to buy tickets as existing customer in 2nd method
            bool log_in_first = true;
            bool already_logged_in = true;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "5");
            tickets_to_book.Add(TestData.draws_preorder[0], "100");
            //***********************************************************************************

            //Buy tickets as new customer
            FunctionLibrary.BuyTicktes_NewCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, pay_method, TestContext.TestName);
            //stored-payment is set to false as remember payment was not ticked
            bool stored_payment = false;
            //Verify payment method stored in my account
            TopNavigation.SelectSubMenu("Hi", "Your Details");
            MyAccountPage.ValidateStoredPaymentMethod(pay_method, stored_payment);            
            //Buy tickets as existing customer already logged in but this time set remember payment to true
            remember_payment_details = true;
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
            //stored-payment is set to true as remember payment was ticked
            stored_payment = true;
            //Verify payment method stored in my account
            TopNavigation.SelectSubMenu("Hi", "Your Details");
            MyAccountPage.ValidateStoredPaymentMethod(pay_method, stored_payment);
        }

               
        // Buy ticket for new customer, validate payment method and then, create booking as exsisting customer   ----1-----
        [TestMethod]
        [TestCategory("Visa"), TestCategory("Book")]
        public void New_Customer_CurrentDraw_PreOrder_Gift_No_No_Remember_Yes_Visa()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = false;
            bool is_gift_details_section = false;            
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "v";
            //below variables for login are assigned to buy tickets as existing customer in 2nd method
            bool log_in_first = true;
            bool already_logged_in = true;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            //tickets_to_book.Add("355", "50");
            tickets_to_book.Add(TestData.draws_live[0], "50");
            tickets_to_book.Add(TestData.draws_preorder[0], "100");
            //***********************************************************************************

            //Buy tickets as new customer
            FunctionLibrary.BuyTicktes_NewCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, pay_method, TestContext.TestName);
            //Verify payment method stored in my account
            TopNavigation.SelectSubMenu("Hi", "Your Details");            
            MyAccountPage.ValidateStoredPaymentMethod(pay_method, stored_payment);            
            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first,already_logged_in, TestContext.TestName);
        }

        // Buy ticket for new customer, validate payment method and then, create booking as exsisting customer   ----1-----
        [TestMethod]
        [TestCategory("Visa"), TestCategory("Book")]
        public void New_Customer_PreOrderOnly_Gift_Yes_Yes_Remember_No_Visa()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = true;
            bool remember_payment_details = false;
            bool stored_payment = false;
            string pay_method = "v";
            //below variables for login are assigned to buy tickets as existing customer in 2nd method
            bool log_in_first = true;
            bool already_logged_in = true;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            //tickets_to_book.Add(TestData.draws_live[0], "50");
            tickets_to_book.Add(TestData.draws_preorder[0], "100");
            //***********************************************************************************

            //Buy tickets as new customer
            FunctionLibrary.BuyTicktes_NewCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, pay_method, TestContext.TestName);
            //Verify payment method stored in my account
            TopNavigation.SelectSubMenu("Hi", "Your Details");
            MyAccountPage.ValidateStoredPaymentMethod(pay_method, stored_payment);
            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        // Buy ticket for new customer, validate payment method and then, create booking as exsisting customer   ----1-----
        [DataTestMethod]
        [DataRow("v")]
        [DataRow("d")]
        [DataRow("v")]
        [DataRow("d")]
        [TestCategory("Visa"), TestCategory("Book")]
        public void New_Customer_PreOrderOnly_Gift_Yes_Yes_Remember_No(string pay_method)
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = true;
            bool remember_payment_details = false;
            bool stored_payment = false;            
            //below variables for login are assigned to buy tickets as existing customer in 2nd method
            bool log_in_first = true;
            bool already_logged_in = true;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            //tickets_to_book.Add(TestData.draws_live[0], "50");
            tickets_to_book.Add(TestData.draws_preorder[0], "100");
            //***********************************************************************************

            //Buy tickets as new customer
            FunctionLibrary.BuyTicktes_NewCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, pay_method, TestContext.TestName);
            //Verify payment method stored in my account
            TopNavigation.SelectSubMenu("Hi", "Your Details");
            MyAccountPage.ValidateStoredPaymentMethod(pay_method, stored_payment);
            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }
      

        //Login as existing customer first and then book tickets with Visa  ----2-----
        [TestMethod]
        [TestCategory("Visa"), TestCategory("Book")]
        public void Trusted_Login_First_And_Then_Buy_Tickets_Gift_No_No_Remember_Yes_Visa()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = false;
            bool is_gift_details_section = false;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "v";
            bool log_in_first = true;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");
            tickets_to_book.Add(TestData.draws_preorder[0], "50");
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first,already_logged_in, TestContext.TestName);
        }

        //Select Tickets first and then Login as existing customer to book tickets with Visa  ----3-----
        [TestMethod]
        [TestCategory("Visa"), TestCategory("Book")]
        public void Trusted_Click_Buy_Tickets_First_And_Then_Login_Gift_No_No_Remember_Yes_Visa()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = false;
            bool is_gift_details_section = false;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "v";
            bool log_in_first = false;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");
            tickets_to_book.Add(TestData.draws_preorder[0], "100");
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
            Assert.IsNotNull(TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber]);
        }


        //Select Tickets first and then Login as existing customer to book tickets with Visa  ----4-----
        //Select Gift checkbox at homepage, Gift auto-selected at step 3 and remember payment details
        [TestMethod]
        [TestCategory("Visa"), TestCategory("Book")]
        public void Trusted_Click_Buy_Tickets_First_And_Then_Login_Gift_Yes_Yes_Remember_Yes_Visa()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = true;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "v";
            bool log_in_first = false;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");
            tickets_to_book.Add(TestData.draws_preorder[0], "50");
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        //Select Tickets first and then Login as existing customer to book tickets with Visa  ----5-----
        //Select Gift checkbox at homepage, Gift auto-selected at step 3 and dont remember payment details
        [TestMethod]
        [TestCategory("Visa"), TestCategory("Book")]
        public void Trusted_Login_First_And_Then_Buy_Tickets_CurrentDrawOnly_Gift_No_Yes_Remember_No_Visa_26755()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = false;
            bool is_gift_details_section = true;
            bool remember_payment_details = false;
            bool stored_payment = false;
            string pay_method = "v";
            bool log_in_first = true;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "50");
            //tickets_to_book.Add(TestData.draws_preorder[0], "50");
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        //Select Tickets first and then Login as existing customer to book tickets with Visa  ----6-----
        //Select Gift checkbox at homepage, DeSelect gift at step 3 and remember payment details        
        [TestMethod]
        [TestCategory("Visa"), TestCategory("Book")]
        public void Trusted_Login_First_And_Then_Buy_Tickets_Gift_Yes_No_Remember_Yes_Visa()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = false;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "v";
            bool log_in_first = true;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "50");
            tickets_to_book.Add(TestData.draws_preorder[0], "30");
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        //Select Tickets first and then Login as existing customer to book tickets with Visa  ----7-----
        //Select Gift checkbox at homepage, DeSelect gift at step 3 and remember payment details        
        [TestMethod]
        [TestCategory("Visa"), TestCategory("Book")]
        public void Trusted_Click_Buy_Tickets_First_And_Then_Login_Gift_Yes_No_Remember_No_Visa()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = false;
            bool remember_payment_details = false;
            bool stored_payment = false;
            string pay_method = "v";
            bool log_in_first = false;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");
            tickets_to_book.Add(TestData.draws_preorder[0], "50");
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        
       
        //******************  End of Visa Test Cases  ************************


        //******************  MasterCard Test Cases  ************************
        // Buy ticket for new customer   ----1-----
        [TestMethod]
        [TestCategory("Master"), TestCategory("Book")]
        public void New_Customer_CurrentDrawOnly_Gift_No_Yes_Remember_No_Master()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = false;
            bool is_gift_details_section = true;
            bool remember_payment_details = false;
            string pay_method = "m";
            //below variables for login are assigned to buy tickets as existing customer in 2nd method
            bool log_in_first = true;
            bool already_logged_in = true;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "5");            
            //***********************************************************************************

            //Buy tickets            
            FunctionLibrary.BuyTicktes_NewCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, pay_method, TestContext.TestName);
            //stored-payment is set to true as remember payment was ticked
            bool stored_payment = false;
            //Verify payment method stored in my account
            TopNavigation.SelectSubMenu("Hi", "Your Details");            
            MyAccountPage.ValidateStoredPaymentMethod(pay_method,stored_payment);            
            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        //Login as existing customer first and then book tickets with Visa  ----2-----
        [TestMethod]
        [TestCategory("Master"), TestCategory("Book")]
        public void Trusted_Login_First_And_Then_Buy_Tickets_Gift_No_No_Remember_Yes_Master()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = false;
            bool is_gift_details_section = false;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "m";
            bool log_in_first = true;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");
            tickets_to_book.Add(TestData.draws_preorder[0], "50");
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        //Select Tickets first and then Login as existing customer to book tickets with Visa  ----3-----
        [TestMethod]
        [TestCategory("Master"), TestCategory("Book")]
        public void Trusted_Click_Buy_Tickets_First_And_Then_Login_Gift_No_No_Remember_Yes_Master()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = false;
            bool is_gift_details_section = false;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "m";
            bool log_in_first = false;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");
            tickets_to_book.Add(TestData.draws_preorder[0], "50");
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }


        //Select Tickets first and then Login as existing customer to book tickets with Visa  ----4-----
        //Select Gift checkbox at homepage, Gift auto-selected at step 3 and remember payment details
        [TestMethod]
        [TestCategory("Master"), TestCategory("Book")]
        public void Trusted_Click_Buy_Tickets_First_And_Then_Login_Gift_Yes_Yes_Remember_Yes_Master()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = true;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "m";
            bool log_in_first = false;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");
            tickets_to_book.Add(TestData.draws_preorder[0], "50");
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        //Select Tickets first and then Login as existing customer to book tickets with Visa  ----5-----
        //Select Gift checkbox at homepage, Gift auto-selected at step 3 and dont remember payment details
        [TestMethod]
        [TestCategory("Master"), TestCategory("Book")]
        public void Trusted_Login_First_And_Then_Buy_Tickets_Gift_No_Yes_Remember_No_Master()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = true;
            bool remember_payment_details = false;
            bool stored_payment = false;
            string pay_method = "m";
            bool log_in_first = true;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "5");
            tickets_to_book.Add(TestData.draws_preorder[0], "100");
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        //Select Tickets first and then Login as existing customer to book tickets with Visa  ----6-----
        //Select Gift checkbox at homepage, DeSelect gift at step 3 and remember payment details        
        [TestMethod]
        [TestCategory("Master"), TestCategory("Book")]
        public void Trusted_Login_First_And_Then_Buy_Tickets_Gift_Yes_No_Remember_Yes_Master()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = false;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "m";
            bool log_in_first = true;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");
            tickets_to_book.Add(TestData.draws_preorder[0], "50");
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        //Select Tickets first and then Login as existing customer to book tickets with Visa  ----7-----
        //Select Gift checkbox at homepage, DeSelect gift at step 3 and remember payment details        
        [TestMethod]
        [TestCategory("Master"), TestCategory("Book")]
        public void Trusted_Click_Buy_Tickets_First_And_Then_Login_CurrentDraw_PreOrder_Gift_Yes_No_Remember_No_Master()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = false;
            bool remember_payment_details = false;
            bool stored_payment = false;
            string pay_method = "m";
            bool log_in_first = false;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");
            tickets_to_book.Add(TestData.draws_preorder[0], "50");
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        //******************  End of MasterCard Test Cases  ************************

        //*******************************************    Quick Buy ******************************
        
            //Select Tickets first and then Login as existing customer to book tickets with Visa  ----7-----
        //Select Gift checkbox at homepage, DeSelect gift at step 3 and remember payment details        
        [TestMethod]
        [TestCategory("Master"), TestCategory("Book"), TestCategory("QuickBuy")]
        public void Trusted_Click_Quick_Buy_First_And_Then_Login_Gift_Yes_No_Remember_No_Master()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = false;
            bool remember_payment_details = false;
            bool stored_payment = false;
            string pay_method = "m";
            bool log_in_first = false;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");
            //tickets_to_book.Add(TestData.draws_preorder[0], "50");
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.QuickBuy_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        // Buy ticket for new customer, validate payment method and then, create booking as exsisting customer   ----1-----
        [TestMethod]
        [TestCategory("Visa"), TestCategory("Book"), TestCategory("QuickBuy")]
        public void New_Customer_Quick_Buy_Gift_No_No_Remember_Yes_Visa()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = false;
            bool is_gift_details_section = false;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "v";
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            //tickets_to_book.Add("355", "50");
            tickets_to_book.Add(TestData.draws_live[0], "30");            
            //***********************************************************************************

            //Buy tickets as new customer
            FunctionLibrary.QuickBuy_NewCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, pay_method, TestContext.TestName);
            //Verify payment method stored in my account
            TopNavigation.SelectSubMenu("Hi", "Your Details");
            MyAccountPage.ValidateStoredPaymentMethod(pay_method, stored_payment);
            //Buy tickets as existing customer already logged in
            //FunctionLibrary.QuickBuy_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        // Buy ticket for new customer, validate payment method and then, create booking as exsisting customer   ----1-----
        [TestMethod]
        [TestCategory("Visa"), TestCategory("Book"), TestCategory("QuickBuy")]
        public void New_Customer_Quick_Buy_Gift_Yes_Yes_Remember_No_Visa()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = true;
            bool remember_payment_details = false;
            bool stored_payment = false;
            string pay_method = "v";
            //below variables for login are assigned to buy tickets as existing customer in 2nd method
            bool log_in_first = true;
            bool already_logged_in = true;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");            
            //***********************************************************************************

            //Buy tickets as new customer
            FunctionLibrary.QuickBuy_NewCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, pay_method, TestContext.TestName);
            //Verify payment method stored in my account
            TopNavigation.SelectSubMenu("Hi", "Your Details");
            MyAccountPage.ValidateStoredPaymentMethod(pay_method, stored_payment);
            //Buy tickets as existing customer already logged in
            //FunctionLibrary.QuickBuy_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }


        //Login as existing customer first and then book tickets with Visa  ----2-----
        [TestMethod]
        [TestCategory("Visa"), TestCategory("Book"), TestCategory("QuickBuy")]
        public void Trusted_Login_First_And_Then_Quick_Buy_Gift_No_No_Remember_Yes_Visa()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = false;
            bool is_gift_details_section = false;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "v";
            bool log_in_first = true;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");            
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.QuickBuy_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        //Select Tickets first and then Login as existing customer to book tickets with Visa  ----3-----
        [TestMethod]
        [TestCategory("Visa"), TestCategory("Book"), TestCategory("QuickBuy")]
        public void Trusted_Click_Quick_Buy_First_And_Then_Login_Gift_No_No_Remember_Yes_Visa()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = false;
            bool is_gift_details_section = false;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "v";
            bool log_in_first = false;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");            
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.QuickBuy_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
            Assert.IsNotNull(TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber]);
        }


        //Select Tickets first and then Login as existing customer to book tickets with Visa  ----4-----
        //Select Gift checkbox at homepage, Gift auto-selected at step 3 and remember payment details
        [TestMethod]
        [TestCategory("Visa"), TestCategory("Book"), TestCategory("QuickBuy")]
        public void Trusted_Click_Quick_Buy_First_And_Then_Login_Gift_Yes_Yes_Remember_Yes_Visa()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = true;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "v";
            bool log_in_first = false;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");            
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.QuickBuy_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        //Select Tickets first and then Login as existing customer to book tickets with Visa  ----5-----
        //Select Gift checkbox at homepage, Gift auto-selected at step 3 and dont remember payment details
        [TestMethod]
        [TestCategory("Visa"), TestCategory("Book"), TestCategory("QuickBuy")]
        public void Trusted_Login_First_And_Then_Quick_Buy_Gift_No_Yes_Remember_No_Visa_26755()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = false;
            bool is_gift_details_section = true;
            bool remember_payment_details = false;
            bool stored_payment = false;
            string pay_method = "v";
            bool log_in_first = true;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "50");            
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.QuickBuy_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        //Select Tickets first and then Login as existing customer to book tickets with Visa  ----6-----
        //Select Gift checkbox at homepage, DeSelect gift at step 3 and remember payment details        
        [TestMethod]
        [TestCategory("Visa"), TestCategory("Book"), TestCategory("QuickBuy")]
        public void Trusted_Login_First_And_Then_Quick_Buy_Gift_Yes_No_Remember_Yes_Visa()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = false;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "v";
            bool log_in_first = true;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");            
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.QuickBuy_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        //Select Tickets first and then Login as existing customer to book tickets with Visa  ----7-----
        //Select Gift checkbox at homepage, DeSelect gift at step 3 and remember payment details        
        [TestMethod]
        [TestCategory("Visa"), TestCategory("Book"), TestCategory("QuickBuy")]
        public void Trusted_Click_Quick_Buy_First_And_Then_Login_Gift_Yes_No_Remember_No_Visa()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = false;
            bool remember_payment_details = false;
            bool stored_payment = false;
            string pay_method = "v";
            bool log_in_first = false;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");            
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.QuickBuy_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        /*
        //Login first and then click buy tickets to book tickets with Visa  ----9-----
        //Select Gift checkbox at homepage, DeSelect gift at step 3 and remember payment details        
        [TestMethod]
        [TestCategory("Visa"), TestCategory("Facebook"), TestCategory("Book")]
        public void Trusted_Facebook_Login_First_And_Then_Buy_Tickets_Gift_Yes_No_Remember_Yes_Visa()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = false;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "v";
            bool log_in_first = true;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");
            tickets_to_book.Add(TestData.draws_preorder[0], "50");
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingFacebookCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, TestContext.TestName);
        }


        //Login first and then click buy tickets to book tickets with Visa  ----9-----
        //Select Gift checkbox at homepage, DeSelect gift at step 3 and remember payment details        
        [TestMethod]
        [TestCategory("Paypal"), TestCategory("Facebook"), TestCategory("Book")]
        public void Trusted_Facebook_Login_First_And_Then_Buy_Tickets_Gift_Yes_No_Remember_Yes_Paypal()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = false;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "p";
            bool log_in_first = true;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "50");
            tickets_to_book.Add(TestData.draws_preorder[0], "50");
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingFacebookCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, TestContext.TestName);
        }


        //Select Tickets first and then Login as existing customer to book tickets with Visa  ----8-----
        //Select Gift checkbox at homepage, Gift auto-selected at step 3 and remember payment details
        [TestMethod]
        [TestCategory("Visa"), TestCategory("Smoke"), TestCategory("Facebook"), TestCategory("Book")]
        public void Trusted_Facebook_Click_Buy_Tickets_First_And_Then_Login_Gift_Yes_Yes_Remember_Yes_Visa()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = true;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "v";
            bool log_in_first = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");
            tickets_to_book.Add(TestData.draws_preorder[0], "50");
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingFacebookCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, TestContext.TestName);
        }


        //Select Tickets first and then Login as existing customer to book tickets with Visa  ----8-----
        //Select Gift checkbox at homepage, Gift auto-selected at step 3 and remember payment details
        [TestMethod]
        [TestCategory("Visa"), TestCategory("Smoke"), TestCategory("Facebook"), TestCategory("Book"), TestCategory("QuickBuy")]
        public void Trusted_Facebook_Click_Quick_Buy_First_And_Then_Login_Gift_Yes_Yes_Remember_Yes_Visa()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = true;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "v";
            bool log_in_first = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");            
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.QuickBuy_ExistingFacebookCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, TestContext.TestName);
        }

        //Login first and then click buy tickets to book tickets with Visa  ----9-----
        //Select Gift checkbox at homepage, DeSelect gift at step 3 and remember payment details        
        [TestMethod]
        [TestCategory("Visa"), TestCategory("Facebook"), TestCategory("Book"), TestCategory("QuickBuy")]
        public void Trusted_Facebook_Login_First_And_Then_Quick_Buy_Gift_Yes_No_Remember_Yes_Visa()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = false;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "v";
            bool log_in_first = true;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");            
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.QuickBuy_ExistingFacebookCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, TestContext.TestName);
        }
        */

        // Buy ticket for new customer   ----1-----
        [TestMethod]
        [TestCategory("Paypal"), TestCategory("Book"), TestCategory("QuickBuy"), TestCategory("Smoke")]
        public void New_Customer_QuickBuy_Gift_Yes_No_Remember_No_Paypal()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = false;
            bool remember_payment_details = false;
            bool stored_payment = false;
            string pay_method = "p";
            //below variables for login are assigned to buy tickets as existing customer in 2nd method
            bool log_in_first = true;
            bool already_logged_in = true;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");            
            //***********************************************************************************

            //Buy tickets
            FunctionLibrary.QuickBuy_NewCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, pay_method, TestContext.TestName);
            //Verify payment method stored in my account
            TopNavigation.SelectSubMenu("Hi", "Your Details");
            MyAccountPage.ValidateStoredPaymentMethod(pay_method, stored_payment);
            //Buy tickets as existing customer already logged in
            //FunctionLibrary.QuickBuy_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        //Select Tickets first and then Login as existing customer to book tickets with Visa  ----5-----
        //Select Gift checkbox at homepage, Gift auto-selected at step 3 and dont remember payment details
        [TestMethod]
        [TestCategory("Smoke"), TestCategory("Paypal"), TestCategory("Book"), TestCategory("QuickBuy")]
        public void Trusted_Login_First_And_Then_Quick_Buy_Gift_No_Yes_Remember_No_Paypal()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = false;
            bool is_gift_details_section = true;
            bool remember_payment_details = false;
            bool stored_payment = false;
            string pay_method = "p";
            bool log_in_first = true;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");            
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.QuickBuy_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        //********************  End of Quick Buy *********************************************************


        //******************  Start of Paypal Test Cases  ************************

        // Buy ticket for new customer   ----1-----
        [TestMethod]
        [TestCategory("Paypal"), TestCategory("Book")]
        public void New_Customer_CurrentDraw_PreOrder_Gift_Yes_No_Remember_No_Paypal()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = false;
            bool remember_payment_details = false;
            bool stored_payment = false;
            string pay_method = "p";
            //below variables for login are assigned to buy tickets as existing customer in 2nd method
            bool log_in_first = true;
            bool already_logged_in = true;            
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");
            tickets_to_book.Add(TestData.draws_preorder[0], "50");
            //***********************************************************************************

            //Buy tickets
            FunctionLibrary.BuyTicktes_NewCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, pay_method, TestContext.TestName);
            //Verify payment method stored in my account
            TopNavigation.SelectSubMenu("Hi", "Your Details");            
            MyAccountPage.ValidateStoredPaymentMethod(pay_method,stored_payment);
            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        //Select Tickets first and then Login as existing customer to book tickets with Visa  ----5-----
        //Select Gift checkbox at homepage, Gift auto-selected at step 3 and dont remember payment details
        [TestMethod]
        [TestCategory("Smoke"), TestCategory("Paypal"), TestCategory("Book")]
        public void Trusted_Login_First_And_Then_Buy_Tickets_Gift_No_Yes_Remember_No_Paypal()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = false;
            bool is_gift_details_section = true;
            bool remember_payment_details = false;
            bool stored_payment = false;
            string pay_method = "p";
            bool log_in_first = true;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");
            tickets_to_book.Add(TestData.draws_preorder[0], "50");
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        //Select Tickets first and then Login as existing customer to book tickets with Visa  ----6-----
        //Select Gift checkbox at homepage, DeSelect gift at step 3 and remember payment details        
        [TestMethod]
        [TestCategory("Paypal"), TestCategory("Book")]
        public void Trusted_Login_First_And_Then_Buy_Tickets_Gift_Yes_No_Remember_Yes_Paypal()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = false;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "p";
            bool log_in_first = true;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "50");
            tickets_to_book.Add(TestData.draws_preorder[0], "50");
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }


        //******************  End of Paypal Test Cases  ************************

        //******************  Start of Amex Test Cases  ************************

        // Buy ticket for new customer, validate payment method and then, create booking as exsisting customer   ----1-----
        [TestMethod]
        [TestCategory("Amex"), TestCategory("Book")]
        public void New_Customer_PreOrderOnly_Gift_Yes_Yes_Remember_No_Amex()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = true;
            bool remember_payment_details = false;
            bool stored_payment = false;
            string pay_method = "a";
            //below variables for login are assigned to buy tickets as existing customer in 2nd method
            bool log_in_first = true;
            bool already_logged_in = true;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            //tickets_to_book.Add(TestData.draws_live[0], "50");
            tickets_to_book.Add(TestData.draws_preorder[0], "50");
            //***********************************************************************************

            //Buy tickets as new customer
            FunctionLibrary.BuyTicktes_NewCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, pay_method, TestContext.TestName);
            //Verify payment method stored in my account
            TopNavigation.SelectSubMenu("Hi", "Your Details");
            MyAccountPage.ValidateStoredPaymentMethod(pay_method, stored_payment);
            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        //Login as existing customer first and then book tickets with Visa  ----2-----
        [TestMethod]
        [TestCategory("Amex"), TestCategory("Book")]
        public void Trusted_Login_First_And_Then_Buy_Tickets_Gift_No_No_Remember_Yes_Amex()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = false;
            bool is_gift_details_section = false;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "a";
            bool log_in_first = true;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");            
            tickets_to_book.Add(TestData.draws_preorder[0], "50");
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        //******************  End of Amex Test Cases  ************************

        //******************  Start of Diners Test Cases  ************************

        // Buy ticket for new customer, validate payment method and then, create booking as exsisting customer   ----1-----
        [TestMethod]
        [TestCategory("Diners"), TestCategory("Book")]
        public void New_Customer_PreOrderOnly_Gift_Yes_Yes_Remember_No_Diners()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = true;
            bool is_gift_details_section = true;
            bool remember_payment_details = false;
            bool stored_payment = false;
            string pay_method = "d";
            //below variables for login are assigned to buy tickets as existing customer in 2nd method
            bool log_in_first = true;
            bool already_logged_in = true;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            //tickets_to_book.Add(TestData.draws_live[0], "50");
            tickets_to_book.Add(TestData.draws_preorder[0], "100");
            //***********************************************************************************

            //Buy tickets as new customer
            FunctionLibrary.BuyTicktes_NewCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, pay_method, TestContext.TestName);
            //Verify payment method stored in my account
            TopNavigation.SelectSubMenu("Hi", "Your Details");
            MyAccountPage.ValidateStoredPaymentMethod(pay_method, stored_payment);
            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        //Login as existing customer first and then book tickets with Visa  ----2-----
        [TestMethod]
        [TestCategory("Diners"), TestCategory("Book")]
        public void Trusted_Login_First_And_Then_Buy_Tickets_Gift_No_No_Remember_Yes_Diners()
        {
            //*************************    Test Data   ******************************************
            bool is_gift_checkout_page = false;
            bool is_gift_details_section = false;
            bool remember_payment_details = true;
            bool stored_payment = true;
            string pay_method = "d";
            bool log_in_first = true;
            bool already_logged_in = false;
            //Declare which tickets to book in which draws
            Dictionary<string, string> tickets_to_book = new Dictionary<string, string>();
            tickets_to_book.Add(TestData.draws_live[0], "30");
            tickets_to_book.Add(TestData.draws_preorder[0], "50");
            //***********************************************************************************

            //Buy tickets as existing customer already logged in
            FunctionLibrary.BuyTicktes_ExistingCustomer(tickets_to_book, is_gift_checkout_page, is_gift_details_section, remember_payment_details, stored_payment, pay_method, log_in_first, already_logged_in, TestContext.TestName);
        }

        //******************  End of Amex Test Cases  ************************

        [TestCleanup]
        public void TestCleanup()
        {
            Console.WriteLine("   Entered Test Cleanup");
            Console.WriteLine(TestContext.CurrentTestOutcome);
            if (TestContext.CurrentTestOutcome == UnitTestOutcome.Failed)
            {
                Console.WriteLine("   Entered if statement");
                FunctionLibrary.ScreenGrab(TestContext.TestName);

            }
            Console.WriteLine("   Finished Test Cleanup");
        }

        /*-----End of Test Cases which reuse existing ticket book methods in function library----------
        //------------------------------------------------------------------------------
        //Delete This after--------------------------------------------------------------
        [TestMethod]
        public void BurnUp_86_CheckIterationPathsLoad()
        {
            bool isLoaded = false;
            try
            {
                FunctionLibrary.ShowSelectedData();
                _selenium.ClickIterationPath();
                isLoaded = _selenium.CheckIterationPathsLoad();
            }
            catch (Exception)
            {
                var testFilePath = FunctionLibrary.ScreenGrab("BurnUp_86_CheckIterationPathsLoadERROR");
                AttachScreenShotFileToTestResult(testFilePath);
                throw;
            }
            Assert.IsTrue(isLoaded);
        }
        public void AttachScreenShotFileToTestResult(string screenShotPath)
        {
            try
            {
                if (!string.IsNullOrEmpty(screenShotPath))
                {
                    TestContext.AddResultFile(screenShotPath);
                }
            }
            catch (Exception)
            {
                //We don't want to stop the tests because we can't attach a file so we let it go....let it go.. let it go...
            }
        }
        */
        //------------------------------------------------------------------------------



        /*

        [TestMethod]
        public void OrderTickets()
        {

            //CheckoutPageTests chk =  new CheckoutPageTests();
            //chk.VerifyCheckout();

            bool resultStatus;
            CheckoutPage.ClickBuyTickets();

            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$20";
            TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketValue] = "$75";


            bool firstOrderStatus = CheckoutPage.MultipleOrderSelection("1", TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            bool secondOrderStatus = CheckoutPage.MultipleOrderSelection("2", TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketValue]);
            if (firstOrderStatus == secondOrderStatus)
            {
                resultStatus = true;
            }
            else { resultStatus = false; }
            Assert.IsTrue(resultStatus);

            // Verify the total amount on the Order total
            string orderTotalValue = CheckoutPage.GetOrderTotalValue();

            //Calculate the Order Total Value the customer has selected
            CheckoutPage.CalcOrderTotalValue();

            StringAssert.Contains(orderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue]);
            
            //click on checkout
            CheckoutPage.SelectCheckOutButton();

            //Select Customer New or Existing
            CheckoutPage.FeedNewCustomerDetails(); 
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Select Payment method Amex Credit card            
            CheckoutPage.CreditCardPaymentMethod(TestData.CreditCardNumber[TestData.CreditCardNumbersKey.AmexCard], false);

            //Enter customer details           
            CheckoutPage.CustomerContactDetails(false);
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Order Summary validation        
            string finalOrderTotalValue = CheckoutPage.GetFinaliseOrderTotalValue();
                       
            StringAssert.Contains(finalOrderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue], "The total ticket value in the finalise summary page is different to what it wasselected");

            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
            Assert.IsTrue(confirmOrderStatus);

            //Verify that a Ticket Number is allocated            
            Assert.IsNotNull(TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber]);
            Assert.IsNotNull(TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketNumber]);

            //Validate the order confirmation page
            string OrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();

            StringAssert.Contains(OrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");

            


        }

        [TestMethod]
        public void OrderSingleExistingDiscoverGift()
        {

            //CheckoutPageTests chk =  new CheckoutPageTests();
            //chk.VerifyCheckout();
                        
            CheckoutPage.ClickBuyTickets();

            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$30";
            
            bool firstOrderStatus = CheckoutPage.ChooseAndSelectOrder(TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            Assert.IsTrue(firstOrderStatus);

            // Verify the total amount on the Order total
            string orderTotalValue = CheckoutPage.GetOrderTotalValue();

            //Calculate the Order Total Value the customer has selected
            CheckoutPage.CalcOrderTotalValue();

            StringAssert.Contains(orderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue]);

            //click on checkout
            CheckoutPage.SelectCheckOutButton();

            //Select Customer  Existing
            CheckoutPage.FeedExistCustomerDetails();
            //CheckoutPage.FeedNewCustomerDetails(TestData.CustomerDetails[TestData.CustomerDetailsKey.FirstName], TestData.CustomerDetails[TestData.CustomerDetailsKey.Email]);
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Modify Payment option to Credit card
            CheckoutPage.ModifyPaymentMethod();
            //Select Payment method Amex Credit card            
            CheckoutPage.CreditCardPaymentMethod(TestData.CreditCardNumber[TestData.CreditCardNumbersKey.DiscoverCard], false);

            //Modify the personal details
            CheckoutPage.ModifyDetails();

            //Enter customer details           
            CheckoutPage.CustomerContactDetails(true);
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Order Summary validation        
            string finalOrderTotalValue = CheckoutPage.GetFinaliseOrderTotalValue();

            StringAssert.Contains(finalOrderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue], "The total ticket value in the finalise summary page is different to what it wasselected");

            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
            Assert.IsTrue(confirmOrderStatus);

            //Verify that a Ticket Number is allocated            
            Assert.IsNotNull(TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber]);
            Assert.IsNotNull(TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketNumber]);

            //Validate the order confirmation page
            string OrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();

            StringAssert.Contains(OrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");
            

        }



        [TestMethod]
        public void OrderSingleExistingVisaGiftRememberPayment()
        {

            
            //Sigin to the website
             Utility.SignIn();

            //Click on Buy Tickets
             TopNavigation.BuyTickets.GoTo();

            //LotteryDrawPageGallery.OpenSapientPreviewPage();
            //Driver.Instance.Navigate().GoToUrl("http://preview.sapientnitro.com.au/rsl/checkout.html");

            CheckoutPage.ClickBuyTickets();

            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$10";

            bool firstOrderStatus = CheckoutPage.ChooseAndSelectOrder(TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            Assert.IsTrue(firstOrderStatus);

            // Verify the total amount on the Order total
            string orderTotalValue = CheckoutPage.GetOrderTotalValue();

            
            //Calculate the Order Total Value the customer has selected
            CheckoutPage.CalcOrderTotalValue();

           
            StringAssert.Contains(orderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue]);

            //Select Gift option click on checkout
            CheckoutPage.SelectCheckOutButton(true);

            //Modify Payment option to Credit card
 //           CheckoutPage.ModifyPaymentMethod();
            //Select Payment method Amex Credit card            
            CheckoutPage.CreditCardPaymentMethod(TestData.CreditCardNumber[TestData.CreditCardNumbersKey.VisaCard], true);
            
            //Validate the customer details
            string existingCustomerDetails = CheckoutPage.GetExistingCustomerContactDetails();
            StringAssert.Contains(existingCustomerDetails, TestData.CustomerDetails[TestData.CustomerDetailsKey.FirstName]);
            StringAssert.Contains(existingCustomerDetails, TestData.CustomerDetails[TestData.CustomerDetailsKey.PhoneNumber]);
            StringAssert.Contains(existingCustomerDetails, TestData.CustomerDetails[TestData.CustomerDetailsKey.Email]);
            StringAssert.Contains(existingCustomerDetails, TestData.CustomerDetails[TestData.CustomerDetailsKey.Address]);

            //Give Gift details
            CheckoutPage.SelectGiftInYourDetails();

            Driver.Wait(TimeSpan.FromSeconds(3));

            //Order Summary validation        
            string finalOrderTotalValue = CheckoutPage.GetFinaliseOrderTotalValue();

            StringAssert.Contains(finalOrderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue], "The total ticket value in the finalise summary page is different to what it wasselected");

            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
                                
            Assert.IsTrue(confirmOrderStatus);

            //Verify that a Ticket Number is allocated            
            Assert.IsNotNull(TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber]);
            Assert.IsNotNull(TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketNumber]);

            //Validate the order confirmation page
            string OrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();

            StringAssert.Contains(OrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");


        }


        [TestMethod]
        public void OrderMultipleExistingPaypal()
        {

            
            CheckoutPage.ClickBuyTickets();
                       
            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$5";
            TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketValue] = "$100";

            bool resultStatus;
            bool firstOrderStatus = CheckoutPage.MultipleOrderSelection("1", TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            bool secondOrderStatus = CheckoutPage.MultipleOrderSelection("2", TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketValue]);
            if (firstOrderStatus == secondOrderStatus)
            {
                resultStatus = true;
            }
            else { resultStatus = false; }
            Assert.IsTrue(resultStatus);

            // Verify the total amount on the Order total
            string orderTotalValue = CheckoutPage.GetOrderTotalValue();

            //Calculate the Order Total Value the customer has selected
            CheckoutPage.CalcOrderTotalValue();

            StringAssert.Contains(orderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue]);
            
            //click on checkout
            CheckoutPage.SelectCheckOutButton();

            //Select Customer  Existing
            CheckoutPage.FeedExistCustomerDetails();
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Modify Payment option to Credit card
            CheckoutPage.ModifyPaymentMethod();
            //Select Payment method Paypal
            CheckoutPage.PaypalPaymentMethod(false);
            

            //Modify the personal details
            CheckoutPage.ModifyDetails();

            //Enter customer details           
            CheckoutPage.CustomerContactDetails(false);
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Order Summary validation        
            string finalOrderTotalValue = CheckoutPage.GetFinaliseOrderTotalValue();

            StringAssert.Contains(finalOrderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue], "The total ticket value in the finalise summary page is different to what it wasselected");

            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
            Assert.IsTrue(confirmOrderStatus);

            //Verify that a Ticket Number is allocated            
            Assert.IsNotNull(TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber]);
            Assert.IsNotNull(TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketNumber]);

            //Validate the order confirmation page
            string OrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();

            StringAssert.Contains(OrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");
            
        }
        

        [TestMethod]
        public void OrderSingleExistingPaypalRememberPayment()
        {

            CheckoutPage.ClickBuyTickets();


            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$20";

            bool firstOrderStatus = CheckoutPage.ChooseAndSelectOrder(TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            Assert.IsTrue(firstOrderStatus);

            // Verify the total amount on the Order total
            string orderTotalValue = CheckoutPage.GetOrderTotalValue();

            //Calculate the Order Total Value the customer has selected
            CheckoutPage.CalcOrderTotalValue();

            StringAssert.Contains(orderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue]);

            //click on checkout
            CheckoutPage.SelectCheckOutButton();
                       
            //Select Customer  Existing
            CheckoutPage.FeedExistCustomerDetails();
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Modify Payment option to Credit card
            CheckoutPage.ModifyPaymentMethod();
            //Select Payment method Paypal
            CheckoutPage.PaypalPaymentMethod(true);


            //Modify the personal details
            CheckoutPage.ModifyDetails();

            //Enter customer details           
            CheckoutPage.CustomerContactDetails(false);
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Order Summary validation        
            string finalOrderTotalValue = CheckoutPage.GetFinaliseOrderTotalValue();

            StringAssert.Contains(finalOrderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue], "The total ticket value in the finalise summary page is different to what it wasselected");

            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
            Assert.IsTrue(confirmOrderStatus);

            //Verify that a Ticket Number is allocated            
            Assert.IsNotNull(TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber]);
            Assert.IsNotNull(TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketNumber]);

            //Validate the order confirmation page
            string OrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();

            StringAssert.Contains(OrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");


        }

        

        [TestMethod]
        public void OrderMultipleExistingStoredPaypal()
        {
            //Sigin to the website
            // Utility.SignIn();

            //SignInPage.SigningIn(TestData.CustomerDetails[TestData.CustomerDetailsKey.Email], TestData.CustomerDetails[TestData.CustomerDetailsKey.Password]);

            //SignInPage.SigningIn("testing123456@gmail.com", "4me2test");

            //SignInPage.Button("Sign in");

            ////Update the stored payment method
            //MyAccountPage.Navigation("payment method");

            //MyAccountPage.UpdatePayment_Click_Modify_Button();

            //MyAccountPage.UpdatePaymentMethod("paypal");

            //Click on Buy Tickets
            // TopNavigation.BuyTickets.GoTo();


            LotteryDrawPageGallery.OpenSapientPreviewPage();
            Driver.Instance.Navigate().GoToUrl("https://rslau-cd.tst.rslqld.org");

            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$50";
            TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketValue] = "$10";

            bool resultStatus;
            bool firstOrderStatus = CheckoutPage.MultipleOrderSelection("1", TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            bool secondOrderStatus = CheckoutPage.MultipleOrderSelection("2", TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketValue]);
            if (firstOrderStatus == secondOrderStatus)
            {
                resultStatus = true;
            }
            else { resultStatus = false; }
            Assert.IsTrue(resultStatus);

            // Verify the total amount on the Order total
            string orderTotalValue = CheckoutPage.GetOrderTotalValue();

            //Calculate the Order Total Value the customer has selected
            CheckoutPage.CalcOrderTotalValue();

            StringAssert.Contains(orderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue]);
                        
            //click on checkout
            CheckoutPage.SelectCheckOutButton();

            //Select Customer  Existing
           // CheckoutPage.FeedExistCustomerDetails();
            //Driver.Wait(TimeSpan.FromSeconds(3));
                  

            //Order Summary validation        
            string finalOrderTotalValue = CheckoutPage.GetFinaliseOrderTotalValue();

            StringAssert.Contains(finalOrderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue], "The total ticket value in the finalise summary page is different to what it wasselected");

            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
            Assert.IsTrue(confirmOrderStatus);

            //Verify that a Ticket Number is allocated            
            Assert.IsNotNull(TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber]);
            Assert.IsNotNull(TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketNumber]);

            //Validate the order confirmation page
            string OrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();

            StringAssert.Contains(OrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");
            
        }


        [TestMethod]
        public void OrderSingleExistingLoggedinStoredDiscoverGift()
        {

            //Sigin to the website
            // Utility.SignIn();

            ////Update the stored payment method
            //MyAccountPage.Navigation("payment method");

            //MyAccountPage.UpdatePayment_Click_Modify_Button();

           // MyAccountPage.UpdatePaymentMethod("new credit card", TestData.CreditCardNumber[TestData.CreditCardNumbersKey.DiscoverCard], "Discover Card", TestData.CreditCardNumber[TestData.CreditCardNumbersKey.ExpiryDate]);
           
            //Click on Buy Tickets
            // TopNavigation.BuyTickets.GoTo();

            LotteryDrawPageGallery.OpenSapientPreviewPage();
            Driver.Instance.Navigate().GoToUrl("http://preview.sapientnitro.com.au/rsl/checkout.html");

            CheckoutPage.ClickBuyTickets();

            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$100";

            bool firstOrderStatus = CheckoutPage.ChooseAndSelectOrder(TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            Assert.IsTrue(firstOrderStatus);

            // Verify the total amount on the Order total
            string orderTotalValue = CheckoutPage.GetOrderTotalValue();

            //Calculate the Order Total Value the customer has selected
            CheckoutPage.CalcOrderTotalValue();

            StringAssert.Contains(orderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue]);

            //Select Gift option click on checkout
            CheckoutPage.SelectCheckOutButton(true);

            //Validate the customer details
            string existingCustomerDetails = CheckoutPage.GetExistingCustomerContactDetails();
            StringAssert.Contains(existingCustomerDetails, TestData.CustomerDetails[TestData.CustomerDetailsKey.FirstName]);
            StringAssert.Contains(existingCustomerDetails, TestData.CustomerDetails[TestData.CustomerDetailsKey.PhoneNumber]);
            StringAssert.Contains(existingCustomerDetails, TestData.CustomerDetails[TestData.CustomerDetailsKey.Email]);
            StringAssert.Contains(existingCustomerDetails, TestData.CustomerDetails[TestData.CustomerDetailsKey.Address]);

            //Give Gift details
            CheckoutPage.SelectGiftInYourDetails();
                       
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Order Summary validation        
            string finalOrderTotalValue = CheckoutPage.GetFinaliseOrderTotalValue();

            StringAssert.Contains(finalOrderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue], "The total ticket value in the finalise summary page is different to what it wasselected");

            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
            Assert.IsTrue(confirmOrderStatus);

            //Verify that a Ticket Number is allocated            
            Assert.IsNotNull(TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber]);
            Assert.IsNotNull(TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketNumber]);

            //Validate the order confirmation page
            string OrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();

            StringAssert.Contains(OrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");


        }


        [TestMethod]
        public void OrderMultipleExistingLoggedinPaypal()
        {


            //Sigin to the website
            // Utility.SignIn();

            //Click on Buy Tickets
            // TopNavigation.BuyTickets.GoTo();

            LotteryDrawPageGallery.OpenSapientPreviewPage();
            Driver.Instance.Navigate().GoToUrl("http://preview.sapientnitro.com.au/rsl/checkout.html");

            CheckoutPage.ClickBuyTickets();


            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$20";

            bool firstOrderStatus = CheckoutPage.ChooseAndSelectOrder(TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            Assert.IsTrue(firstOrderStatus);

            // Verify the total amount on the Order total
            string orderTotalValue = CheckoutPage.GetOrderTotalValue();

            //Calculate the Order Total Value the customer has selected
            CheckoutPage.CalcOrderTotalValue();

            StringAssert.Contains(orderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue]);

            //click on checkout
            CheckoutPage.SelectCheckOutButton();

            //Select Customer  Existing
            CheckoutPage.FeedExistCustomerDetails();
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Modify Payment option to Credit card
            CheckoutPage.ModifyPaymentMethod();
            //Select Payment method Paypal
            CheckoutPage.PaypalPaymentMethod(true);


            //Modify the personal details
            CheckoutPage.ModifyDetails();

            //Enter customer details           
            CheckoutPage.CustomerContactDetails(false);
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Order Summary validation        
            string finalOrderTotalValue = CheckoutPage.GetFinaliseOrderTotalValue();

            StringAssert.Contains(finalOrderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue], "The total ticket value in the finalise summary page is different to what it wasselected");

            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
            Assert.IsTrue(confirmOrderStatus);

            //Verify that a Ticket Number is allocated            
            Assert.IsNotNull(TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber]);
            Assert.IsNotNull(TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketNumber]);

            //Validate the order confirmation page
            string OrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();

            StringAssert.Contains(OrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");


        }

        // Test case which verifies that a new customer is able to order multiple tickets with Paypal.
        [TestMethod]
        public void OrderMultipleNewPaypal()
        {


            CheckoutPage.ClickBuyTickets();

            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$50";
            TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketValue] = "$50";

            bool resultStatus;
            bool firstOrderStatus = CheckoutPage.MultipleOrderSelection("1", TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            bool secondOrderStatus = CheckoutPage.MultipleOrderSelection("2", TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketValue]);
            if (firstOrderStatus == secondOrderStatus)
            {
                resultStatus = true;
            }
            else { resultStatus = false; }


            Assert.IsTrue(resultStatus);

            // Verify the total amount on the Order total
            string orderTotalValue = CheckoutPage.GetOrderTotalValue();

            //Calculate the Order Total Value the customer has selected
            CheckoutPage.CalcOrderTotalValue();

            StringAssert.Contains(orderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue]);

            //click on checkout
            CheckoutPage.SelectCheckOutButton();

            //Select Paypal check out option 
            CheckoutPage.PayPalCheckout();
                                
            //Select Payment method Paypal
            CheckoutPage.PaypalPaymentMethod(false);


            //Enter customer details           
            CheckoutPage.CustomerContactDetails(false);
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Order Summary validation        
            string finalOrderTotalValue = CheckoutPage.GetFinaliseOrderTotalValue();

            StringAssert.Contains(finalOrderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue], "The total ticket value in the finalise summary page is different to what it wasselected");

            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
            Assert.IsTrue(confirmOrderStatus);

            //Verify that a Ticket Number is allocated            
            Assert.IsNotNull(TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber]);
            Assert.IsNotNull(TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketNumber]);

            //Validate the order confirmation page
            string OrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();

            StringAssert.Contains(OrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");

        }



        //Test case which verifies that new customer is able to order a single ticket using Paypal.
        [TestMethod]
        public void OrderSingleNewPaypalCheckout()
        {

            CheckoutPage.ClickBuyTickets();
            

            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$30";

            CheckoutPage.DeselectOrder();

            bool firstOrderStatus = CheckoutPage.ChooseAndSelectOrder(TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            Assert.IsTrue(firstOrderStatus);


            //Deselect the second order
            CheckoutPage.DeselectOrder();


            // Verify the total amount on the Order total
            string orderTotalValue = CheckoutPage.GetOrderTotalValue();

            //Calculate the Order Total Value the customer has selected
            CheckoutPage.CalcOrderTotalValue();

            StringAssert.Contains(orderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue]);

            //click on checkout
            CheckoutPage.SelectCheckOutButton();


            //Select Paypal check out option 
            CheckoutPage.PayPalCheckout();

            //Select Payment method Paypal
            CheckoutPage.PaypalPaymentMethod(false,false);


            //Enter customer details           
            CheckoutPage.CustomerContactDetails(false);
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Order Summary validation        
            string finalOrderTotalValue = CheckoutPage.GetFinaliseOrderTotalValue();

            StringAssert.Contains(finalOrderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue], "The total ticket value in the finalise summary page is different to what it wasselected");

            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
            Assert.IsTrue(confirmOrderStatus);

            //Verify that a Ticket Number is allocated            
            Assert.IsNotNull(TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber]);
            Assert.IsNotNull(TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketNumber]);

            //Validate the order confirmation page
            string OrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();

            StringAssert.Contains(OrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");




        }

        
        //New Customer , Credit Card - Visa, Remember Payment - Yes, Gift - Yes, Current Draw - Yes, PreOrder - N
         

        [TestMethod]
        public void OrderSingleNewVisaGiftRememberPayment()
        {

            //Initialize the new customer data
            TestData.CreateNewCustomerData();

            CheckoutPage.ClickBuyTickets();

            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$50";

            //Deselecting the default selected ticket
            CheckoutPage.DeselectOrder();
            
            //Select the ticket and verify it is displayed on the order summary
            bool firstOrderStatus = CheckoutPage.ChooseAndSelectOrder(TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            Assert.IsTrue(firstOrderStatus);

            // Verify the total amount on the Order total
            string orderTotalValue = CheckoutPage.GetOrderTotalValue();

            //Calculate the Order Total Value the customer has selected
            CheckoutPage.CalcOrderTotalValue();

            StringAssert.Contains(orderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue]);

            //click on checkout
            CheckoutPage.SelectCheckOutButton();

            //Select Customer  New
            //CheckoutPage.FeedExistCustomerDetails();
           CheckoutPage.FeedNewCustomerDetails();
            Driver.Wait(TimeSpan.FromSeconds(3));

            
            //Select Payment method Visa Credit card            
            CheckoutPage.CreditCardPaymentMethod(TestData.CreditCardNumber[TestData.CreditCardNumbersKey.VisaCard], true);
                     

            //Enter customer details           
            CheckoutPage.CustomerContactDetails(true);
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Order Summary validation        
            string finalOrderTotalValue = CheckoutPage.GetFinaliseOrderTotalValue();

            StringAssert.Contains(finalOrderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue], "The total ticket value in the finalise summary page is different to what it wasselected");

            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
            Assert.IsTrue(confirmOrderStatus);

            //Verify that a Ticket Number is allocated            
            Assert.IsNotNull(TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber]);
            Assert.IsNotNull(TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketNumber]);

            //Validate the order confirmation page
            string OrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();

            StringAssert.Contains(OrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");


        }


        //New Customer , Credit card - Amex, Remember payment - No, Gift - Yes, Current Draw - Yes, PreOrder - No

        [TestMethod]
        public void OrderSingleNewAmexGift()
        {

            //Initialize the new customer data
            TestData.CreateNewCustomerData();

            CheckoutPage.ClickBuyTickets();

            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$50";

            //Deselecting the default selected ticket
            CheckoutPage.DeselectOrder();

            //Select the ticket and verify it is displayed on the order summary
            bool firstOrderStatus = CheckoutPage.ChooseAndSelectOrder(TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            Assert.IsTrue(firstOrderStatus);

            // Verify the total amount on the Order total
            string orderTotalValue = CheckoutPage.GetOrderTotalValue();

            //Calculate the Order Total Value the customer has selected
            CheckoutPage.CalcOrderTotalValue();

            StringAssert.Contains(orderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue]);

            //click on checkout
            CheckoutPage.SelectCheckOutButton();

            //Select Customer  New
            //CheckoutPage.FeedExistCustomerDetails();
            CheckoutPage.FeedNewCustomerDetails();
            Driver.Wait(TimeSpan.FromSeconds(3));


            //Select Payment method Visa Credit card            
            CheckoutPage.CreditCardPaymentMethod(TestData.CreditCardNumber[TestData.CreditCardNumbersKey.AmexCard], false);


            //Enter customer details           
            CheckoutPage.CustomerContactDetails(true);
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Order Summary validation        
            string finalOrderTotalValue = CheckoutPage.GetFinaliseOrderTotalValue();

            StringAssert.Contains(finalOrderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue], "The total ticket value in the finalise summary page is different to what it wasselected");

            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
            Assert.IsTrue(confirmOrderStatus);

            //Verify that a Ticket Number is allocated            
            Assert.IsNotNull(TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber]);
            Assert.IsNotNull(TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketNumber]);

            //Validate the order confirmation page
            string OrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();

            StringAssert.Contains(OrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");


        }

        //New Customer, Credit Card - Diners Club, Multiple Tickets
        [TestMethod]
        public void OrderMultipleNewDiners()
        {

            //Initialize the new customer data
            TestData.CreateNewCustomerData();

            CheckoutPage.ClickBuyTickets();

            //Deselecting the default selected ticket
            CheckoutPage.DeselectOrder();
            
            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$50";
            TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketValue] = "$20";

            bool resultStatus;
            bool firstOrderStatus = CheckoutPage.MultipleOrderSelection("1", TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            bool secondOrderStatus = CheckoutPage.MultipleOrderSelection("2", TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketValue]);
            if (firstOrderStatus == secondOrderStatus)
            {
                resultStatus = true;
            }
            else { resultStatus = false; }
            Assert.IsTrue(resultStatus);

            // Verify the total amount on the Order total
            string orderTotalValue = CheckoutPage.GetOrderTotalValue();

            //Calculate the Order Total Value the customer has selected
            CheckoutPage.CalcOrderTotalValue();

            StringAssert.Contains(orderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue]);

            //click on checkout
            CheckoutPage.SelectCheckOutButton();

            //Select Customer  New
            //CheckoutPage.FeedExistCustomerDetails();
            CheckoutPage.FeedNewCustomerDetails();
            Driver.Wait(TimeSpan.FromSeconds(3));


            //Select Payment method Visa Credit card            
            CheckoutPage.CreditCardPaymentMethod(TestData.CreditCardNumber[TestData.CreditCardNumbersKey.AmexCard], false);


            //Enter customer details           
            CheckoutPage.CustomerContactDetails(true);
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Order Summary validation        
            string finalOrderTotalValue = CheckoutPage.GetFinaliseOrderTotalValue();

            StringAssert.Contains(finalOrderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue], "The total ticket value in the finalise summary page is different to what it wasselected");

            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
            Assert.IsTrue(confirmOrderStatus);

            //Verify that a Ticket Number is allocated            
            Assert.IsNotNull(TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber]);
            Assert.IsNotNull(TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketNumber]);

            //Validate the order confirmation page
            string OrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();

            StringAssert.Contains(OrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");


        }

        //New Customer , Credit card - Discover, Remember payment - No, Gift - No, Current Draw - Yes, PreOrder - No

        [TestMethod]
        public void OrderSingleNewDiscover()
        {

            //Initialize the new customer data
            TestData.CreateNewCustomerData();

            CheckoutPage.ClickBuyTickets();

            TestData.orderDetails[TestData.OrderDetailsKey.TicketValue] = "$50";

            //Deselecting the default selected ticket
            CheckoutPage.DeselectOrder();

            //Select the ticket and verify it is displayed on the order summary
            bool firstOrderStatus = CheckoutPage.ChooseAndSelectOrder(TestData.orderDetails[TestData.OrderDetailsKey.TicketValue]);
            Assert.IsTrue(firstOrderStatus);

            // Verify the total amount on the Order total
            string orderTotalValue = CheckoutPage.GetOrderTotalValue();

            //Calculate the Order Total Value the customer has selected
            CheckoutPage.CalcOrderTotalValue();

            StringAssert.Contains(orderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue]);

            //click on checkout
            CheckoutPage.SelectCheckOutButton();

            //Select Customer  New
            //CheckoutPage.FeedExistCustomerDetails();
            CheckoutPage.FeedNewCustomerDetails();
            Driver.Wait(TimeSpan.FromSeconds(3));


            //Select Payment method Visa Credit card            
            CheckoutPage.CreditCardPaymentMethod(TestData.CreditCardNumber[TestData.CreditCardNumbersKey.DiscoverCard], false);


            //Enter customer details           
            CheckoutPage.CustomerContactDetails(false);
            Driver.Wait(TimeSpan.FromSeconds(3));

            //Order Summary validation        
            string finalOrderTotalValue = CheckoutPage.GetFinaliseOrderTotalValue();

            StringAssert.Contains(finalOrderTotalValue, TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue], "The total ticket value in the finalise summary page is different to what it wasselected");

            //Confirm Order
            bool confirmOrderStatus = CheckoutPage.ConfirmOrder();
            Assert.IsTrue(confirmOrderStatus);

            //Verify that a Ticket Number is allocated            
            Assert.IsNotNull(TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber]);
            Assert.IsNotNull(TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketNumber]);

            //Validate the order confirmation page
            string OrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();

            StringAssert.Contains(OrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");


        }


        //

    */



    }

}
