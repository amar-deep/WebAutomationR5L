﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RslWebAutomation.PageActions;
using System.Collections.Generic;

namespace RslWebAutomationTests.TestRunner
{
    [TestClass]
    public class DeclineCodesTests : WebsiteTest
    {        
        public static string[] pay_types = new string[4];
        Random rnd = new Random();

        [ClassInitialize]
        public static void DeclineCodesInit(TestContext context)
        {         
            pay_types[0] = "v";
            pay_types[1] = "m";
            pay_types[2] = "v";
            pay_types[3] = "m";
        }

        [TestInitialize]
        public void DeclineCodeTest()
        {
        }
       
        //Test decline code by using decline code as customer name in payment
        //While booking tickets as new customer
        [DataTestMethod]
        [DataRow("error 2000")]
        [DataRow("error 2001")]
        [DataRow("error 2002")]
        [DataRow("error 2003")]
        [DataRow("error 2004")]        
        [TestCategory("DeclineCodes")]
        public void Decline_Code_Test_Via_New_Customer_Ticket_Booking__Top_Four(string ccName)
        {            
            string pay_method = pay_types[rnd.Next(0, 3)];
                                    
            FunctionLibrary.BuyTicktes_NewCustomer_CreditCardDeclineCodes_Verification
                (pay_method, ccName, TestContext.TestName);
            //Validate the order error message page
            if (CheckoutPage.OrderFailureMessageDisplayed())            
                Console.WriteLine("   Error Message displayed for decline code '" + ccName + "'");            
            else            
                Assert.Fail("Error Message not displayed for decline code '" + ccName + "'");                        
        }        

        //Test decline code by using decline code as customer name in payment
        //While booking tickets as new customer
        [DataTestMethod]        
        [DataRow("error 2005")]
        [DataRow("error 2006")]
        [DataRow("error 2007")]
        [DataRow("error 2008")]
        [DataRow("error 2009")]
        [DataRow("error 2010")]
        [DataRow("error 2011")]
        [DataRow("error 2012")]
        [DataRow("error 2013")]
        [DataRow("error 2014")]
        [DataRow("error 2015")]
        [DataRow("error 2016")]
        [DataRow("error 2017")]
        [DataRow("error 2018")]
        [DataRow("error 2019")]
        [DataRow("error 2020")]
        [DataRow("error 2021")]
        [DataRow("error 2022")]
        [DataRow("error 2023")]
        [DataRow("error 2024")]
        [DataRow("error 2025")]
        [DataRow("error 2026")]
        [DataRow("error 2027")]
        [TestCategory("DeclineCodes")]
        public void Decline_Code_Test_Via_New_Customer_Ticket_Booking(string ccName)
        {
            string pay_method = pay_types[rnd.Next(0, 3)];

            FunctionLibrary.BuyTicktes_NewCustomer_CreditCardDeclineCodes_Verification
                (pay_method, ccName, TestContext.TestName);
            //Validate the order error message page
            if (CheckoutPage.OrderFailureMessageDisplayed())
                Console.WriteLine("   Error Message displayed for decline code '" + ccName + "'");
            else
                Assert.Fail("Error Message not displayed for decline code '" + ccName + "'");
        }

    }

}
