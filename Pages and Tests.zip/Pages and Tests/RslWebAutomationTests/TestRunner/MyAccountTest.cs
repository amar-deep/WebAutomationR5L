﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RslWebAutomation;
using RslWebAutomation.Utility;
using RslWebAutomation.PageActions;
using OpenQA.Selenium;

namespace RslWebAutomationTests.TestRunner
{   
    [TestClass]
    public class MyAccountTest : WebsiteTest
    {
       
        [TestInitialize]
        public void MyAccountBrowserInit()
        {
            
        }
        

        [TestMethod]
        [TestCategory("MyAccount")]
        public void Verify_Login_With_Valid_And_Invalid_Credentials()
        {
            string login_fail_xpath = "//span[@class='form-validation-failed']";            
            string email_empty_xpath = "//span[text()='Please enter your Email']";
            string password_empty_xpath = "//span[text()='Please enter your Password']";

            //**********  Login with wrong email ********************
            LogInPage.SignIn("incorrectemail@gmail.com", "password");
            if (Utility.isElementPresent(login_fail_xpath))
                Console.WriteLine("   Not abel to login with incorrect email as expected");
            else
                Assert.Fail("Logged in with incorrect email");
            Driver.Instance.Navigate().Refresh();

            //**********  Login with wrong password ********************
            LogInPage.SignIn("test.remembervisa@dev-rslqld.org", "wrongpassword");
            if (Utility.isElementPresent(login_fail_xpath))
                Console.WriteLine("   Not abel to login with incorrect email as expected");
            else
                Assert.Fail("Logged in with incorrect password");
            Driver.Instance.Navigate().Refresh();

            //Login without entering username and password
            LogInPage.SignIn("", "");
            if (Utility.isElementPresent(email_empty_xpath) && Utility.isElementPresent(password_empty_xpath))
                Console.WriteLine("   Correct error message displayed if login without email and password");
            else
                Assert.Fail("Logged in with incorrect password");
            Driver.Instance.Navigate().Refresh();

            //Login with entering valid username and password
            LogInPage.SignIn("test.remembervisa@dev-rslqld.org", "password");
            TopNavigation.SelectSubMenu("Hi", "Your Details");        
        }


        [TestMethod]
        [TestCategory("MyAccount")]
        public void Verify_Error_If_Current_Password_Is_Wrong_In_UpdatePassword()
        {
            string incorrect_password_message_xpath = "//*[contains(text(),'The password you entered is incorrect')]";
            
            //Login with entering valid username and password
            LogInPage.SignIn("test.remembervisa@dev-rslqld.org", "password");
            TopNavigation.SelectSubMenu("Hi", "Your Details");
            //Navigate to Update Password section, key in password in textboxes and click on Update button
            MyAccountPage.Navigation("Update password");            
            MyAccountPage.UpdatePassword_Enter_Password_Values("test", "testtest","testtest");
            MyAccountPage.UpdatePassword_Click_Update_Button();

            if (Utility.isElementPresent(incorrect_password_message_xpath))
                Console.WriteLine("   Message shown that The password you entered is incorrect");
            else
                Assert.Fail("Correct message about wrong password not shown");
            Driver.Wait(TimeSpan.FromSeconds(2));
        }

        [TestMethod]
        [TestCategory("MyAccount")]
        public void Verify_Error_If_Updated_Password_Does_Not_Have_Minimum_Length()
        {
            string minimum_password_length_message_xpath = "//span[@for='account-new-password' and contains(text(),'The password should be minimum 6 characters')]";
            string minimum_confirm_password_length_message_xpath = "//span[@for='account-new-password-confirm' and contains(text(),'The password should be minimum 6 characters')]";
            
            //Login with entering valid username and password
            LogInPage.SignIn("test.remembervisa@dev-rslqld.org", "password");
            TopNavigation.SelectSubMenu("Hi", "Your Details");
            //Navigate to Update Password section and key in password in textboxes
            MyAccountPage.Navigation("Update password");            
            MyAccountPage.UpdatePassword_Enter_Password_Values("test", "test", "test");
            
            if (Utility.isElementPresent(minimum_password_length_message_xpath) && Utility.isElementPresent(minimum_confirm_password_length_message_xpath))
                Console.WriteLine("   Messages shown correctly about password length");
            else
                Assert.Fail("Correct message about message length not shown");
            Driver.Wait(TimeSpan.FromSeconds(2));
        }

        [TestMethod]
        [TestCategory("MyAccount")]
        public void Verify_Error_If_New_Password_And_Confirm_Password_Do_Not_Match()
        {            
            string confirm_password_mismatch_message_xpath = "//span[@for='account-new-password-confirm' and contains(text(),'Passwords do not match')]";

            //Login with entering valid username and password
            LogInPage.SignIn("test.remembervisa@dev-rslqld.org", "password");
            TopNavigation.SelectSubMenu("Hi", "Your Details");
            //Navigate to Update Password section and key in password in textboxes
            MyAccountPage.Navigation("Update password");
            MyAccountPage.UpdatePassword_Enter_Password_Values("test", "testtest", "testtes");

            if (Utility.isElementPresent(confirm_password_mismatch_message_xpath))
                Console.WriteLine("   Messages shown correctly about password not matching in confirm password");
            else
                Assert.Fail("Correct message about message not matching in confirm password not shown");
            Driver.Wait(TimeSpan.FromSeconds(2));
        }

        [TestMethod]
        [TestCategory("MyAccount")]
        public void Verify_Password_Can_Be_Updated_Succesfully()
        {
            string password_updated_message_xpath = "//*[contains(text(),'Updated Password Successfully')]";
            string modal_password_updated_ok_button = "//div[@id='modal-password-updated']//a[text()='OK']";

            //Login with entering valid username and password
            LogInPage.SignIn("test.updatepassword@dev-rslqld.org", "password");
            TopNavigation.SelectSubMenu("Hi", "Your Details");
            //Navigate to Update Password section and key in password in textboxes
            MyAccountPage.Navigation("Update password");
            MyAccountPage.UpdatePassword_Enter_Password_Values("password", "password1", "password1");
            MyAccountPage.UpdatePassword_Click_Update_Button();

            if (Utility.isElementPresent(password_updated_message_xpath))
                Console.WriteLine("   Messages shown correctly about password updated succesfully");
            else
                Assert.Fail("Messages not shown about password updated succesfully");
            Driver.Wait(TimeSpan.FromSeconds(2));
            Driver.Instance.FindElement(By.XPath(modal_password_updated_ok_button)).Click();
            MyAccountPage.SignOut();

            //Verify loggin with new password
            LogInPage.SignIn("test.updatepassword@dev-rslqld.org", "password1");
            TopNavigation.SelectSubMenu("Hi", "Your Details");
            //Update password back to previous one so that this test case can be reRun again
            MyAccountPage.Navigation("Update password");
            MyAccountPage.UpdatePassword_Enter_Password_Values("password1", "password", "password");
            MyAccountPage.UpdatePassword_Click_Update_Button();

            if (Utility.isElementPresent(password_updated_message_xpath))
                Console.WriteLine("   Messages shown correctly about password updated succesfully");
            else
                Assert.Fail("Messages not shown about password updated succesfully");
            Driver.Wait(TimeSpan.FromSeconds(2));
            Driver.Instance.FindElement(By.XPath(modal_password_updated_ok_button)).Click();
            MyAccountPage.SignOut();
        }

        [TestMethod]
        [TestCategory("MyAccount")]
        public void Verify_Top_Navigation_When_User_Is_Logged_In_Or_Logged_Out()
        {            
            //Login with entering valid username and password
            LogInPage.SignIn("test.remembervisa@dev-rslqld.org", "password");
            //Click on 'My Account' header. this is to verify Signin tab has been changed into 'My Account' tab
            try
            {
                //TopNavigation.SelectMenu("MyAccount");
                TopNavigation.SelectSubMenu("Hi", "Your Details");
                Console.WriteLine("   My Account header tab clickable after Signing In");
            }
            catch
            {
                Assert.Fail("My Account header tab not clickable after Signing In");
            }
            MyAccountPage.SignOut();
            try
            {
                TopNavigation.SelectMenu("Login");
                Console.WriteLine("   Login header tab clickable after Signing In");
            }
            catch
            {
                Assert.Fail("Login header tab not clickable after Signing In");
            }
        }

        [TestMethod]
        [TestCategory("MyAccount")]
        public void Verify_Forgotten_Password_Link_Present_At_Expected_Pages()
        {
            string forgotten_password_link_sign_in_page = "//form[@id='frmLogin']//a[text()='Forgotten Your password?']";
            string forgotten_password_link_checkout_page = "//form[@id='ExistingMemberForm']//a[text()='Forgot password?']";
            string forgotten_password_link_vip_checkout_page = "//form[@id='ExistingMemberForm']//a[text()='Forgot password?']";

            //Check forgotten password link at Sign In page
            TopNavigation.SelectMenu("Login");
            if (Utility.isElementPresent(forgotten_password_link_sign_in_page))
                Console.WriteLine("   Forgotten password link present at page Sign In as expexpected");
            else
                Assert.Fail("Forgotten password link not present at page Sign");
            Driver.Wait(TimeSpan.FromSeconds(2));

            //Check forgotten password link at checkout page
            HomePage.ClickBuyTickets();
            CheckoutPage.SelectTickets();
            CheckoutPage.ClickBuyTickets(false);
            CheckoutPage.Click_ExistCustomer_CheckBox();
            if (Utility.isElementPresent(forgotten_password_link_checkout_page))
                Console.WriteLine("   Forgotten password link present at page CheckOut as expexpected");
            else
                Assert.Fail("Forgotten password link not present at page CheckOut");
            Driver.Wait(TimeSpan.FromSeconds(2));

            //Check forgotten password link at VIP checkout page
            JoinVIPPage.Goto_Join_VIP_Club_Page();
            Driver.Wait(TimeSpan.FromSeconds(2));
            JoinVIPPage.Click_JoinNow();
            CheckoutPage.Click_ExistCustomer_CheckBox();

            if (Utility.isElementPresent(forgotten_password_link_vip_checkout_page))
                Console.WriteLine("   Forgotten password link present at page VIP CheckOut as expexpected");
            else
                Assert.Fail("Forgotten password link not present at page VIP CheckOut");
            Driver.Wait(TimeSpan.FromSeconds(2));
        }

        [TestMethod]
        [TestCategory("MyAccount")]
        public void Verify_Payment_Type_Update_To_Paypal()
        {
            //*************************    Test Data   ******************************************
            string new_payment_method = "p";
            //***********************************************************************************
            LogInPage.SignIn("test.updatepayment@dev-rslqld.org", "password");
            TopNavigation.SelectSubMenu("Hi", "Your Details");
            MyAccountPage.Update_Payment_Method(new_payment_method);

            if (!MyAccountPage.Verify_Details_Updated_Succesfully())
            {
                Assert.Fail("Failed as Details not updated succesfully. Please check");
            }
            else
            { 
                MyAccountPage.Click_Ok_Button_On_Modal_Details_Updated();                
                if (MyAccountPage.ValidateStoredPaymentMethod(new_payment_method, true))
                    Console.WriteLine("   Payment method succesfully updated as " + new_payment_method);
                else
                    Assert.Fail("Error. Payment details not updated to " + new_payment_method);
            }
        }

        [TestMethod]
        [TestCategory("Smoke"), TestCategory("MyAccount")]
        public void Verify_Payment_Method_Update_To_VISA()
        {
            //*************************    Test Data   ******************************************
            string new_payment_method = "v";
            //***********************************************************************************
            LogInPage.SignIn("test.updatepayment@dev-rslqld.org", "password");
            TopNavigation.SelectSubMenu("Hi", "Your Details");
            MyAccountPage.Update_Payment_Method(new_payment_method);

            if (!MyAccountPage.Verify_Details_Updated_Succesfully())
            {
                Assert.Fail("Failed as Details not updated succesfully. Please check");
            }
            else
            {
                MyAccountPage.Click_Ok_Button_On_Modal_Details_Updated();                
                if (MyAccountPage.ValidateStoredPaymentMethod(new_payment_method, true))
                    Console.WriteLine("   Payment method succesfully updated as " + new_payment_method);
                else
                    Assert.Fail("Error. Payment details not updated to " + new_payment_method);
            }
        }

        [TestMethod]
        [TestCategory("MyAccount")]
        public void Verify_Payment_Method_Update_To_AMEX()
        {
            //*************************    Test Data   ******************************************
            string new_payment_method = "a";
            //***********************************************************************************
            LogInPage.SignIn("test.updatepayment@dev-rslqld.org", "password");
            TopNavigation.SelectSubMenu("Hi", "Your Details");
            MyAccountPage.Update_Payment_Method(new_payment_method);

            if (!MyAccountPage.Verify_Details_Updated_Succesfully())
            {
                Assert.Fail("Failed as Details not updated succesfully. Please check");
            }
            else
            {
                MyAccountPage.Click_Ok_Button_On_Modal_Details_Updated();
                if (MyAccountPage.ValidateStoredPaymentMethod(new_payment_method, true))
                    Console.WriteLine("   Payment method succesfully updated as " + new_payment_method);
                else
                    Assert.Fail("Error. Payment details not updated to " + new_payment_method);
            }
        }

        [TestMethod]
        [TestCategory("MyAccount")]
        public void Verify_Update_Address()
        {
            //*************************    Test Data   ******************************************
            string newAddress = "89 Rue";
            //***********************************************************************************
            LogInPage.SignIn("test.updateaddress@dev-rslqld.org", "password");
            TopNavigation.SelectSubMenu("Hi", "Your Details");            
            MyAccountPage.Update_Address(newAddress);

            if (!MyAccountPage.Verify_Details_Updated_Succesfully())
            {
                Assert.Fail("Failed as Details not updated succesfully. Please check");
            }
            else
            {
                MyAccountPage.Click_Ok_Button_On_Modal_Details_Updated();
                
                if (MyAccountPage.Verify_Address_Updated(newAddress))
                    Console.WriteLine("   Address succesfully updated as " + newAddress);
                else
                    Assert.Fail("Error. Address not updated to " + newAddress);
            }

            //Change Address back to original address
            newAddress = "85 kealy";
            MyAccountPage.Update_Address(newAddress);
            MyAccountPage.Click_Ok_Button_On_Modal_Details_Updated();
        }

        [TestMethod]
        [TestCategory("MyAccount")]
        public void Verify_Payment_Method_Update_To_MasterCard()
        {
            //*************************    Test Data   ******************************************
            string new_payment_method = "m";
            //***********************************************************************************
            LogInPage.SignIn("test.updatepayment@dev-rslqld.org", "password");
            TopNavigation.SelectSubMenu("Hi", "Your Details");
            MyAccountPage.Update_Payment_Method(new_payment_method);

            if (!MyAccountPage.Verify_Details_Updated_Succesfully())
            {
                Assert.Fail("Failed as Details not updated succesfully. Please check");
            }
            else
            {
                MyAccountPage.Click_Ok_Button_On_Modal_Details_Updated();
                if (MyAccountPage.ValidateStoredPaymentMethod(new_payment_method, true))
                    Console.WriteLine("   Payment method succesfully updated as " + new_payment_method);
                else
                    Assert.Fail("Error. Payment details not updated to " + new_payment_method);
            }
        }


        [TestMethod]
        [TestCategory("MyAccount")]
        public void Verify_Payment_Method_Update_To_DINERSCLUB()
        {
            //*************************    Test Data   ******************************************
            string new_payment_method = "d";
            //***********************************************************************************
            LogInPage.SignIn("test.updatepayment@dev-rslqld.org", "password");
            TopNavigation.SelectSubMenu("Hi", "Your Details");
            MyAccountPage.Update_Payment_Method(new_payment_method);

            if (!MyAccountPage.Verify_Details_Updated_Succesfully())
            {
                Assert.Fail("Failed as Details not updated succesfully. Please check");
            }
            else
            {
                MyAccountPage.Click_Ok_Button_On_Modal_Details_Updated();
                if (MyAccountPage.ValidateStoredPaymentMethod(new_payment_method, true))
                    Console.WriteLine("   Payment method succesfully updated as " + new_payment_method);
                else
                    Assert.Fail("Error. Payment details not updated to " + new_payment_method);
            }

        }


        [TestMethod]
        [TestCategory("MyAccount")]
        public void Verify_Payment_Method_Update_To_DISCOVERcard()
        {

            //*************************    Test Data   ******************************************
            string new_payment_method = "dis";
            //***********************************************************************************
            LogInPage.SignIn("test.updatepayment@dev-rslqld.org", "password");
            TopNavigation.SelectSubMenu("Hi", "Your Details");
            MyAccountPage.Update_Payment_Method(new_payment_method);

            if (!MyAccountPage.Verify_Details_Updated_Succesfully())
            {
                Assert.Fail("Failed as Details not updated succesfully. Please check");
            }
            else
            {
                MyAccountPage.Click_Ok_Button_On_Modal_Details_Updated();
                if (MyAccountPage.ValidateStoredPaymentMethod(new_payment_method, true))
                    Console.WriteLine("   Payment method succesfully updated as " + new_payment_method);
                else
                    Assert.Fail("Error. Payment details not updated to " + new_payment_method);
            }

        }


        /*


        [TestMethod]
        public void VerifyDetailsUpdate()
        {
            //TestData.CreateCustomer();
            //SignInPage.SigningIn(TestData.CustomerDetails[TestData.CustomerDetailsKey.Email], TestData.CustomerDetails[TestData.CustomerDetailsKey.Password]);
            LogInPage.SignIn("automationTesting@rslqld.org", "Testing1234");

            MyAccountPage.Navigation("my details");

            MyAccountPage.DetailsBeforeUpdate();

            MyAccountPage.UpdateDetails_Click_Modify_Button();

            MyAccountPage.DetailsInput(TestData.CustomerDetails);

            //Check form validation errors
            Assert.IsTrue(MyAccountPage.formValidation("my details"), "Field validation failed");

            MyAccountPage.UpdateDetails_Click_Update_Button();

            Driver.Wait(TimeSpan.FromSeconds(2));

            Assert.IsTrue(MyAccountPage.AlertUpdatedBox(), "Update not successfull. Something went wrong");

            Driver.Wait(TimeSpan.FromSeconds(1));

            MyAccountPage.Navigation("my details");

            Assert.IsTrue(MyAccountPage.ValidateDetailsAfterUpdate(), "Personal Details are not updated. Please Verify");
        }
        


        [TestMethod]
        public void VerifySubscription()
        {

            LogInPage.SignIn(TestData.CustomerDetails[TestData.CustomerDetailsKey.Email], TestData.CustomerDetails[TestData.CustomerDetailsKey.Password]);

            MyAccountPage.Navigation("subscription");

            Driver.Wait(TimeSpan.FromSeconds(1));

            MyAccountPage.SelectSubscription("$1000");

            //MyAccountPage.UpdateBtn("subscription");

            MyAccountPage.AlertUpdatedBox();

            MyAccountPage.Navigation("subscription");

            Driver.Wait(TimeSpan.FromSeconds(1));

            Assert.IsTrue(MyAccountPage.ValidateSelectedSubSc("$1000"), "New Subscription \"UPDATED\"");

        }


        [TestMethod]
        public void VerifyOrderHistory()
        {

            //SignInPage.SigningIn(TestData.CustomerDetails[TestData.CustomerDetailsKey.Email], TestData.CustomerDetails[TestData.CustomerDetailsKey.Password]);
            LogInPage.SignIn("testing123456@gmail.com", "4me2test");
           
            CheckoutPage.ClickBuyTickets(false);

            //CheckoutPage.ChooseAndSelectOrder("$75");
            CheckoutPage.SelectTickets();

            // Get the Draw Number into Orderdetails Dictionary
            String DrawNum = MyAccountPage.GetText("//*[@id='js-order-summary']/table/tbody/tr[1]/td[1]/div[1]");

            TestData.orderDetails.Add(TestData.OrderDetailsKey.DrawNumber, DrawNum);
            
            CheckoutPage.SelectCheckOutButton();

            Driver.Wait(TimeSpan.FromSeconds(2));

            CheckoutPage.FeedExistCustomerDetails();

            Driver.Instance.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(2000);

            //CheckoutPage.CreditCardPaymentMethod(TestData.CreditCardNumber[TestData.CreditCardNumbersKey.AmexCard], TestData.CreditCardNumber[TestData.CreditCardNumbersKey.ExpiryDate], "RSLAmexCreditCard");

            //CheckoutPage.CustomerContactDetails(TestData.CustomerDetails[TestData.CustomerDetailsKey.FirstName], TestData.CustomerDetails[TestData.CustomerDetailsKey.LastName], TestData.CustomerDetails[TestData.CustomerDetailsKey.Email], false);

            CheckoutPage.ConfirmOrder();
            bool confirmOrderStatus = CheckoutPage.If_Order_Created_succesfully();

            Assert.IsTrue(confirmOrderStatus);

            // Get the Ticket Number into Orderdetails Dictionary
            String TicketNum = MyAccountPage.GetText("//*[@id='confirmation']/div/div[2]/div/div/div[2]/div[1]/div[3]");

            TestData.orderDetails.Add(TestData.OrderDetailsKey.TicketNumber, TicketNum);

            TopNavigation.SelectSubMenu("Hi", "Your Details");
           
            MyAccountPage.Navigation("order history");

            Driver.Wait(TimeSpan.FromSeconds(1));

            Assert.IsTrue(MyAccountPage.ValidateTicketDetailsInOrderHistory());

        }


        [TestMethod]
        public void VerifyVIPstatus()
        {

            //SignInPage.SigningIn(TestData.CustomerDetails[TestData.CustomerDetailsKey.Email], TestData.CustomerDetails[TestData.CustomerDetailsKey.Password]);
            LogInPage.SignIn("testing123456@gmail.com", "4me2test");

            MyAccountPage.Navigation("overview");
            
            String[] VIPstatus = Driver.Instance.FindElement(By.XPath("//*[@id='Overview']/p[4]")).Text.Split(':');

            //delete Scrolldown code when "subscription" is added in in-page navigation menu
            IWebElement element = Driver.Instance.FindElement(By.XPath("//*[@id='subscription']/div/div/div/div[3]/div/a"));
            Utility.ScrollDown(element, Driver.Instance);
            
            Driver.Wait(TimeSpan.FromSeconds(2));
            //MyAccountPage.Navigation("subscription");
            

            // Condition to verify if VIP status YES
            if (VIPstatus[1].ToLower().TrimStart().Equals("yes"))
            {
                Console.WriteLine(VIPstatus[1]);
                Assert.IsTrue(MyAccountPage.ValidateVIPStatus(), "As VIPStatus is \"YES\" No default SubScription is not selected for VIP");
            }

            // Condition to verify if VIP status NO
            if (VIPstatus[1].ToLower().TrimStart().Equals("no"))
            {
                Console.WriteLine(VIPstatus[1]);
                Assert.IsFalse(MyAccountPage.ValidateVIPStatus(), "As VIPStatus is \"NO\" SubScription is selected for Non VIP");
            }
        }

    */

    }
}
