﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RslWebAutomation;
using RslWebAutomation.PageActions;
using System.Collections.Generic;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;

namespace RslWebAutomationTests.TestRunner
{
    [TestClass]
    public class DynamicsTests
    {        
        
        [TestInitialize]
        public void DeclineCodeTest()
        {
        }
        

        [TestMethod]
        [TestCategory("DynamicsVerify")]
        public void Verify_Login_With_Valid_And_Invalid_Credentialsss()
        {            
            DynamicsFunctions.Log_Into_ERP("amardeep.chawla@rslqld.org", "Samreen06", "https://rslqlotos-uat.sandbox.operations.dynamics.com");
            DynamicsFunctions.Click_On_Module_Pane_Opener();
            DynamicsFunctions.Click_On_A_Module("Retail");
            DynamicsFunctions.click_On_A_module_Option("Customers", "Customer service");
            DynamicsFunctions.Enter_A_FilterCriteria_For_Searching("Email address");

            //Open excel file
            var FilePath = "C:\\Testing\\Web_Test_Data.xlsx";
            Excel.Application xlApp = new Excel.Application();
            try
            {
                Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(FilePath);
                string sheetname = (DateTime.Now.Day.ToString() + "_" + DateTime.Now.Month.ToString());
                Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[sheetname];
                //Excel._Worksheet xlWorksheet = xlApp.ActiveSheet;
                Excel.Range xlRange = xlWorksheet.UsedRange;
                int rowCount = xlRange.Rows.Count;
                Console.WriteLine("Iterate through all rows");
                for (int i = 2; i <= rowCount; i++)
                {
                    string email = xlWorksheet.Cells[i, 1].Text.Trim();
                    string tickets = xlWorksheet.Cells[i, 6].Text.Trim();
                    Console.WriteLine("Email value is " + email);

                    Console.WriteLine("Checking ticket if the ticket exists for email " + email);
                    DynamicsFunctions.Enter_Customers_Detail_In_Search_Box(email);
                    DynamicsFunctions.Click_On_Search_Button();
                    if (DynamicsFunctions.Click_On_Select_Button())
                    {
                        //Expand Sales Order tab
                        DynamicsFunctions.Expand_SalesOrder_FastTab_If_Collapsed();
                        //Expand Lines tab
                        DynamicsFunctions.Expand_SalesOrderLines_FastTab_If_Collapsed();
                        if (DynamicsFunctions.is_Sales_Order_Present(tickets))
                            Console.WriteLine("+++  Sales order found for email " + email + " and ticket number " + tickets);
                        else
                            Console.WriteLine("---------------Sales order not found for email " + email + " and ticket number " + tickets);
                    }
                    
                }

                Marshal.ReleaseComObject(xlRange);
                Marshal.ReleaseComObject(xlWorksheet);

                xlWorkbook.Close();
                Marshal.ReleaseComObject(xlWorkbook);

                //quit and release
                xlApp.Quit();
                Marshal.ReleaseComObject(xlApp);
                //Console.WriteLine("   Excel content is: " +cell_content); 
            }
            catch
            {
                //quit and release
                Console.WriteLine("Closing excel in case of any error in between");
                xlApp.Quit();
                Marshal.ReleaseComObject(xlApp);
                //Console.WriteLine("   Excel content is: " +cell_content); 

            }            
                            
            Driver.Wait(TimeSpan.FromSeconds(10));
        }

        public TestContext TestContext { get; set; }

        [TestCleanup]
        public void Cleanup()
        {
            Driver.Wait(TimeSpan.FromSeconds(2));
            Console.WriteLine("   Entered Test Cleanup");
            Console.WriteLine(TestContext.CurrentTestOutcome);
            if (TestContext.CurrentTestOutcome == UnitTestOutcome.Failed)
            {
                Console.WriteLine("   Entered if statement");
                FunctionLibrary.ScreenGrab(TestContext.TestName);

            }
            Console.WriteLine("   Finished Test Cleanup");
            if (!(TestContext.TestName).Contains("Excel"))
                Driver.Close();
            else
                Console.WriteLine("It is excel file test case");

        }
    }

}
