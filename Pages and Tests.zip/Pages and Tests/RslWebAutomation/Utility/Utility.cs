﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.IE;
using System;
//using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using OpenQA.Selenium.Interactions;
using System.Threading;
using RslWebAutomation.PageActions;
using OpenQA.Selenium.Support.UI;

namespace RslWebAutomation.Utility
{
    public class Utility
    {

        private static IWebDriver driver = null;

       

        public static IWebDriver getBrowser(String browsername)
        {
            if (browsername.Equals("firefox", StringComparison.OrdinalIgnoreCase))
            {
                driver = new FirefoxDriver();
            }
            else if (browsername.Equals("chrome", StringComparison.OrdinalIgnoreCase))
            {
                driver = new ChromeDriver();
            }
            else if (browsername.Equals("ie", StringComparison.OrdinalIgnoreCase))
            {
                driver = new InternetExplorerDriver();
            }

            driver.Manage().Window.Maximize();
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            return driver;
        }

        public static void Signout()
        {   
            //If the user is already logged out then return
           
            if (Driver.Instance.FindElements(By.XPath("//*[@id='app-container']//a[@href='/Login']")).Count() != 0)
                {
                return;
                }
            //Go to My Account
            TopNavigation.SelectSubMenu("Hi", "Your Details");

            IWebElement webSignOut = Driver.Instance.FindElement(By.XPath("//*[@id='sign-out']//a[contains( text(),'Sign Out')]"));
            webSignOut.Click();
            
        }

        public static Boolean CheckforElementAndClick(IWebElement element)
        {
            try
            {
                if (element.Displayed)
                {
                    element.Click();                    
                    //Console.WriteLine(element.ToString() + "  : ToString");
                    //Console.WriteLine(element.Text.ToString() + " : Text");
                    //Console.WriteLine(element.GetType() + " : Get Type ");
                    //Console.WriteLine(element.Location + " : Location");
                    //Console.WriteLine(element.Enabled + " : locator status");
                }
                else
                {
                    Console.WriteLine(element + "  element is not visible or displayed");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Exception caught.{0}", e.ToString());
                //throw e;
                return false;
            }
            return true;
        }

        /// <summary>
        /// Gets a string from the TestContext properties
        /// </summary>
        /// <param name="context">Test Context</param>
        /// <param name="property">Property to find</param>
        /// <returns>A string</returns>
       //// public static string GetrunSettingValue(TestContext context,string property)
       // {
             
       //     if (context.Properties[property] == null)
       //     {
       //         throw new ArgumentException("Property does not exist, does not have a value, or a test setting is not selected");
       //     }
       //     else
       //     {
       //         return context.Properties[property].ToString();
       //     }
       // }    


        public static IWebDriver ScrollDown(IWebElement actionElement, IWebDriver Instance)
        {
            Actions act = new Actions(Instance);
            //int T = (actionElement.Location.Y) + 2;
            //act.MoveByOffset(0,T).Build().Perform();
            //((IJavaScriptExecutor) Driver.Instance).ExecuteScript("window.scrollTo(0," + T + ")");
            act.SendKeys(Keys.PageDown).Perform();
            act.MoveToElement(actionElement).Build().Perform();
            
            ((IJavaScriptExecutor)Driver.Instance).ExecuteScript("arguments[0].scrollIntoView(false);", actionElement);
            Thread.Sleep(5000);
            Instance.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            return Instance;
        }


        public static Boolean isElementPresent(string ElementXpath)
        {

            IList<IWebElement> elements = Driver.Instance.FindElements(By.XPath(ElementXpath));

            if (elements.Count > 0)
                return true;
            else
                return false;

        }

        public static void SignIn()
        {
            //Go to login
            TopNavigation.SelectMenu("Login");

            Driver.Wait(TimeSpan.FromSeconds(5));
            
            //Give login information
            //SignInPage.SigningIn(TestData.CustomerDetails[TestData.CustomerDetailsKey.Email], TestData.CustomerDetails[TestData.CustomerDetailsKey.Password]);
            LogInPage.SignIn("testing123456@gmail.com", "4me2test");

            Driver.Wait(TimeSpan.FromSeconds(5));

        }
        public static void WaitforPageLoad()
        {

            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(60));
            wait.Until((x) =>
            {
                return ((IJavaScriptExecutor)Driver.Instance).ExecuteScript("return document.readyState").Equals("complete");
            });
        }







    }

}

