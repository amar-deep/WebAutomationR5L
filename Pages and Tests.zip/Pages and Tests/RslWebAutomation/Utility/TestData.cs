﻿using RslWebAutomation.PageActions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;


namespace RslWebAutomation.Utility
{
    public static class TestData
    {       
        public enum OrderDetailsKey
        {
            TicketValue,
            TicketNumber,
            DrawNumber,
            DrawDate,
            TotalOrderValue
        }

        public enum GiftDetailKey
        {
            FirstName,
            LastName,
            PhoneNumber,
            Email,
            Address,
            Message
        }

        public enum CustomerDetailsKey
        {
            FirstName,
            LastName,
            PhoneNumber,
            Email,
            Address,
            Day,
            Month,
            Year,
            Password
        }

        public enum ExisCustRememberVisaKey
        {
            FirstName,
            LastName,
            PhoneNumber,
            Email,
            Address,
            DOB,
            Password
        }

        public enum ExisCustDontRememberVisaKey
        {
            FirstName,
            LastName,
            PhoneNumber,
            Email,
            Address,
            DOB,
            Password
        }

        public enum ExisCustRememberMasterKey
        {
            FirstName,
            LastName,
            PhoneNumber,
            Email,
            Address,
            DOB,
            Password
        }

        public enum ExisCustDontRememberMasterKey
        {
            FirstName,
            LastName,
            PhoneNumber,
            Email,
            Address,
            DOB,
            Password
        }

        public enum ExisCustRememberPaypalKey
        {
            FirstName,
            LastName,
            PhoneNumber,
            Email,
            Address,
            DOB,
            Password
        }

        public enum ExisCustDontRememberPaypalKey
        {
            FirstName,
            LastName,
            PhoneNumber,
            Email,
            Address,
            DOB,
            Password
        }

        public enum ExisCustRememberAmexKey
        {
            FirstName,
            LastName,
            PhoneNumber,
            Email,
            Address,
            DOB,
            Password
        }

        public enum ExisCustRememberDinersKey
        {
            FirstName,
            LastName,
            PhoneNumber,
            Email,
            Address,
            DOB,
            Password
        }

        public enum CreditCardNumbersKey
        {
            VisaCard,
            AmexCard,
            DinersClubCard,
            MasterCard,
            DiscoverCard,  
            ExpiryDate            
        }

        public enum DynamicsDataKey
        {
            email,
            firstname,
            lastname,            
            is_gift,
            pay_method,
            tickets
        }

        public enum RetrieveExcelDataKey
        {
            email,
            firstname,
            lastname,
            is_gift,
            pay_method,
            tickets
        }


        //Stores the Order details in this object 
        public static Dictionary<OrderDetailsKey, string> orderDetails = new Dictionary<OrderDetailsKey, string>();
        public static Dictionary<OrderDetailsKey, string> secondOrderDetails = new Dictionary<OrderDetailsKey, string>();
        public static Dictionary<GiftDetailKey, string> giftDetails = new Dictionary<GiftDetailKey, string>();        
        public static Dictionary<CustomerDetailsKey, string> CustomerDetails = new Dictionary<CustomerDetailsKey, string>();        
        public static Dictionary<CreditCardNumbersKey, string> CreditCardNumber = new Dictionary<CreditCardNumbersKey, string>();

        public static Dictionary<ExisCustRememberVisaKey, string> ExisCustRememberVisa = new Dictionary<ExisCustRememberVisaKey, string>();
        public static Dictionary<ExisCustDontRememberVisaKey, string> ExisCustDontRememberVisa = new Dictionary<ExisCustDontRememberVisaKey, string>();

        public static Dictionary<ExisCustRememberMasterKey, string> ExisCustRememberMaster = new Dictionary<ExisCustRememberMasterKey, string>();
        public static Dictionary<ExisCustDontRememberMasterKey, string> ExisCustDontRememberMaster = new Dictionary<ExisCustDontRememberMasterKey, string>();

        public static Dictionary<ExisCustRememberPaypalKey, string> ExisCustRememberPaypal = new Dictionary<ExisCustRememberPaypalKey, string>();
        public static Dictionary<ExisCustDontRememberPaypalKey, string> ExisCustDontRememberPaypal = new Dictionary<ExisCustDontRememberPaypalKey, string>();

        public static Dictionary<ExisCustRememberAmexKey, string> ExisCustRememberAmex = new Dictionary<ExisCustRememberAmexKey, string>();

        public static Dictionary<ExisCustRememberDinersKey, string> ExisCustRememberDiners = new Dictionary<ExisCustRememberDinersKey, string>();

        public static Dictionary<DynamicsDataKey, string> DynamicsData = new Dictionary<DynamicsDataKey, string>();

        public static Dictionary<RetrieveExcelDataKey, string> RetrieveExcelData = new Dictionary<RetrieveExcelDataKey, string>();

        public static List<string> draws_live = new List<string>();
        public static List<string> draws_preorder = new List<string>();


        public static void CreateTestDrawData()
        {            
            draws_live.Add("371");
            //draws_live.Add("369L");
         
            draws_preorder.Add("372");            
        }                

        public static void CreateNewCustomerData()
        {
            //Create fake data for Customer personal details
            Random random = new System.Random();
            int rndNumber = random.Next(900);
            string rndHex = random.Next().ToString("X4");

            int randomDay = random.Next(1, 30);
            int randomMonth = random.Next(1, 12);
            int randomYear = random.Next(1920, 2000);

            CustomerDetails[CustomerDetailsKey.FirstName] = Faker.NameFaker.FirstName();
            CustomerDetails[CustomerDetailsKey.LastName] = Faker.NameFaker.LastName();
            CustomerDetails[CustomerDetailsKey.Email] = CustomerDetails[CustomerDetailsKey.FirstName] + '.' + CustomerDetails[CustomerDetailsKey.LastName] + "@dev-rslqld.org";
            //CustomerDetails[CustomerDetailsKey.PhoneNumber] = Faker.PhoneFaker.Phone();
            CustomerDetails[CustomerDetailsKey.PhoneNumber] = "02" + Faker.NumberFaker.Number(11111111, 99999999).ToString();
            CustomerDetails[CustomerDetailsKey.Address] = "UNIT 1 85 Kitchener St";
            CustomerDetails[CustomerDetailsKey.Day] = Faker.NumberFaker.Number(1, 10).ToString();
            CustomerDetails[CustomerDetailsKey.Month] = Faker.NumberFaker.Number(1, 12).ToString();
            CustomerDetails[CustomerDetailsKey.Year] = Faker.NumberFaker.Number(1940, 2000).ToString();
            CustomerDetails[CustomerDetailsKey.Password] = "password";
        }

        public static void CreateExistingCustomerData()
        {
            //Existing Customer details with Visa and remember payment details
            ExisCustRememberVisa[ExisCustRememberVisaKey.FirstName] = "Test";
            ExisCustRememberVisa[ExisCustRememberVisaKey.LastName] = "Remembervisa";
            ExisCustRememberVisa[ExisCustRememberVisaKey.Email] = "test.remembervisa1@dev-rslqld.org";            
            ExisCustRememberVisa[ExisCustRememberVisaKey.PhoneNumber] = "0765649899";
            ExisCustRememberVisa[ExisCustRememberVisaKey.Address] = "87 Eliza St KEILOR PARK VIC 3042 AUS";
            ExisCustRememberVisa[ExisCustRememberVisaKey.DOB] = "9th September 1990";           
            ExisCustRememberVisa[ExisCustRememberVisaKey.Password] = "password";

            //Existing Customer details with Visa and don't remember payment details
            ExisCustDontRememberVisa[ExisCustDontRememberVisaKey.FirstName] = "test";
            ExisCustDontRememberVisa[ExisCustDontRememberVisaKey.LastName] = "dontremembervisa";
            ExisCustDontRememberVisa[ExisCustDontRememberVisaKey.Email] = "test.dontremember_visa@dev-rslqld.org";            
            ExisCustDontRememberVisa[ExisCustDontRememberVisaKey.PhoneNumber] = "0765649899";
            ExisCustDontRememberVisa[ExisCustDontRememberVisaKey.Address] = "87 Eliza St KEILOR PARK VIC 3042 AUS";
            ExisCustDontRememberVisa[ExisCustDontRememberVisaKey.DOB] = "9th September 1990";
            ExisCustDontRememberVisa[ExisCustDontRememberVisaKey.Password] = "password";

            //Existing Customer details with MasterCard and remember payment details
            ExisCustRememberMaster[ExisCustRememberMasterKey.FirstName] = "Test";
            ExisCustRememberMaster[ExisCustRememberMasterKey.LastName] = "Remembermaster";
            ExisCustRememberMaster[ExisCustRememberMasterKey.Email] = "test.remembermaster@dev-rslqld.org";
            ExisCustRememberMaster[ExisCustRememberMasterKey.PhoneNumber] = "0765649899";
            ExisCustRememberMaster[ExisCustRememberMasterKey.Address] = "87 Eliza St KEILOR PARK VIC 3042 AUS";
            ExisCustRememberMaster[ExisCustRememberMasterKey.DOB] = "9th September 1990";
            ExisCustRememberMaster[ExisCustRememberMasterKey.Password] = "password";

            //Existing Customer details with MasterCard and don't remember payment details
            ExisCustDontRememberMaster[ExisCustDontRememberMasterKey.FirstName] = "test";
            ExisCustDontRememberMaster[ExisCustDontRememberMasterKey.LastName] = "dontremembermaster";
            ExisCustDontRememberMaster[ExisCustDontRememberMasterKey.Email] = "test.dontremember_visa@dev-rslqld.org";
            ExisCustDontRememberMaster[ExisCustDontRememberMasterKey.PhoneNumber] = "0765649899";
            ExisCustDontRememberMaster[ExisCustDontRememberMasterKey.Address] = "87 Eliza St KEILOR PARK VIC 3042 AUS";
            ExisCustDontRememberMaster[ExisCustDontRememberMasterKey.DOB] = "9th September 1990";
            ExisCustDontRememberMaster[ExisCustDontRememberMasterKey.Password] = "password";

            //Existing Customer details with Amex and remember payment details
            ExisCustRememberAmex[ExisCustRememberAmexKey.FirstName] = "Test";
            ExisCustRememberAmex[ExisCustRememberAmexKey.LastName] = "Rememberamex";
            ExisCustRememberAmex[ExisCustRememberAmexKey.Email] = "test.rememberamex@dev-rslqld.org";
            ExisCustRememberAmex[ExisCustRememberAmexKey.PhoneNumber] = "0765649899";
            ExisCustRememberAmex[ExisCustRememberAmexKey.Address] = "87 Eliza St KEILOR PARK VIC 3042 AUS";
            ExisCustRememberAmex[ExisCustRememberAmexKey.DOB] = "9th September 1990";
            ExisCustRememberAmex[ExisCustRememberAmexKey.Password] = "password";

            //Existing Customer details with Amex and don't remember payment details
            ExisCustDontRememberMaster[ExisCustDontRememberMasterKey.FirstName] = "test";
            ExisCustDontRememberMaster[ExisCustDontRememberMasterKey.LastName] = "dontrememberamex";
            ExisCustDontRememberMaster[ExisCustDontRememberMasterKey.Email] = "test.dontremember_visa@dev-rslqld.org";
            ExisCustDontRememberMaster[ExisCustDontRememberMasterKey.PhoneNumber] = "0765649899";
            ExisCustDontRememberMaster[ExisCustDontRememberMasterKey.Address] = "87 Eliza St KEILOR PARK VIC 3042 AUS";
            ExisCustDontRememberMaster[ExisCustDontRememberMasterKey.DOB] = "9th September 1990";
            ExisCustDontRememberMaster[ExisCustDontRememberMasterKey.Password] = "password";

            //Existing Customer details with Diners and remember payment details
            ExisCustRememberDiners[ExisCustRememberDinersKey.FirstName] = "Test";
            ExisCustRememberDiners[ExisCustRememberDinersKey.LastName] = "Rememberdiners";
            ExisCustRememberDiners[ExisCustRememberDinersKey.Email] = "test.rememberdiners@dev-rslqld.org";
            ExisCustRememberDiners[ExisCustRememberDinersKey.PhoneNumber] = "0765649899";
            ExisCustRememberDiners[ExisCustRememberDinersKey.Address] = "87 Eliza St KEILOR PARK VIC 3042 AUS";
            ExisCustRememberDiners[ExisCustRememberDinersKey.DOB] = "9th September 1990";
            ExisCustRememberDiners[ExisCustRememberDinersKey.Password] = "password";

            //Existing Customer details with Diners and don't remember payment details
            ExisCustDontRememberMaster[ExisCustDontRememberMasterKey.FirstName] = "test";
            ExisCustDontRememberMaster[ExisCustDontRememberMasterKey.LastName] = "dontrememberdiners";
            ExisCustDontRememberMaster[ExisCustDontRememberMasterKey.Email] = "test.dontremember_visa@dev-rslqld.org";
            ExisCustDontRememberMaster[ExisCustDontRememberMasterKey.PhoneNumber] = "0765649899";
            ExisCustDontRememberMaster[ExisCustDontRememberMasterKey.Address] = "87 Eliza St KEILOR PARK VIC 3042 AUS";
            ExisCustDontRememberMaster[ExisCustDontRememberMasterKey.DOB] = "9th September 1990";
            ExisCustDontRememberMaster[ExisCustDontRememberMasterKey.Password] = "password";

            //Existing Customer details with Paypal and remember payment details
            ExisCustRememberPaypal[ExisCustRememberPaypalKey.FirstName] = "Test";
            ExisCustRememberPaypal[ExisCustRememberPaypalKey.LastName] = "Rememberpaypal";
            ExisCustRememberPaypal[ExisCustRememberPaypalKey.Email] = "test.rememberpaypal@dev-rslqld.org";
            ExisCustRememberPaypal[ExisCustRememberPaypalKey.PhoneNumber] = "0765649899";
            ExisCustRememberPaypal[ExisCustRememberPaypalKey.Address] = "87 Eliza St KEILOR PARK VIC 3042 AUS";
            ExisCustRememberPaypal[ExisCustRememberPaypalKey.DOB] = "9th September 1990";
            ExisCustRememberPaypal[ExisCustRememberPaypalKey.Password] = "password";

            //Existing Customer details with Paypal and don't remember payment details
            ExisCustDontRememberPaypal[ExisCustDontRememberPaypalKey.FirstName] = "test";
            ExisCustDontRememberPaypal[ExisCustDontRememberPaypalKey.LastName] = "dontrememberpaypal";
            ExisCustDontRememberPaypal[ExisCustDontRememberPaypalKey.Email] = "test.dontremember_visa@dev-rslqld.org";
            ExisCustDontRememberPaypal[ExisCustDontRememberPaypalKey.PhoneNumber] = "0765649899";
            ExisCustDontRememberPaypal[ExisCustDontRememberPaypalKey.Address] = "87 Eliza St KEILOR PARK VIC 3042 AUS";
            ExisCustDontRememberPaypal[ExisCustDontRememberPaypalKey.DOB] = "9th September 1990";
            ExisCustDontRememberPaypal[ExisCustDontRememberPaypalKey.Password] = "password";
        }


        //This function creates a Gift customer data which can be used
        public static void CreateGiftCust()
        {
            //Generate Gift Order recipient Details            
            giftDetails[GiftDetailKey.FirstName] = "TestGift";
            giftDetails[GiftDetailKey.LastName] = Faker.NameFaker.LastName();
            giftDetails[GiftDetailKey.Email] = giftDetails[GiftDetailKey.FirstName] + '.' + giftDetails[GiftDetailKey.LastName] + "@rslqld.org";
            giftDetails[GiftDetailKey.PhoneNumber] = "0765649834";
            giftDetails[GiftDetailKey.Address] = "91 rue";
            giftDetails[GiftDetailKey.Message] = "This is a test gift for you.";
        }

        public static void CreateCreditCardData()
        {
            CreditCardNumber[CreditCardNumbersKey.AmexCard] = "378282246310005";
            CreditCardNumber[CreditCardNumbersKey.DinersClubCard] = "36259600000004";
            CreditCardNumber[CreditCardNumbersKey.DiscoverCard] = "6011111111111117";
            CreditCardNumber[CreditCardNumbersKey.VisaCard] = "4111111111111111";
            CreditCardNumber[CreditCardNumbersKey.MasterCard] = "2223000048400011";
            CreditCardNumber[CreditCardNumbersKey.ExpiryDate] =  "10/22";            
        }

        public static string ReturnCreditCardNumber(string pay_mehtod)
        {
            string credit_card_number = null;
            switch (pay_mehtod)
            {
                case "v":
                    credit_card_number = TestData.CreditCardNumber[CreditCardNumbersKey.VisaCard];
                    Console.WriteLine("   Credit Card number is " + credit_card_number);
                    break;

                case "m":
                    credit_card_number = TestData.CreditCardNumber[CreditCardNumbersKey.MasterCard];
                    Console.WriteLine("   Credit Card number is " + credit_card_number);
                    break;

                case "a":
                    credit_card_number = TestData.CreditCardNumber[CreditCardNumbersKey.AmexCard];
                    Console.WriteLine("   Credit Card number is " + credit_card_number);
                    break;

                case "d":
                    credit_card_number = TestData.CreditCardNumber[CreditCardNumbersKey.DinersClubCard];
                    Console.WriteLine("   Credit Card number is " + credit_card_number);
                    break;

                case "dis":
                    credit_card_number = TestData.CreditCardNumber[CreditCardNumbersKey.DiscoverCard];
                    Console.WriteLine("   Credit Card number is " + credit_card_number);
                    break;

                default:
                    Console.WriteLine("   Did not match any SwitchCase, so exiting the switch statement");
                    //return null;
                    break;
            }
            return credit_card_number;
        }

        public static string ReturnEmailAddress(string pay_mehtod, bool if_remember)
        {
            string email_address = null;

            if (pay_mehtod == "v" & if_remember == true)
                email_address = TestData.ExisCustRememberVisa[ExisCustRememberVisaKey.Email];
            else if (pay_mehtod == "v" & if_remember == false)
                email_address = TestData.ExisCustDontRememberVisa[ExisCustDontRememberVisaKey.Email];
            else if (pay_mehtod == "m" & if_remember == true)
                email_address = TestData.ExisCustRememberMaster[ExisCustRememberMasterKey.Email];
            else if (pay_mehtod == "m" & if_remember == false)
                email_address = TestData.ExisCustDontRememberVisa[ExisCustDontRememberVisaKey.Email];
            else if (pay_mehtod == "p" & if_remember == true)
                email_address = TestData.ExisCustRememberPaypal[ExisCustRememberPaypalKey.Email];
            else if (pay_mehtod == "p" & if_remember == false)
                email_address = TestData.ExisCustDontRememberVisa[ExisCustDontRememberVisaKey.Email];
            else if (pay_mehtod == "a" & if_remember == true)
                email_address = TestData.ExisCustRememberAmex[ExisCustRememberAmexKey.Email];
            else if (pay_mehtod == "a" & if_remember == false)
                email_address = TestData.ExisCustDontRememberVisa[ExisCustDontRememberVisaKey.Email];
            else if (pay_mehtod == "d" & if_remember == true)
                email_address = TestData.ExisCustRememberDiners[ExisCustRememberDinersKey.Email];
            else if (pay_mehtod == "d" & if_remember == false)
                email_address = TestData.ExisCustDontRememberVisa[ExisCustDontRememberVisaKey.Email];

            return email_address;
        }

        public static void WriteUserDataFile()
        {
            string filePath = "../../../RslWebAutomation/TestDataFile/user_data_test.csv";
            var separator = ",";
            //var sw = new StreamWriter(filePath, true);
            //var csvWriter = new CsvWriter(sw);
            //csvWriter.
            //File.CreateText(filePath))
            // Write the text to a new file named "WriteFile.txt".

            StringBuilder csvContent = new StringBuilder();
            foreach (var entry in giftDetails)
            {
                csvContent.Append(entry.Value + separator);
            }
            csvContent.Append(Environment.NewLine);
            File.AppendAllText(filePath, csvContent.ToString());
        }
    }
}



