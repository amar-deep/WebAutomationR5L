﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using RslWebAutomation.Utility;
using System.Runtime.InteropServices;
using System.Linq;
using System.Collections;
using OpenQA.Selenium.Chrome;


namespace RslWebAutomation.PageActions
{
    public class DynamicsFunctions : Driver
    {

        public DynamicsFunctions(IWebDriver Instance) : base(Instance)
        {

        }


        public static void Initialize(string url)
        {
            Instance = new ChromeDriver();
            Instance.Manage().Window.Maximize();
            Instance.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            Instance.Navigate().GoToUrl(url);
        }           

        public static void Acess_ERP_Website(string urlkey)
        {
            Initialize(urlkey);
            FunctionLibrary.Wait_For_Page_Load_To_Complete();
            Wait(TimeSpan.FromSeconds(2));
            Driver.Instance.Manage().Window.Maximize();            
        }

        public static void Enter_User_Name(string user_name)
        {
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(15));
            try
            {
                //Enter user name                
                IWebElement user_name_edit_box = wait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector("input[id='i0116']")));
                user_name_edit_box.Click();
                user_name_edit_box.SendKeys(user_name);

                user_name_edit_box.SendKeys(Keys.Enter);
                Wait(TimeSpan.FromSeconds(2));
            }
            catch (OpenQA.Selenium.WebDriverTimeoutException)
            {
                //Click on another account                                
                IWebElement another_account_display = wait.Until(ExpectedConditions.ElementToBeClickable(By.Id("otherTile")));
                another_account_display.Click();

                //Enter user name                
                IWebElement user_name_edit_box = wait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector("input[id='i0116']")));
                user_name_edit_box.Click();
                user_name_edit_box.SendKeys(user_name);
                user_name_edit_box.SendKeys(Keys.Enter);
                Wait(TimeSpan.FromSeconds(2));
            }
        }

        public static void Enter_Password(string password)
        {
            WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(15));
            IWebElement work_or_school_account_password = wait.Until<IWebElement>(d => d.FindElement(By.Id("passwordInput")));
            work_or_school_account_password.Clear();
            work_or_school_account_password.SendKeys(password);
            Wait(TimeSpan.FromSeconds(1));
        }

        public static void VerifyDynamicsHomePage()
        {
            WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(60));
            IWebElement financeAndOperations = Instance.FindElement(By.Id("NavBarDashboard_label"));
        }

        public static void ClickNoStayedSignIn()
        {
            WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(60));
            IWebElement NoStayedsignIn = Instance.FindElement(By.Id("idBtn_Back"));
            NoStayedsignIn.Click();
        }

        public static void Log_Into_ERP(string user_name, string password, string url)
        {
            
            Acess_ERP_Website(url);            
            Enter_User_Name(user_name);            
            Enter_Password(password);
            WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(15));
            //Click on New SiginButton
            try
            {
                Wait(TimeSpan.FromSeconds(1));
                
                IWebElement sign_in_button = wait.Until(ExpectedConditions.ElementToBeClickable(By.Id("submitButton")));
                Wait(TimeSpan.FromSeconds(3));
                sign_in_button.Click();                
            }
            catch (OpenQA.Selenium.WebDriverTimeoutException)
            {
                Wait(TimeSpan.FromSeconds(1));                
                IWebElement sign_in_button = wait.Until(ExpectedConditions.ElementIsVisible(By.Id("submitButton")));                
                sign_in_button.Click();
            }

            //Wait for page loading to complete
            Wait(TimeSpan.FromSeconds(2));
            FunctionLibrary.Wait_For_Page_Load_To_Complete();

            try
            {
                //Verify dynamics home page                
                IWebElement financeAndOperations = Instance.FindElement(By.Id("NavBarDashboard_label"));
            }            
            catch (OpenQA.Selenium.NoSuchElementException)
            {
                //login_page.ClickNoStayedSignIn();
                wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(60));
                IWebElement NoStayedsignIn = Instance.FindElement(By.Id("idBtn_Back"));
                NoStayedsignIn.Click();
            }
            Wait(TimeSpan.FromSeconds(2));
            FunctionLibrary.Wait_For_Page_Load_To_Complete();

            try
            {
                VerifyDynamicsHomePage();
            }

            //catch(OpenQA.Selenium.InvalidElementStateException)
            catch (OpenQA.Selenium.NoSuchElementException)
            {
                ClickNoStayedSignIn();
                FunctionLibrary.Wait_For_Page_Load_To_Complete();
            }
            //wait_For_Page_Load_To_Complete();
        }

        public static void Click_On_Module_Pane_Opener()
        {
            try
            {
                Wait(TimeSpan.FromSeconds(1));
                WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(60));
                IWebElement module_pane_opener = wait.Until(ExpectedConditions.ElementToBeClickable(By.ClassName("modulesPane-opener")));
                module_pane_opener.Click();
                IWebElement workSpaces = wait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector("div[title='Workspaces']")));

            }
            catch (OpenQA.Selenium.WebDriverTimeoutException)
            {
                Wait(TimeSpan.FromSeconds(1));
                WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(30));
                IWebElement module_pane_opener = wait.Until(ExpectedConditions.ElementToBeClickable(By.ClassName("modulesPane-opener")));
                module_pane_opener.Click();

                IWebElement workSpaces = wait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector("div[title='Workspaces']")));
            }

        }

        //Navigate to customer service page 
        public static void Click_On_A_Module(string modulename)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(60));
                IWebElement module_name = wait.Until(ExpectedConditions.ElementToBeClickable(By.LinkText(modulename)));
                module_name.Click();
                //Sometimes when we click on "Module pane opener", module is already clicked (this could be due to someother actions in the test)
                //So we are confirming that module options are displayed or not
                WebDriverWait wait_one = new WebDriverWait(Instance, TimeSpan.FromSeconds(10));
                IWebElement sub_menu = wait_one.Until(ExpectedConditions.ElementIsVisible(By.ClassName("dashboardTiles_wide")));
            }
            catch (OpenQA.Selenium.WebDriverTimeoutException)
            {
                Wait(TimeSpan.FromSeconds(3));
                //sometimes clicking on Modulepane is not working properly when the environment is slow, so re-attempting the action, if the issue happens
                WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(60));
                IWebElement module_pane_opener = wait.Until(ExpectedConditions.ElementToBeClickable(By.ClassName("modulesPane-opener")));
                module_pane_opener.Click();

                IWebElement module_name = wait.Until(ExpectedConditions.ElementToBeClickable(By.LinkText(modulename)));
                module_name.Click();
            }
        }

        public static void click_On_A_module_Option(string sub_menu_heading, string module_option)
        {
            //Trying this as we are experiencing trouble when dealing with "Sourcing and procurement"            
            FunctionLibrary.WaitForAjaxComplete(10);

            try
            {
                WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(5));
                IWebElement moduleoption = wait.Until(ExpectedConditions.ElementToBeClickable(By.LinkText(module_option)));
                moduleoption.Click();
            }
            catch (OpenQA.Selenium.WebDriverTimeoutException)
            {
                //If a submenu is not expanded, then the module option is Not available in the DOM and as a result we cannot click on it.
                //For example: If "Recuring Invoices" sub-menu  under "Accounts Receivable" is Not expanded, then an option (example: "Free text tax invoice templates") under it is Not avaible in DOM.
                //In this catch block we are expanding the "Sub menu" first and then clicking on the module option

                WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(30));

                IWebElement sub_menu_heading_link = wait.Until(ExpectedConditions.ElementToBeClickable(By.LinkText(sub_menu_heading)));
                Wait(TimeSpan.FromSeconds(2));
                sub_menu_heading_link.Click();

                IWebElement moduleoption = wait.Until(ExpectedConditions.ElementToBeClickable(By.LinkText(module_option)));
                moduleoption.Click();
            }
            FunctionLibrary.Wait_For_Page_Load_To_Complete();
            FunctionLibrary.WaitForAjaxComplete(30);

        }

        

        //Go to Customer Service

        public static void Enter_A_FilterCriteria_For_Searching(string search_by)
        {
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(15));
            IWebElement searchBox = wait.Until(ExpectedConditions.ElementToBeClickable(
                By.CssSelector("input[id^='mcrcustomerservice_'][id$='_CustSearchType_input']")));
            searchBox.Click();
            searchBox.SendKeys(search_by);
        }
        public static void Enter_Customers_Detail_In_Search_Box(string text_to_seatch)
        {
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(15));
            IWebElement searchBox = wait.Until(ExpectedConditions.ElementToBeClickable
                (By.CssSelector("input[id^='mcrcustomerservice_'][id$='_SearchText_input']")));
            searchBox.Click();
            searchBox.Clear();
            searchBox.SendKeys(text_to_seatch);
            Console.WriteLine("   Entered email in search box.");
        }

        public static void Click_On_Search_Button()
        {
            Console.WriteLine("Click on Search button");
            try
            {
                WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(15));
                IWebElement searchButton = wait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector("button[id^='mcrcustomerservice_'][id$='_CustSearch']")));
                searchButton.Click();

                IWebElement select_button = wait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector("button[id^='MCRCustSearch_'][id$='_ButtonSelect']")));
            }
            catch (OpenQA.Selenium.WebDriverTimeoutException)
            {
                WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(15));
                IWebElement searchButton = wait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector("button[id^='mcrcustomerservice_'][id$='_CustSearch']")));
                searchButton.Click();

                IWebElement select_button = wait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector("button[id^='MCRCustSearch_'][id$='_ButtonSelect']")));
            }
            Driver.Wait(TimeSpan.FromSeconds(2));
        }

        public static bool Click_On_Select_Button()
        {
            try
            {
                IWebElement cust_account_found = Instance.FindElement(
                By.XPath("//input[contains(@id, 'MCRCustSearchTable_CustAccount') and contains(@title,'C')]"));
                Boolean result = FunctionLibrary.IsElementPresent(By.CssSelector("button[id^='MCRCustSearch_'][id$='_ButtonSelect']"));
                // Boolean result = driver.FindElement(By.CssSelector("button[id^='MCRCustSearch_'][id$='_ButtonSelect']"));
                Console.WriteLine("result is" + result);

                int maxAttempts = 15;
                int loopCount = 1;
                //IWebElement select_button = driver.FindElement(By.CssSelector("button[id^='MCRCustSearch_'][id$='_ButtonSelect']"));
                while (result == true && loopCount <= maxAttempts)
                {
                    IWebElement select_button = Instance.FindElement(By.CssSelector("button[id^='MCRCustSearch_'][id$='_ButtonSelect']"));
                    select_button.Click();
                    loopCount++;
                    Driver.Wait(TimeSpan.FromSeconds(3));
                    //Boolean result = function_library.IsElementPresent(By.CssSelector("button[id^='MCRCustSearch_'][id$='_ButtonSelect']"));
                    result = FunctionLibrary.IsElementPresent(By.CssSelector("button[id^='MCRCustSearch_'][id$='_ButtonSelect']"));
                }
                return true;
            }
            catch(NoSuchElementException)
            {
                Console.WriteLine("---------------No record with found with email. Clicking Cancel button");
                IWebElement cancel_button = Instance.FindElement(By.CssSelector("button[id^='MCRCustSearch_'][id$='_ButtonCancel']"));
                cancel_button.Click();
                Driver.Wait(TimeSpan.FromSeconds(2));
                return false;
            }
            
        }

        ///Sales order Fasttab   
        public static void Expand_SalesOrder_FastTab_If_Collapsed()
        {
            WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(60));
            IWebElement salesOrderFastTabHeader = wait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector("header[id^='mcrcustomerservice_'][id$='_TabPageSalesOrderDetail_header']")));
            string salesOrderFastTabExpansionStatus = salesOrderFastTabHeader.GetAttribute("aria-expanded");
            if (salesOrderFastTabExpansionStatus == "true")
            {
                //Do nothing
            }
            else
            {
                IWebElement salesOrderFastTab = wait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector("h1[id^='mcrcustomerservice_'][id$='_TabPageSalesOrderDetail_caption']")));
                salesOrderFastTab.Click();
            }            
        }

        public static void Expand_SalesOrderLines_FastTab_If_Collapsed()
        {

            WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(60));
            IWebElement salesOrderLinesFastTabHeader = wait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector("header[id^='mcrcustomerservice_'][id$='_TabPageLinesDetail_header']")));
            string salesOrderLinesFastTabExpansionStatus = salesOrderLinesFastTabHeader.GetAttribute("aria-expanded");
            if (salesOrderLinesFastTabExpansionStatus == "true")
            {
                //Do nothing
            }
            else
            {
                IWebElement salesOrderLinesFastTab = wait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector("h1[id^='mcrcustomerservice_'][id$='_TabPageLinesDetail_caption']")));
                salesOrderLinesFastTab.Click();
            }
        }

        public static bool is_Sales_Order_Present(string ticket_numner)
        {
            bool sales_order_present = false;
            int sales_order_rows = Instance.FindElements(
                By.XPath("//div[contains(@id, 'mcrcustomerservice') and contains(@id,'SalesOrdersGrid_RowTemplate')]")).Count;

            var sales_order_row_checkboxes = Instance.FindElements(
                By.XPath("//div[contains(@id, 'mcrcustomerservice') and contains(@id,'SalesOrdersGrid_RowTemplate')]/div/span[@role='checkbox']"));
            //string sales_order_row_checkboxes_xpath = "//div[contains(@id, 'mcrcustomerservice') and contains(@id,'SalesOrdersGrid_RowTemplate')]/div/span[@role='checkbox']";

            for (int i=0; i<=(sales_order_rows-1);i++)
            {
                sales_order_row_checkboxes = Instance.FindElements(
                By.XPath("//div[contains(@id, 'mcrcustomerservice') and contains(@id,'SalesOrdersGrid_RowTemplate')]/div/span[@role='checkbox']"));
                Console.WriteLine("Checking the row " + (i+1));
                sales_order_row_checkboxes[i].Click();
                Wait(TimeSpan.FromSeconds(1));

                //Verify line order value
                if (is_Ticket_Number_In_Lines_Tab(ticket_numner))
                {
                    sales_order_present = true;
                    Console.WriteLine("Expected ticket number found");
                    break;
                }

                sales_order_row_checkboxes = Instance.FindElements(
                By.XPath("//div[contains(@id, 'mcrcustomerservice') and contains(@id,'SalesOrdersGrid_RowTemplate')]/div/span[@role='checkbox']"));
                Console.WriteLine("Unchecking the row " + (i+1));
                sales_order_row_checkboxes[i].Click();
                Wait(TimeSpan.FromSeconds(1));

            }
            return sales_order_present;
        }

        public static bool is_Ticket_Number_In_Lines_Tab(string ticket_number)
        {            
            try
            {
                IWebElement expected_ticket = Instance.FindElement(
                    By.XPath("//input[contains(@id,'mcrcustomerservice') and contains(@id,'SalesOrderLines_TicketNumber_input') and contains(@title,'" + ticket_number + "')]"));
                return true;
            }
            catch
            {
                Console.WriteLine("Ticket number not there in current sales order");
                return false;
            }
        }
    }
}
