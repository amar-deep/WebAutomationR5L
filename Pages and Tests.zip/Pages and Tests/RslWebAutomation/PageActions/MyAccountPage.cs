﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using RslWebAutomation.Utility;
using OpenQA.Selenium.Interactions;
using System.Runtime.InteropServices;
using System.Configuration;
using OpenQA.Selenium.Support.UI;

namespace RslWebAutomation.PageActions
{
    public class MyAccountPage : Driver
    {
        public MyAccountPage(IWebDriver Instance) : base(Instance)
        {

        }
        // Xpaths used in "UpdateBtn" method
        public static String DetailsUpdateBtnXpath = "//a[contains(@href,'details') and contains(text(),'Update')]";
        public static String PaymentUpdateBtnXpath = "//input[contains(@href,'payment') and contains(@value,'Update')]";
        
        public static String PasswdUpdateBtnXpath = "//a[@class='btn btn-rounded btn-navy js-btn-update-details']";

        public static String subscriptUpdateBtnXpath = "//*[@id='subscription']/div/div/div/div[3]/div/a";

        //below Variables used in "modifyBtn" method
        public static String DetailsModifyBtnXpath = "//div[@id='js-account-details-view']//a[contains(text(),'Modify')]";
        public static String PaymentModifyBtnXpath = "//div[@id='js-account-payment-view']//a[contains(text(),'Modify')]";

        public static String SignOutBtnXpath  = "//a[contains(text(),'Log Out')]";

        //Stores data for Details update
        public static Dictionary<String, string> DetailsUpdated = new Dictionary<String, string>();

        
        public static void Click(String ElementXpath)
        {
            if (Driver.Instance.FindElement(By.XPath(ElementXpath)).Displayed)
            {
                Driver.Wait(TimeSpan.FromSeconds(1));
                Driver.Instance.FindElement(By.XPath(ElementXpath)).Click();
            }
            else
            {
                ((IJavaScriptExecutor)Driver.Instance).ExecuteScript("arguments[0].scrollIntoView(false);", Driver.Instance.FindElement(By.XPath(ElementXpath)));
                Driver.Wait(TimeSpan.FromSeconds(1));
                Driver.Instance.FindElement(By.XPath(ElementXpath)).Click();
            }
        }


        public static void Input(String ElementXpath, String data)
        {
            if (Driver.Instance.FindElement(By.XPath(ElementXpath)).Displayed)
            {
                Driver.Instance.FindElement(By.XPath(ElementXpath)).SendKeys(data);
            }
            else
            {
                ((IJavaScriptExecutor)Driver.Instance).ExecuteScript("arguments[0].scrollIntoView(false);", Driver.Instance.FindElement(By.XPath(ElementXpath)));
                Driver.Wait(TimeSpan.FromSeconds(1));
                Driver.Instance.FindElement(By.XPath(ElementXpath)).SendKeys(data);
            }
        }
        
        public static void Clear(String ElementXpath)
        {
            if (Driver.Instance.FindElement(By.XPath(ElementXpath)).Displayed)
            {
                Driver.Instance.FindElement(By.XPath(ElementXpath)).Clear();
            }
            else
            {
                ((IJavaScriptExecutor)Driver.Instance).ExecuteScript("arguments[0].scrollIntoView(false);", Driver.Instance.FindElement(By.XPath(ElementXpath)));
                Driver.Wait(TimeSpan.FromSeconds(1));
                Driver.Instance.FindElement(By.XPath(ElementXpath)).Clear();
            }
        }


        public static String GetText(String ElementXpath)
        {
            return Driver.Instance.FindElement(By.XPath(ElementXpath)).Text;
        }


        public static Boolean isElementSelected(String ElementXpath)
        {

            if (Driver.Instance.FindElement(By.XPath(ElementXpath)).Selected)
                return true;
            else
                return false;
        }


        public static bool AlertUpdatedBox()
        {
            string alertText = GetText("//*[@id='modal-account-updated']/div/p");
            Console.WriteLine(alertText);

            if (!string.IsNullOrEmpty(alertText) && alertText.ToLower().Equals("details updated"))
            {
                Click("//*[@id='modal-account-updated']/div/a");
                return true;
            }
            else
            {
                Click("//*[@id='modal-account-updated']/div/a");
                return false;
            }
        }

        public static void Update_Payment_Method(string new_payment_method)
        {
            Navigation("Payment");
            UpdatePayment_Click_Modify_Button();
            if (new_payment_method == "p")
            {
                CheckoutPage.PaymentMethod_MyAccount_Page_Check_RadioButton_Paypal();
                CheckoutPage.EnterPaymentDetails_Paypal();
            }
            else
            {
                CheckoutPage.PaymentMethod_MyAccount_Page_Check_RadioButton_CreditCard();
                CheckoutPage.EnterPaymentDetails_CreditCard(TestData.ReturnCreditCardNumber(new_payment_method), false);
                UpdatePayment_Click_Update_Button();
            }
            
        }

        public static void Update_Address(string custAddr)
        {
            Navigation("details");
            UpdateDetails_Click_Modify_Button();

            IWebElement webAddress = Instance.FindElement(By.Id("AccountAddress"));

            webAddress.Clear();
            webAddress.SendKeys(custAddr);
            Wait(TimeSpan.FromSeconds(1));
            //Select address option with suburb Coorparoo in Customer Account Address suggestions
            if (custAddr.Contains("Rue"))
                CheckoutPage.selectOptionWithText("PETRIE", "Account");
            else if (custAddr.Contains("kealy"))
                CheckoutPage.selectOptionWithText("BENALLA", "Account");
            Wait(TimeSpan.FromSeconds(1));
            UpdateDetails_Click_Update_Button();
        }

        public static bool Verify_Address_Updated(string newAddress)
        {
            IWebElement updatedAddress = Instance.FindElement(By.XPath("//strong[@class='account-address']"));
            if (updatedAddress.Text.Contains(newAddress))
                return true;
            else
                return false;
        }

        public static bool Verify_Details_Updated_Succesfully()
        {            
            Driver.Wait(TimeSpan.FromSeconds(2));
            string details_updated_modal_xpath = "//*[@id='modal-account-updated' and @class='modal']/div/h4[@class='message-heading-success']";
            try
            {                
                IWebElement details_updated_modal = Instance.FindElement(By.XPath(details_updated_modal_xpath));
                Driver.Wait(TimeSpan.FromSeconds(1));
                return true;
            }
            catch
            {
                Console.WriteLine("   Details not updated or Details updated modal text is wrong");
               return false;
            }
        }

        public static void Click_Ok_Button_On_Modal_Details_Updated()
        {
            IWebElement ok_button = Instance.FindElement(
                By.XPath("//*[@id='modal-account-updated' and @class='modal']//a[contains(text(),'OK')]"));
            ok_button.Click();
            Driver.Wait(TimeSpan.FromSeconds(1));
        }

        public static bool formValidation(String fieldValidation)
        {

            IList<IWebElement> formErrorElements = Driver.Instance.FindElements(
                By.XPath("//span[@class='field-validation-error']"));

            if (formErrorElements.Count > 0)
            {

                for (int i = 0; i < formErrorElements.Count; i++)
                {

                    String script = "return $('.field-validation-error')[" + i + "].innerText";

                    String errorMsg = (String)((IJavaScriptExecutor)Driver.Instance).ExecuteScript(script);

                    Console.WriteLine(errorMsg);
                }

                return false;
            }

            return true;

        }


        public static void DetailsBeforeUpdate()
        {            
            //MyAccountPage.DetailsUpdated.Add("NameBefore", GetText("//*[@id='js-details-view']/div[1]/div/strong"));
            MyAccountPage.DetailsUpdated.Add("NameBefore", GetText("//*[@class='account-name']"));
            MyAccountPage.DetailsUpdated.Add("PhNumBefore", GetText("//*[@class='account-home-phone']"));
            MyAccountPage.DetailsUpdated.Add("EmailBefore", GetText("//*[@class='account-email']"));
            MyAccountPage.DetailsUpdated.Add("AddressBefore", GetText("//*[@class='account-address']"));
            MyAccountPage.DetailsUpdated.Add("DOBBefore", GetText("//*[@class='account-dob']"));
            Console.WriteLine("\n");

            foreach (KeyValuePair<String, String> item in MyAccountPage.DetailsUpdated)
            {
                if (item.ToString().Contains("Before"))
                {
                    Console.WriteLine(item.Key + ": " + MyAccountPage.DetailsUpdated[item.Key]);
                }
            }            
            Console.WriteLine("   -----------------------");
        }


        public static void DetailsInput(Dictionary<TestData.CustomerDetailsKey, String> data)
        {
            foreach (TestData.CustomerDetailsKey key in Enum.GetValues(typeof(TestData.CustomerDetailsKey)))
            {
                Driver.Wait(TimeSpan.FromSeconds(1));

                //Console.WriteLine(key.ToString().ToLower());

                switch (key.ToString().ToLower())
                {
                    case "firstname":                        
                        Clear("//*[@id='AccountFirstName']");
                        Input("//*[@id='AccountFirstName']", data[key]);
                        break;

                    case "lastname":                        
                        Clear("//*[@id='AccountLastName']");
                        Input("//*[@id='AccountLastName']", data[key]);
                        break;

                    case "phonenumber":                        
                        Clear("//*[@id='AccountHomePhoneNumber']");
                        Input("//*[@id='AccountHomePhoneNumber']", data[key]);
                        break;

                    case "email":                       
                        Clear("//*[@id='UpdateAccountEmailAddress']");
                        Input("//*[@id='UpdateAccountEmailAddress']", data[key]);
                        break;

                    case "address":                       
                        Clear("//*[@id='account-address']");
                        Input("//*[@id='account-address']", data[key]);
                        break;

                    case "day":                       
                        Clear("//*[@id='AccountDOBDay']");
                        Input("//*[@id='AccountDOBDay']", data[key]);
                        break;

                    case "month":                        
                        Clear("//*[@id='AccountDOBMonth']");
                        Input("//*[@id='AccountDOBMonth']", data[key]);
                        break;

                    case "year":                       
                        Clear("//*[@id='AccountDOBYear']");
                        Input("//*[@id='AccountDOBYear']", data[key]);
                        break;
                }
            }
        }


        public static Boolean ValidateDetailsAfterUpdate()
        {

            Console.WriteLine("\n");

            Boolean nameUpdate, phNumUpdate, EmailUpdate, AddUpdate, dobUpdate;
            nameUpdate = phNumUpdate = EmailUpdate = AddUpdate = dobUpdate = false;

            MyAccountPage.DetailsUpdated.Add("NameAfter", GetText("//*[@id='js-details-view']/div[1]/div/strong"));
            MyAccountPage.DetailsUpdated.Add("PhNumAfter", GetText("//*[@id='js-details-view']/div[2]/div[1]/strong"));
            MyAccountPage.DetailsUpdated.Add("EmailAfter", GetText("//*[@id='js-details-view']/div[2]/div[2]/strong"));
            MyAccountPage.DetailsUpdated.Add("AddressAfter", GetText("//*[@id='js-details-view']/div[3]/div/strong"));
            MyAccountPage.DetailsUpdated.Add("DOBAfter", GetText("//*[@id='js-details-view']/div[4]/div/strong"));
            
            foreach (KeyValuePair<String, String> item in MyAccountPage.DetailsUpdated)
            {
                if (item.ToString().Contains("After"))
                {
                    Console.WriteLine(item.Key + ": " + MyAccountPage.DetailsUpdated[item.Key]);
                }
                
                switch (MyAccountPage.DetailsUpdated[item.Key])
                {
                    case "NameAfter":
                        if (!item.Value.ToLower().Equals(MyAccountPage.DetailsUpdated["NameAfter"].ToLower()))
                            nameUpdate = true;
                        break;
                    case "PhNumAfter":
                        if (!item.Value.ToLower().Equals(MyAccountPage.DetailsUpdated["PhNumAfter"].ToLower()))
                            phNumUpdate = true;
                        break;
                    case "EmailAfter":
                        if (!item.Value.ToLower().Equals(MyAccountPage.DetailsUpdated["EmailAfter"].ToLower()))
                            EmailUpdate = true;
                        break;
                    case "AddressAfter":
                        if (!item.Value.ToLower().Equals(MyAccountPage.DetailsUpdated["AddressAfter"].ToLower()))
                            AddUpdate = true;
                        break;
                    case "DOBAfter":
                        if (!item.Value.ToLower().Equals(MyAccountPage.DetailsUpdated["DOBAfter"].ToLower()))
                            dobUpdate = true;
                        break;

                }
            }
            
            if (nameUpdate || phNumUpdate || EmailUpdate || AddUpdate || dobUpdate)
                return true;
            else
                return false;
        }


        public static void Navigation(String navigateTo)
        {
            IWebElement navigate_element = null;
            try
            {
                navigate_element = Driver.Instance.FindElement(
                    By.XPath("//*[@id='js-prize-navigator']/div/nav/ul/li/a[contains(text(),'" + navigateTo + "')]"));
                navigate_element.Click();
            }
            catch
            {
                Console.WriteLine("   Element not find on My Account page. Please check if xpath is incorrect or it is defect");
            }
            Driver.Wait(TimeSpan.FromSeconds(1));
        }

        

        


        public static void SelectSubscription(String Newsubsc)
        {
            String ExistingselectedSubsc = GetText("//div[@class='tickets-selected']").Substring(0, (GetText("//div[@class='tickets-selected']").Length - 22));
            String ticketSelectorXpath_1 = "//*[@id='vip-ticket-selector']/section/div[1]/div[1]/div[";
            int NumOfDraw = Driver.Instance.FindElements(By.XPath("//*[@id='vip-ticket-selector']/section/div[1]/div[1]/div")).Count();
            
            if (Newsubsc.Substring(1).Equals(ExistingselectedSubsc.Substring(1)))
            {
                return;
            }
            else if (Int32.Parse(Newsubsc.Substring(1)) < Int32.Parse(ExistingselectedSubsc.Substring(1)))
            {
                for (int i = ( GetSelectedSubScPosition(ExistingselectedSubsc, NumOfDraw) - 1 ); i > 0; i-- )
                {
                    Driver.Wait(TimeSpan.FromSeconds(1));
                    if (GetText(ticketSelectorXpath_1 + i + "]/a/div[1]").Equals(Newsubsc))
                    {
                        //Console.WriteLine(Driver.Instance.FindElement(By.XPath(ticketSelectorXpath_1 + i + "]/a/div[1]")).Text);
                        Click(ticketSelectorXpath_1 + i + "]/a/span");
                        Driver.Wait(TimeSpan.FromSeconds(1));
                        break;
                    }
                    else
                    {
                        Click("//div[@class='swiper-button-prev swiper-button-white']");
                    }
                }
            }
            else if (Int32.Parse(Newsubsc.Substring(1)) > Int32.Parse(ExistingselectedSubsc.Substring(1)))
            {
                for (int i = (GetSelectedSubScPosition(ExistingselectedSubsc, NumOfDraw) + 1); i <= NumOfDraw; i++)
                {
                    Driver.Wait(TimeSpan.FromSeconds(1));
                    if (GetText(ticketSelectorXpath_1 + i + "]/a/div[1]").Equals(Newsubsc))
                    {
                        //Console.WriteLine(Driver.Instance.FindElement(By.XPath(ticketSelectorXpath_1 + i + "]/a/div[1]")).Text);
                        Click(ticketSelectorXpath_1 + i + "]/a/span");
                        Driver.Wait(TimeSpan.FromSeconds(1));
                        break;
                    }
                    else
                    {
                        Click("//div[@class='swiper-button-next swiper-button-white']");
                    }
                }
            }            
        }


        public static int GetSelectedSubScPosition(String ExistingSelectedSubSc, int NumOfDraw)
        {
            int i = 1;
            foreach (int loop in Enumerable.Range(1, NumOfDraw))
            {
                if (GetText("//*[@id='vip-ticket-selector']/section/div[1]/div[1]/div[" + i + "]/a/div[1]").Equals(ExistingSelectedSubSc))
                {
                    return i;
                }
                i++;
            }
            return -1;
        }


        public static Boolean ValidateSelectedSubSc(String NewSubSc)
        {

            String SelectedSubSc = GetText("//div[@class='tickets-selected']").Substring(0, (GetText("//div[@class='tickets-selected']").Length - 22));

            if (NewSubSc.Equals(SelectedSubSc))
                return true;
            else
                return false;
        }


        public static void UpdatePaymentMethod(String PaymentType, [Optional] String CCNum, [Optional] String CCName, [Optional]  String ExpDate)
        {

            if (PaymentType.ToLower().Equals("paypal"))
            {
                if (isElementSelected("//*[@id='js-payment-edit']/div[1]/div[3]/div[1]/label/span[1]"))
                {
                    Console.WriteLine("   already selected");
                }
                else
                {
                    Click("//*[@id='js-payment-edit']/div[1]/div[3]/div[1]/label/span[1]");

                    if (!isElementSelected("//*[@id='js-payment-edit']/div[1]/div[3]/div[2]/div/div/div/label/span[1]"))
                    {
                        Click("//*[@id='js-payment-edit']/div[1]/div[3]/div[2]/div/div/div/label/span[1]");
                    }
                }
            }
            else if (PaymentType.ToLower().Equals("new credit card"))
            {
                if (isElementSelected("//*[@id='js-payment-edit']/div[1]/div[2]/div[1]/label/span[1]"))
                {
                    Console.WriteLine("   already selected");
                }
                else
                {
                    Click("//*[@id='js-payment-edit']/div[1]/div[2]/div[1]/label/span[1]");
                    Input("//*[@id='Credit-card-number']", CCNum);
                    Console.WriteLine("   Credit Card Number: " + CCNum);
                    Input("//*[@id='Credit-card-name']", CCName);
                    Console.WriteLine("   Credit Card Number: " + CCName);
                    Input("//*[@id='Credit-card-expiry']", ExpDate);
                    Console.WriteLine("   Credit Card Number: " + ExpDate);
                }
            }
        }
        

        public static bool ValidateStoredPaymentMethod(string pay_method, bool stored_funding)
        {
            String storedPaymentText = GetText("//*[@id='js-account-payment-view']");

            if (!stored_funding)
            {
                if (storedPaymentText.Contains("You do not currently have a stored funding source"))
                {
                    Console.WriteLine("   No payment stored as expected");
                    return true;
                }
                else
                {
                    Console.WriteLine("   Error in not stored payment text");
                    return false;
                }
                    
            }
            else
            {
                //Validate paypal stored
                if (pay_method == "p")
                {
                    if (storedPaymentText.Contains("Stored PayPal account using it.support-buyer@rslqld.org"))
                    {
                        Console.WriteLine("   payment stored paypal and details match as expected");
                        return true;
                    }
                    else
                    {
                        Console.WriteLine("   Error in stored payment text for paypal");
                        return false;
                    }
                        
                }
                //Validate Credit card number
                else
                {
                    string CCNum = TestData.ReturnCreditCardNumber(pay_method);
                    String Expected_last4Digits = CCNum.Substring(CCNum.Length - 4);
                    String pattern = @"\d+";
                    String Stored_last4Digit = null;

                    foreach (Match m in Regex.Matches(storedPaymentText, pattern))
                    {
                        Console.WriteLine(m.Value + "  " + m);
                        //Console.WriteLine("   '{0}' found at index {1}.", m.Value, m.Index);
                        Stored_last4Digit = m.Value;
                    }

                    if (Expected_last4Digits.Equals(Stored_last4Digit))
                    {
                        Console.WriteLine("   Credit card last 4 digits match stored number");
                        return true;
                    }                        
                    else
                    {
                        Console.WriteLine("   Error. Credit card last 4 digits does not match stored number");
                        return false;
                    }                        
                }
            }
          
        }


        public static void UpdatePassword_Enter_Password_Values(string OldPassword, string NewPassword, string confirmNewPassword)
        {
            Input("//*[@id='account-old-password']", OldPassword);
            Click("//*[@id='showOldPassword']");

            Input("//*[@id='account-new-password']", NewPassword);
            Click("//*[@id='showNewPassword']");

            Input("//*[@id='account-new-password-confirm']", confirmNewPassword);
            Click("//*[@id='showConfirmPassword']");

            Console.WriteLine("   Values added: OldPassword {0}, NewPassword {1}, ConfirmPassword {2}", OldPassword, NewPassword, confirmNewPassword);

            Driver.Wait(TimeSpan.FromSeconds(1));
        }

        public static void UpdatePassword_Click_Update_Button()
        {
            Click(PasswdUpdateBtnXpath);
            Console.WriteLine("   Clicked in update password");
        }

        public static void UpdateDetails_Click_Modify_Button()
        {
            Click(DetailsModifyBtnXpath);
            Console.WriteLine("   Clicked on Modify button to update details");
        }

        public static void UpdateDetails_Click_Update_Button()
        {
            Click(DetailsUpdateBtnXpath);
            Console.WriteLine("   Clicked in update password");
        }

        public static void UpdatePayment_Click_Modify_Button()
        {
            Click(PaymentModifyBtnXpath);
            Console.WriteLine("   Clicked on Modify button to update details");
        }

        public static void UpdatePayment_Click_Update_Button()
        {
            Click(PaymentUpdateBtnXpath);
            Console.WriteLine("   Clicked in update password");
        }        
        
        
        public static Boolean ValidateTicketDetailsInOrderHistory()
        {
            Console.WriteLine("   ************* Submitted Order Details *************");

            Console.WriteLine("   Selected Draw Number in Order Summary: " + TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber].ToLower());

            Console.WriteLine("   Selected Ticket Number in Order Submit: " + TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber].ToLower());

            if (!Utility.Utility.isElementPresent("//*[@id='Order history']/div[2]/div"))
            {

                String DrawNum = GetText("//*[@id='order-history']/div/div/div[1]/div[2]/div[3]");

                String TicketNum = GetText("//*[@id='order-history']/div/div/div[1]/div[2]/div[2]");

                


                Boolean ValidateOrderTicket, ValidateOrderTitle;

                ValidateOrderTicket = ValidateOrderTitle = false;

                if (DrawNum.ToLower().Contains(TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber].ToLower()))
                {
                    ValidateOrderTicket = true;
                }

                if (TicketNum.ToLower().Equals(TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber].ToLower()))
                {
                    ValidateOrderTitle = true;
                }

                if (ValidateOrderTicket && ValidateOrderTitle)
                {
                    Console.WriteLine("   ************* Matched Order Details from History *************");

                    Console.WriteLine("   DrawNumber in Order History: " + DrawNum.ToLower());

                    Console.WriteLine("   Ticketnumber in Order History: " + TicketNum);

                    return true;
                }else
                {
                    Console.WriteLine("   ************* Not Matched Order Details from History *************");

                    Console.WriteLine("   DrawNumber in Order History: " + DrawNum.ToLower());

                    Console.WriteLine("   Ticketnumber in Order History: " + TicketNum);

                    return false;
                }

            }
            else
            {
                Console.WriteLine("   ************* No Orders found *************");

                return false;
            }
                
        }


        public static Boolean ValidateStoredPayment(String CCNum, String paymentType)
        {

            if (paymentType.Equals("new credit card"))
            {

                String last4Digits = CCNum.Substring(CCNum.Length - 4);

                String storedCardText = GetText("//*[@id='js-payment-view']");

                String pattern = @"\d+";

                String Stored4Digit = null;

                foreach (Match m in Regex.Matches(storedCardText, pattern))
                {
                    //Console.WriteLine("   '{0}' found at index {1}.", m.Value, m.Index);
                    Stored4Digit = m.Value;

                }


                if (last4Digits.Equals(Stored4Digit))
                    return true;
                else
                    return false;
            }
            return false;

        }


        public static Boolean ValidateVIPStatus()
        {

            String selectText = GetText("//*[@id='vip-ticket-selector']/div/div[2]");

            Console.WriteLine("   Default Subscription: " + selectText);

            if (selectText.ToLower().Contains("subscription selected"))
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public static void SignOut()
        {
            Navigation("Overview");
            Click(SignOutBtnXpath);
            Thread.Sleep(1000);
            Console.WriteLine("   Signed Out");
        }
                
        

    }
}


