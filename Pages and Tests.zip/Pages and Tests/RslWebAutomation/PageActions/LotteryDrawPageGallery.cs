﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support;
using OpenQA.Selenium.Interactions;
using System.Threading;
using RslWebAutomation;

namespace RslWebAutomation
{
    public class LotteryDrawPageGallery : Driver
    {
        [FindsBy(How = How.XPath, Using = "//*[@id='home']/div[3]/section/div/div[1]/div/div[1]/div[10]/a[contains(@href, '.jpg')]")]
        public static IWebElement photoVerificationLocator;

        [FindsBy(How = How.LinkText, Using = "Lottery Draw page")]
        private static IWebElement lotteryDrawPageURLlink;



        public LotteryDrawPageGallery(IWebDriver Instance) : base(Instance)
        {

        }

        public static void OpenSapientPreviewPage()
        {

            Driver.Instance.Navigate().GoToUrl("http://rsl:r5lprototype@preview.sapientnitro.com.au/rsl/");

        }

        public static void OpenLotteryDrawPage()
        {

            Instance.FindElement(By.LinkText("Lottery Draw page")).Click();

        }


        public static Boolean OpenGallerySection()
        {
                        
            Driver.Instance.FindElement(By.XPath("//*[@id='js-prize-navigator']//nav[@role='navigation']//a[@class='js-trigger'][@href='#gallery'][@data-title='Gallery']")).Click();
            bool res = Driver.Instance.FindElement(By.XPath("//div[@id='app-container']//div[@class='header-btn']/a[@class='btn btn-primary btn-red'][text()='Buy tickets']")).Displayed;
            
            return res;
        }

        public static Boolean ClickRightArrow()
        {
           
            IWebElement rightArrowElement = Driver.Instance.FindElement(By.XPath("//*[@id='home']//section[@class='prize-gallery']//div[@class='swiper-button-next swiper-button-white']"));
            Driver.Instance.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            LotteryDrawPageGallery.ScrollDown(rightArrowElement);
            if (rightArrowElement.Displayed)
            {
                rightArrowElement.Click();
                return true;
            }
            else return false;
        }

        public static Boolean ClickPhotoGallery()
        {
           
            IWebElement photoGallery = Driver.Instance.FindElement(By.XPath("//*[@id='home']//nav[@role='navigation']//a[@class='photos active js-prize-gallery-nav'][text()='Photos']"));
            Driver.Instance.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            LotteryDrawPageGallery.ScrollDown(photoGallery);

            //((IJavaScriptExecutor) Driver.Instance).ExecuteScript("arguments[0].scrollBy(0,250);", photoGallery);
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(10));
            wait.Until(ExpectedConditions.ElementToBeClickable(photoGallery));

            Utility.Utility.CheckforElementAndClick(photoGallery);
            photoVerificationLocator = Driver.Instance.FindElement(By.XPath("//*[@id='home']/div[3]/section/div/div[1]/div/div[1]/div[10]/a[contains(@href, '.jpg')]/img"));
            //return Utility.Utility.CheckforElementAndClick(photoGallery, photoVerificationLocator);           
            return photoVerificationLocator.Enabled;

        }

        public static bool ClickVideoGallery()
        {
           
            IWebElement videoGallery = Driver.Instance.FindElement(By.XPath("//*[@id='home']//nav[@role='navigation']//a[@class='videos js-prize-gallery-nav'][text()='Videos']"));
            Driver.Instance.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            LotteryDrawPageGallery.ScrollDown(videoGallery);

            //videoGallery.Click();
            //return Driver.Instance.FindElement(By.XPath("//*[@id='home']/div[3]/section/div/div[1]/div/div[1]//div[@data-nav='videos']")).Displayed;

            Utility.Utility.CheckforElementAndClick(videoGallery);
            IWebElement videoVerificationLocator = Instance.FindElement(By.XPath("//*[@id='home']/div[3]/section/div/div[1]/div/div[1]//div[@data-nav='videos']"));
            //return Utility.Utility.CheckforElementAndClick(videoGallery, videoVerificationLocator);
            return videoVerificationLocator.Enabled;

        }

        public static bool ClickVitualTourGallery()
        {
            
            IWebElement virtualTourGallery = Driver.Instance.FindElement(By.XPath("//*[@id='home']//nav[@role='navigation']//a[@class='virtual js-prize-gallery-nav'][text()='Virtual tour']"));
            Driver.Instance.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            LotteryDrawPageGallery.ScrollDown(virtualTourGallery);

            //virtualTourGallery.Click();
            //return Instance.FindElement(By.XPath("//*[@id='home']/div[3]/section/div/div[1]/div/div[1]/div[8]/div/iframe[contains(@src ,'panedia')]")).Displayed;

            Utility.Utility.CheckforElementAndClick(virtualTourGallery);
            IWebElement virtualVerificationLocator = Instance.FindElement(By.XPath("//*[@id='home']/div[3]/section/div/div[1]/div/div[1]/div[8]/div/iframe[contains(@src ,'panedia')]"));
            //return Utility.Utility.CheckforElementAndClick(virtualTourGallery, virtualVerificationLocator);
            return virtualVerificationLocator.Enabled;

        }

        public static bool ClickFloorPlanGallery()
        {
            
            IWebElement floorPlanGallery = Driver.Instance.FindElement(By.XPath("//*[@id='home']//nav[@role='navigation']//a[@class='floor js-prize-gallery-nav'][text()='Floor plan']"));
            Driver.Instance.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            LotteryDrawPageGallery.ScrollDown(floorPlanGallery);

            //floorPlanGallery.Click();
            //return Instance.FindElement(By.XPath("//*[@id='home']/div[3]/section/div/div[1]/div/div[1]/div[contains(@data-nav,'floor')][contains(@class, 'swiper-slide swiper-slide-active')]")).Displayed;

            Utility.Utility.CheckforElementAndClick(floorPlanGallery);
            IWebElement floorplanVerificationLocator = Instance.FindElement(By.XPath("//*[@id='home']/div[3]/section/div/div[1]/div/div[1]//div[contains(@class, 'swiper-slide swiper-slide-active')][contains(@data-nav,'floor')][contains(@data-nav,'floor')]"));
            return floorplanVerificationLocator.Enabled;

        }

        public static IWebDriver ScrollDown(IWebElement actionElement)
        {
            Actions act = new Actions(Driver.Instance);
            
            act.SendKeys(Keys.PageDown).Perform();
            act.MoveToElement(actionElement).Click().Build().Perform();
            ((IJavaScriptExecutor)Driver.Instance).ExecuteScript("arguments[0].scrollIntoView(false);", actionElement);
            Thread.Sleep(5000);
            Driver.Instance.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            return Instance;
        }


    }
}
