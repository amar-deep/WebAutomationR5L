﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support;
using OpenQA.Selenium.Interactions;
using System.Threading;
using RslWebAutomation;
using RslWebAutomation.Utility;

namespace RslWebAutomation.PageActions
{
    public class JoinVIPPage : Driver
    {
        public JoinVIPPage(IWebDriver Instance) : base(Instance)
        {

        }


        public static void NavigateAllPages()
        {
            Driver.Instance.Navigate().GoToUrl(Driver.BaseUrl);
            TopNavigation.SelectSubMenu("VIPClub", "JoinVIPClub");
            Driver.Wait(TimeSpan.FromSeconds(1));
            //TopNavigation.SelectSubMenu("Prizes", "Draw 347");
            TopNavigation.SelectSubMenu("Winners", "DrawWinner");
            TopNavigation.SelectSubMenu("AboutUs", "Careers");

            Driver.Wait(TimeSpan.FromSeconds(3));
            //TopNavigation.BuyTickets.GoTo();

        }

        //This method selects the Subscription Start Date.The parameter would to 
        public static void SelectSubscription(int indexoDrawRadio)
        {


            IWebElement selectSubscription = Driver.Instance.FindElement(
                By.XPath("//*[@id='app-container']//div[2]/div//div[2]//div[" + indexoDrawRadio + "]//label[1][@class='custom-control custom-radio']"));
            string drawNumber = selectSubscription.Text.Split(':')[0];


            TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber] = selectSubscription.Text.Split(':')[0];

            //TestData.orderDetails["DrawStartDate"] = Driver.Instance.FindElement(By.XPath("//*[@id='app-container']//div[2]/div//div[2]//div[2]//label[1][@class='custom-control custom-radio']//strong")).Text;

            TestData.orderDetails[TestData.OrderDetailsKey.DrawDate] = Driver.Instance.FindElement(By.XPath("//*[@id='app-container']//div[2]/div//div[2]//div[2]//label[1][@class='custom-control custom-radio']//strong")).Text;
            bool isSelectSubDisplay = selectSubscription.Displayed;
            selectSubscription.Click();
            //return drawNumber;
        }


        public static void Goto_Join_VIP_Club_Page()
        {
            TopNavigation.SelectSubMenu("VIPClub", "JoinVIPClub");
            Driver.Instance.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(30);

        }


        public static void SelectSubscription(string subscription_to_select)
        {
            Console.WriteLine(Driver.Instance.Url + "  : is the current page URL");
            Console.WriteLine(Driver.Instance.Title + " : is the window title");
            Driver.Instance.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);

            try
            {
                IWebElement VIP_Draw_link = Driver.Instance.FindElement(
                By.XPath("//div[@id='vip-ticket-selector']//div[@class='price' and text()='" + subscription_to_select + "']"));
                Console.WriteLine("   VIP order selected  " + subscription_to_select);
                VIP_Draw_link.Click();
                Driver.Wait(TimeSpan.FromSeconds(2));
            }
            //Scroll left and right in case element is not visible
            catch (Exception)
            {
                //Scroll left first
                try
                {
                    //Scroll left code
                    IWebElement prevSwiper = Driver.Instance.FindElement(
                        By.XPath("//div[@id='vip-ticket-selector']//div[@class='swiper-button-prev swiper-button-white']"));
                    prevSwiper.Click();
                    Driver.Wait(TimeSpan.FromSeconds(1));
                    prevSwiper.Click();
                    Driver.Wait(TimeSpan.FromSeconds(1));
                    //Find element and click
                    IWebElement VIP_Draw_link = Driver.Instance.FindElement(
                    By.XPath("//div[@id='vip-ticket-selector']//div[@class='price' and text()='" + subscription_to_select + "']"));

                    Console.WriteLine("   Ticket link found");
                    Console.WriteLine("   VIP order selected  " + subscription_to_select);
                    VIP_Draw_link.Click();
                    Driver.Wait(TimeSpan.FromSeconds(2));
                }
                //Scroll right if element is not visible after scrolling left
                catch (Exception)
                {
                    //Scroll right code
                    IWebElement nextSwiper = Driver.Instance.FindElement(
                        By.XPath("//div[@id='vip-ticket-selector']//div[@class='swiper-button-next swiper-button-white']"));
                    nextSwiper.Click();
                    Driver.Wait(TimeSpan.FromSeconds(1));
                    nextSwiper.Click();
                    Driver.Wait(TimeSpan.FromSeconds(1));
                    nextSwiper.Click();
                    Driver.Wait(TimeSpan.FromSeconds(1));
                    nextSwiper.Click();
                    Driver.Wait(TimeSpan.FromSeconds(1));
                    //Find element and click
                    IWebElement VIP_Draw_link = Driver.Instance.FindElement(
                    By.XPath("//div[@id='vip-ticket-selector']//div[@class='price' and text()='" + subscription_to_select + "']"));

                    Console.WriteLine("   Ticket link found");
                    Console.WriteLine("   VIP order selected  " + subscription_to_select);
                    VIP_Draw_link.Click();
                    Driver.Wait(TimeSpan.FromSeconds(2));
                }
            }
        }

        public static void Verify_Order_Summary(string subscription_selected)
        {
            try
            {
                IWebElement OrderSummary_Value_Locator = Driver.Instance.FindElement(
                    By.XPath("//td[@class='order-summary-item-description']/div/span[@class='selection']"));

                IWebElement OrderSummary_DrawTitle_Locator = Driver.Instance.FindElement(
                    By.XPath("//tr[@class='order-vip-start']//span[@class='js-draw-title']"));

                string actualOrderSummaryValue = OrderSummary_Value_Locator.Text;
                string actualOrderSummaryDrawNumber = OrderSummary_DrawTitle_Locator.Text;

                if (actualOrderSummaryValue.Contains(subscription_selected))
                {
                    Console.WriteLine("   Order Summary showing correct subscription selected: " + subscription_selected);
                }
                else
                {
                    Console.WriteLine("   Error. Order Summary showing incorrect subscription: " + actualOrderSummaryValue);
                }

                string expected_DrawNumber = TestData.draws_live[0];

                if (actualOrderSummaryDrawNumber.Contains(expected_DrawNumber))
                {
                    Console.WriteLine("   Order Summary showing correct draw number: " + expected_DrawNumber);
                }
                else
                {
                    Console.WriteLine("   Error. Order Summary showing incorrect draw number: " + actualOrderSummaryDrawNumber);
                }
            }
            catch
            {
                Console.WriteLine("   ----Error----. Order Summary at first step is not displayed or draw number/value is not displayed within");
            }
        }

        public static void Click_JoinNow()
        {
            IWebElement joinNowButton = Driver.Instance.FindElement(
                By.XPath("//div/a[text()='JOIN NOW']"));
            joinNowButton.Click();

            Driver.Instance.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(30);
        }

        //This method adds new customer details in step 3
        public static bool FeedNewCustomerContactDetails()
        {
            WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(30));

            wait.Until(ExpectedConditions.ElementToBeClickable(By.Id("btnContinueDetails")));

            IWebElement firstName = Instance.FindElement(By.Id("AccountFirstName"));
            IWebElement lastName = Instance.FindElement(By.Id("AccountLastName"));
            IWebElement eMail = Instance.FindElement(By.Id("AccountEmailAddress"));
            IWebElement webPhone = Instance.FindElement(By.Id("AccountHomePhoneNumber"));
            IWebElement webAddress = Instance.FindElement(By.Id("AccountAddress"));
            IWebElement webDayDOB = Instance.FindElement(By.Id("AccountDOBDay"));
            IWebElement webMonthDOB = Instance.FindElement(By.Id("AccountDOBMonth"));
            IWebElement webYearDOB = Instance.FindElement(By.Id("AccountDOBYear"));
            IWebElement webPassword = Instance.FindElement(By.Id("AccountPassword"));

            IWebElement Continuebtn = Instance.FindElement(By.Id("btnContinueDetails"));

            string custFirstName = TestData.CustomerDetails[TestData.CustomerDetailsKey.FirstName];
            string custLastName = TestData.CustomerDetails[TestData.CustomerDetailsKey.LastName];
            string custEmailId = TestData.CustomerDetails[TestData.CustomerDetailsKey.Email];
            string custPhone = TestData.CustomerDetails[TestData.CustomerDetailsKey.PhoneNumber];
            string custAddr = "UNIT 1 85 Kitchener St";
            string custDayDOB = TestData.CustomerDetails[TestData.CustomerDetailsKey.Day];
            string custMonthDOB = TestData.CustomerDetails[TestData.CustomerDetailsKey.Month];
            string custYearDOB = TestData.CustomerDetails[TestData.CustomerDetailsKey.Year];
            string custPassword = TestData.CustomerDetails[TestData.CustomerDetailsKey.Password];
            Console.WriteLine("   Password is " + TestData.CustomerDetails[TestData.CustomerDetailsKey.Password]);

            if (Continuebtn.Enabled)
            {
                webPhone.Clear();
                webPhone.SendKeys(custPhone);
                //eMail.Clear();
                //eMail.SendKeys(custEmailId);
                webAddress.Clear();
                webAddress.SendKeys(custAddr);
                Driver.Wait(TimeSpan.FromSeconds(1));
                //Select address option with suburb Coorparoo in Customer Account Address suggestions
                CheckoutPage.selectOptionWithText("COORPAROO", "Account");
                Driver.Wait(TimeSpan.FromSeconds(1));
                webDayDOB.SendKeys(custDayDOB);
                webMonthDOB.SendKeys(custMonthDOB);
                webYearDOB.SendKeys(custYearDOB);
                webPassword.SendKeys(custPassword);

                Utility.Utility.ScrollDown(Continuebtn, Instance);

                Continuebtn.Click();
                Driver.Wait(TimeSpan.FromSeconds(3));
                return true;
            }
            else { return false; }
        }

        public static bool EnterPaymentDetails_CreditCard(string ccNumber)
        {
            IWebElement CreditCardRadioButton = Instance.FindElement(
                By.XPath("//*[@id='payment']//span[@class='custom-control-description'][contains(text(), 'Credit card')]"));

            Driver.Wait(TimeSpan.FromSeconds(2));
            WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(30));
            wait.Until(ExpectedConditions.ElementToBeClickable(
                By.XPath("//*[@id='payment']//span[@class='custom-control-description'][contains(text(), 'Credit card')]")));
            CreditCardRadioButton.Click();

            IWebElement CreditCardName = Instance.FindElement(By.Id("credit_card_name"));
            IWebElement CreditCardContinueButton = Instance.FindElement(By.Id("btnContinuePaymentCreditCard"));

            string ccExpiry = TestData.CreditCardNumber[TestData.CreditCardNumbersKey.ExpiryDate];
            string ccName = TestData.CustomerDetails[TestData.CustomerDetailsKey.FirstName];

            Driver.Instance.SwitchTo().Frame(Instance.FindElement(By.Id("braintree-hosted-field-number")));
            IWebElement CreditCardNumber = Instance.FindElement(By.Id("credit-card-number"));

            CreditCardNumber.Click();
            CreditCardNumber.SendKeys(ccNumber);
            Driver.Instance.SwitchTo().DefaultContent();

            Driver.Instance.SwitchTo().Frame(Instance.FindElement(By.Id("braintree-hosted-field-expirationDate")));
            IWebElement CreditCardExpiry = Instance.FindElement(By.Id("expiration"));
            CreditCardExpiry.Click();
            CreditCardExpiry.SendKeys(ccExpiry);
            Driver.Instance.SwitchTo().DefaultContent();

            Driver.Wait(TimeSpan.FromSeconds(2));
            //CreditCardName.Click();
            CreditCardName.SendKeys(ccName);
            // If the customer selects to store his payment details click the check box

            CreditCardContinueButton.Click();
            Driver.Wait(TimeSpan.FromSeconds(2));
            /*
            try
            {
                IWebElement TicketsForMeRadioButton = Instance.FindElement(
                By.XPath("//span[contains(text(),'these tickets are for me')]"));
            }
            catch
            {
                Console.WriteLine("   Trying to click on Continue button again");
                CreditCardContinueButton.Click();
            }
            */
            Driver.Wait(TimeSpan.FromSeconds(2));
            return true;
        }

        public static void Verify_Order_Summary_Final(string subscription_selected)
        {
            try
            {
                IWebElement OrderSummary_Value_Locator = Driver.Instance.FindElement(
                    By.XPath("//span[@class='js-vip-value-per-draw']"));

                IWebElement OrderSummary_DrawTitle_Locator = Driver.Instance.FindElement(
                    By.XPath("//span[@class='js-vip-first-draw']"));

                string actualOrderSummaryValue = OrderSummary_Value_Locator.Text;
                string actualOrderSummaryDrawNumber = OrderSummary_DrawTitle_Locator.Text;

                if (actualOrderSummaryValue.Contains(subscription_selected))
                {
                    Console.WriteLine("   Order Summary showing correct subscription selected: " + subscription_selected);
                }
                else
                {
                    Console.WriteLine("   Error------. Order Summary showing incorrect subscription: " + actualOrderSummaryValue);
                }

                string expected_DrawNumber = TestData.draws_live[0];

                if (actualOrderSummaryDrawNumber.Contains(expected_DrawNumber))
                {
                    Console.WriteLine("   Order Summary showing correct draw number: " + expected_DrawNumber);
                }
                else
                {
                    Console.WriteLine("   Error-----. Order Summary showing incorrect draw number: " + actualOrderSummaryDrawNumber);
                }
            }
            catch(Exception)
            {
                Console.WriteLine("   ----Error----. Order Summary at final step is not displayed or draw number/value is not displayed within");
            }
        }

        public static void ConfirmOrder(string subscription_selected)
        {
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(120));

            IWebElement confirmOrderbtn = wait.Until(ExpectedConditions.ElementToBeClickable(By.Id("btnContinueSummary")));

            //Utility.Utility.ScrollDown(confirmOrderbtn, Instance);
            confirmOrderbtn.Click();
            IWebElement orderSuccessChk = wait.Until(ExpectedConditions.ElementIsVisible(
                By.XPath("//*[@id='confirmation']//h2[contains(text(), 'Thank you')]")));

            IWebElement confirmed_Subscription_Value_Locator = Instance.FindElement(
                By.XPath("//*[@id='confirmation']//div[@class='confirmation-tickets-list-title']"));

            string confirmedSubscriptionValue = confirmed_Subscription_Value_Locator.Text;

            if (confirmedSubscriptionValue.Contains(subscription_selected))
            {
                Console.WriteLine("   Order Summary showing correct subscription selected: " + subscription_selected);
            }
            else
            {
                Console.WriteLine("   Error----. Order Summary showing incorrect subscription: " + confirmedSubscriptionValue);
            }

        }

        //This method checks customer details in step 3 and click on Continue
        public static void Verify_CustomerContactDetails()
        {
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(10));

            //Write a new method here to Verify Customer details are correct

            IWebElement Continuebtn = Instance.FindElement(By.Id("btnContinueDetails"));
            Continuebtn.Click();
            Driver.Wait(TimeSpan.FromSeconds(5));
        }
    }

}
