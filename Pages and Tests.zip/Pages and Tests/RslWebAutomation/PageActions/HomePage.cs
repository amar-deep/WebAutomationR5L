﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using RslWebAutomation.PageActions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RslWebAutomation
{
    public class HomePage : Driver
    {

        public HomePage(IWebDriver Instance) : base(Instance)
        {


        }

        public static void GoTo()
        {
            Driver.Instance.Navigate().GoToUrl("https://web.test.aws.rslartunion.com.au/signin");


            var wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(10));
            wait.Until(d => d.SwitchTo().ActiveElement().GetAttribute("id") == "main_1_maincontainer_1_fullcolumn_0_EmailTextBox");

            //var driver = new ChromeDriver();


        }

        public static bool ClickBuyTickets()
        {
            Console.WriteLine("Clicking Buy Tickets on HomePage");
            IWebElement buyTicketbutton = Instance.FindElement(
                By.XPath("//*[@id='app-container']//div[@class='header-btn']/a[contains(@class,'btn-primary')]"));
            Utility.Utility.CheckforElementAndClick(buyTicketbutton);
            Wait(TimeSpan.FromSeconds(3));
            bool checkoutPageLoadStatus = Instance.FindElement(
                By.XPath("//*//div[@id='app-container']/main/section//div[@class='order-summary-title']")).Displayed;

            if (checkoutPageLoadStatus)
            {
                Console.WriteLine("Checkout Page loaded. Order Summary Display status is : " + checkoutPageLoadStatus);
                return true;
            }
            else
            {
                return false;
            }
        }

        public static void ClickQuickBuy()
        {
            Console.WriteLine("Clicking Buy Tickets on HomePage");
            IWebElement quickBuybutton = Instance.FindElement(
                By.XPath("//*[@id='app-container']//div[@class='header-btn']/a[contains(@class,'btn-primary')]"));
            Utility.Utility.CheckforElementAndClick(quickBuybutton);
            Wait(TimeSpan.FromSeconds(4));
            /*
            bool checkoutPageLoadStatus = Instance.FindElement(
                By.XPath("//a[contains(@href,'Checkout') and contains(text(),'Confirm')]")).Displayed;

            if (checkoutPageLoadStatus)
            {
                Console.WriteLine("Checkout Page loaded. Order Summary Display status is : " + checkoutPageLoadStatus);
                return true;
            }
            else
            {
                return false;
            }
            */
        }    

        public static bool QuickBuyConfirm()
        {
            Console.WriteLine("Clicking Buy Tickets on HomePage");
            IWebElement Confirmbutton;
            try
            {
                Confirmbutton = Instance.FindElement(
                By.XPath("//a[contains(@href,'Checkout') and contains(text(),'Confirm')]"));
            }
            catch
            {
                Confirmbutton = Instance.FindElement(
                By.XPath("//input[@class='btn btn-primary' and @value='Confirm']"));
            }            

            Utility.Utility.CheckforElementAndClick(Confirmbutton);
            Driver.Wait(TimeSpan.FromSeconds(3));
            bool checkoutPageLoadStatus = Instance.FindElement(
                By.XPath("//*//div[@id='app-container']/main/section//div[@class='order-summary-title']")).Displayed;

            if (checkoutPageLoadStatus)
            {
                Console.WriteLine("Checkout Page loaded. Order Summary Display status is : " + checkoutPageLoadStatus);
                return true;
            }
            else
            {
                return false;
            }
        }

    public static SigninCommand LoginAs(string userName, string password)
        {
            var emailInput = Driver.Instance.FindElement(By.Id("main_1_maincontainer_1_fullcolumn_0_EmailTextBox"));
            emailInput.SendKeys(userName);

            var passwordInput = Driver.Instance.FindElement(By.Id("main_1_maincontainer_1_fullcolumn_0_PasswordTextBox"));
            passwordInput.SendKeys(password);

            var loginButton = Driver.Instance.FindElement(By.Id("main_1_maincontainer_1_fullcolumn_0_LoginLinkBtn"));
            loginButton.Click();

            Driver.Instance.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(50);

            // var wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(40));
            //wait.Until(d => d.SwitchTo().ActiveElement().GetAttribute("id") == "main_0_headercontainer_0_loginbtndesktop_0_myAccountLink");

            return new SigninCommand(userName);
        }
    }

    public class SigninCommand
    {
        private readonly string userName;
        private string password;

        public SigninCommand(string userName)
        {
            this.userName = userName;
        }

        public object WithPassword(string password)
        {
            this.password = password;
            return this;
        }
    }
}
