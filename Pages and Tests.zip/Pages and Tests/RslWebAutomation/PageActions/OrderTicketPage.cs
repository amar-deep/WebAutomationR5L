﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RslWebAutomation
{
    public class OrderTicketPage
    {
        public static void Goto()
        {
            //TopNavigation.BuyTickets.GoTo();
            Driver.Instance.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(50);
            //var orderTicket = Driver.Instance.FindElement(By.XPath( ".//div[@class='buy']"));
            //orderTicket.Click();

            //System.Threading.Thread.Sleep(1000);



        }
    }
}
