﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RslWebAutomation
{
    public class OldHomePage
    {
        public static bool IsAt
        {
            get
            {
                
                var myAccountElement = Driver.Instance.FindElement(By.Id("main_0_headercontainer_0_loginbtndesktop_0_myAccountLink"));
                if (myAccountElement.Text != null )
                {
                    return true ;
                }

                return false;

            }

         }
    }
}
