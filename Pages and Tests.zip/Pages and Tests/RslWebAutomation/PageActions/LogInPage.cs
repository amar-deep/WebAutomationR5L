﻿using OpenQA.Selenium;
using System;
using System.Linq;
using OpenQA.Selenium.Support.UI;

namespace RslWebAutomation.PageActions
{
    public class LogInPage
    {
        
        public static String SignOut = "Sign out";

        // All Xpaths in this class are defined here and stored in string value
        public static String EmailXpath = "//*[@id='Username']";
        public static String PasswordXpath = "//*[@id='Password']";
        public static String SignInBtnXpath = "//input[@type='submit' and contains(@class,'js-btn-account')]";
        //public static String MyAccountBannerXpath = "//div[@class='banner-large' and contains(text(),'My Account')]";
        public static String MyAccountBannerXpath = "//div[@class='banner-large']/span[contains(text(),'My Account')]";

        public static void SignIn(string Username, string Password)
        {

            TopNavigation.SelectMenu("Login");
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(10));
            wait.Until(ExpectedConditions.ElementIsVisible(By.XPath(EmailXpath)));
            //Clear email and enter Email
            Driver.Instance.FindElement(By.XPath(EmailXpath)).Clear();
            Driver.Wait(TimeSpan.FromSeconds(1));
            Driver.Instance.FindElement(By.XPath(EmailXpath)).SendKeys(Username);
            //Clear email and enter Password                        
            Driver.Instance.FindElement(By.XPath(PasswordXpath)).Clear();
            Driver.Instance.FindElement(By.XPath(PasswordXpath)).SendKeys(Password);

            //Click on Signin button
            Driver.Instance.FindElement(By.XPath(SignInBtnXpath)).Click();
            Driver.Wait(TimeSpan.FromSeconds(3));
            Utility.Utility.WaitforPageLoad();
            Console.WriteLine("   Logged in with username {0} and password {1}", Username, Password);
            try
            {
                wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//a[contains(text(),'Hi')]")));
            }
            catch
            {
                Console.WriteLine("Login failed");
            }
            
        }

        public static void LoginFacebook()
        {
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(15));
            
            TopNavigation.SelectMenu("Login");
            Driver.Wait(TimeSpan.FromSeconds(1));
            wait.Until(ExpectedConditions.ElementIsVisible(By.Id("fbloginbutton")));
            Driver.Instance.FindElement(By.Id("fbloginbutton")).Click();
            
            //Switch windows
            Driver.Instance.SwitchTo().Window(Driver.Instance.WindowHandles.Last());
            //Driver.Instance.SwitchTo().Frame(Driver.Instance.FindElement(By.TagName("iframe")));
            Utility.Utility.WaitforPageLoad();
            Driver.Wait(TimeSpan.FromSeconds(1));


            //Clear email and enter Email
            Driver.Instance.FindElement(By.Id("email")).Clear();
            Driver.Wait(TimeSpan.FromSeconds(1));
            Driver.Instance.FindElement(By.Id("email")).SendKeys("amar.rsltest@gmail.com");

            //Clear password and enter password
            Driver.Instance.FindElement(By.Id("pass")).Clear();
            Driver.Wait(TimeSpan.FromSeconds(1));
            Driver.Instance.FindElement(By.Id("pass")).SendKeys("p@ssw0rd");

            //Click on Signin button
            Driver.Instance.FindElement(By.Name("login")).Click();
            Driver.Wait(TimeSpan.FromSeconds(5));
            Driver.Instance.SwitchTo().Window(Driver.Instance.WindowHandles.First());

            wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//a[contains(text(),'Hi')]")));            
        }

        //Keep this method for now but rewrite it if VerifyIncorrectLogin test cases are required
        public static Boolean ValidateSignIn()
        {
            //string pattern = "\\w.[[:word:]]+";
            String Fname = "Testing";
            //String Fname = TestData.CustomerDetails[TestData.CustomerDetailsKey.FirstName];

            if (!Utility.Utility.isElementPresent("//span[@class='form-validation-failed']"))
            {
                String[] GetFirstName = Driver.Instance.FindElement(
                    By.XPath("//*[@id='my-account']//p[contains(text(),'Welcome')]")).Text.Split(' ');

                if (GetFirstName[1].ToLower().Equals(Fname.ToLower()))
                {
                    Console.WriteLine(GetFirstName[0] + " " + GetFirstName[1]);
                    return true;
                }
                else
                {
                    Console.WriteLine("   Actual First name is: "+ GetFirstName[1] + " not matching with Expected name: " + Fname +" -- Please verify");
                    return false;
                }                    
            }
            else
                return false;
        }
       
    }
}
