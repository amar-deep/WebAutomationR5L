﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using RslWebAutomation.Utility;
using System.Runtime.InteropServices;
using System.Linq;
using System.Collections;

namespace RslWebAutomation.PageActions
{
    public class CheckoutPage : Driver
    {

        public CheckoutPage(IWebDriver Instance) : base(Instance)
        {

        }

        public static void ClickBuyTickets(bool is_gift = false)
        {
            if (is_gift)
            {
                IWebElement isGift_checkbox = Driver.Instance.FindElement(
               By.XPath("//div[contains(@class,'tickets-continue')]//span[@class='custom-control-indicator']"));
                Utility.Utility.CheckforElementAndClick(isGift_checkbox);
                Driver.Wait(TimeSpan.FromSeconds(3));
            }

            IWebElement buyTicketbutton = Driver.Instance.FindElement(
                By.XPath("//a[@id='btnBuyTickets']"));
            Utility.Utility.CheckforElementAndClick(buyTicketbutton);
            Driver.Wait(TimeSpan.FromSeconds(3));
        }

        public static void DeSelectTickets()
        {
            Console.WriteLine("   Deselecting all tickets");
            //Get all elements of tickets selected on page
            IList<IWebElement> listticketsselected = Driver.Instance.FindElements(
                By.XPath("//div[contains(@class, 'ticket-selector')]//a[@class='ticket selected']/div[@class='price']"));

            int orderindex = 1;
            foreach (IWebElement ticket_selected in listticketsselected)
            {
                //Get link of ticket in scroller based on draw-number and ticket to select
                try
                {
                    ticket_selected.Click();
                    Driver.Wait(TimeSpan.FromSeconds(2));
                }
                //Scroll left and right in case element is not visible
                catch (ElementNotVisibleException)
                {
                    //Scroll left first
                    try
                    {
                        //Scroll left code
                        IWebElement prevSwiper = Driver.Instance.FindElement(
                            By.XPath("//div[contains(@class, 'ticket-selector')][" + orderindex + "]//div[@class='swiper-button-prev swiper-button-white']"));
                        prevSwiper.Click();
                        Driver.Wait(TimeSpan.FromSeconds(1));
                        prevSwiper.Click();
                        Driver.Wait(TimeSpan.FromSeconds(1));
                        //Find element and click                        
                        ticket_selected.Click();
                        Driver.Wait(TimeSpan.FromSeconds(2));
                    }
                    //Scroll right if element is not visible after scrolling left
                    catch (ElementNotVisibleException)
                    {
                        //Scroll right code
                        IWebElement nextSwiper = Driver.Instance.FindElement(
                            By.XPath("//div[contains(@class, 'ticket-selector')][" + orderindex + "]//div[@class='swiper-button-next swiper-button-white']"));
                        nextSwiper.Click();
                        Driver.Wait(TimeSpan.FromSeconds(1));
                        nextSwiper.Click();
                        Driver.Wait(TimeSpan.FromSeconds(1));
                        nextSwiper.Click();
                        Driver.Wait(TimeSpan.FromSeconds(1));
                        nextSwiper.Click();
                        Driver.Wait(TimeSpan.FromSeconds(1));
                        ticket_selected.Click();
                        Driver.Wait(TimeSpan.FromSeconds(2));
                    }
                }
                orderindex++;
            }
        }

        //This method will select tickets from all draws shown on the page
        public static List<string> SelectTickets()
        {
            //Deselect tickets first
            DeSelectTickets();

            //Get all elements of different lotteries shown on page
            IList<IWebElement> list_draws_to_select_tickets = Driver.Instance.FindElements(
                By.XPath("//div[contains(@class, 'ticket-selector') and contains (@id,'draw-')]"));
            List<string> all_tickets_selected = new List<string>();
            int orderindex = 1;
            foreach (IWebElement draw in list_draws_to_select_tickets)
            {
                //Utility.Utility.ScrollDown(ticket, Instance);
                try
                {
                    //We get all links of tickets in scroller based on order-index
                    IList<IWebElement> links = Driver.Instance.FindElements(
                        By.XPath("//div[contains(@class, 'ticket-selector') and contains (@id,'draw-')][" + orderindex + "]//div[@class='price']"));


                    Console.WriteLine("   total ticket elements is:  " + links.Count);
                    decimal middle_link = (links.Count / 2) + 1;
                    int index_of_ticket_to_select = (int)(middle_link);
                    //string firstOrderStringValue = "";
                    string ticket_selected = links[index_of_ticket_to_select].Text;
                    Console.WriteLine("   Ticket selected for lottery " + orderindex + " is " + ticket_selected);
                    links[index_of_ticket_to_select].Click();
                    all_tickets_selected.Add(ticket_selected);
                }
                catch
                {
                    Console.WriteLine("   Ticket links might be missing for ticket selector at index " + orderindex);
                }
                orderindex++;
                Driver.Wait(TimeSpan.FromSeconds(2));

            }
            return all_tickets_selected;
        }

        //This method will select tickets from particular draws given as arguments
        public static List<string> SelectTickets(List<string> draw_numbers)
        {
            //Get all elements of different lotteries shown on page
            //IList<IWebElement> list_draws_to_select_tickets = new List<IWebElement>();
            List<string> all_tickets_selected = new List<string>();
            foreach (string draw_number in draw_numbers)
            {
                //IWebElement draw_element = Driver.Instance.FindElement(
                //By.XPath("//div[contains(@class, 'ticket-selector') and contains (@id,'draw-') and contains(@id,'" + draw_number + "')]"));
                //list_draws_to_select_tickets.Add(draw_element);                            

                //We get all links of tickets in scroller based on draw-number
                IList<IWebElement> links = Driver.Instance.FindElements(
                    By.XPath("//div[contains(@class, 'ticket-selector') and contains (@id,'draw-') and contains(@id,'" + draw_number + "')]//div[@class='price']"));

                Console.WriteLine("   total ticket elements is:  " + links.Count);
                decimal middle_link = (links.Count / 2) + 1;
                int index_of_ticket_to_select = (int)(middle_link);
                //string firstOrderStringValue = "";
                string ticket_selected = links[index_of_ticket_to_select].Text;
                Console.WriteLine("   Ticket selected for lottery " + draw_number + " is " + ticket_selected);
                links[index_of_ticket_to_select].Click();
                all_tickets_selected.Add(ticket_selected);

                Driver.Wait(TimeSpan.FromSeconds(2));
            }
            return all_tickets_selected;
        }



        //Trying method to 
        public static void SelectTickets(Dictionary<string, string> tickets_to_book)
        {
            //Deselect tickets first
            DeSelectTickets();

            //Gets all keys in dictionary
            Dictionary<string, string>.KeyCollection draw_numbers = tickets_to_book.Keys;

            foreach (string draw_number in draw_numbers)
            {
                //Get link of ticket in scroller based on draw-number and ticket to select
                try
                {
                    /*
                     //Commenting this as locator has changed
                    IWebElement link = Driver.Instance.FindElement(
                    By.XPath("//div[contains(@class, 'ticket-selector') and contains (@id,'draw-') and contains(@id,'" + draw_number + "')]//div[@class='price' and text()='" + tickets_to_book[draw_number] + "']"));
                    */
                    IWebElement link = Driver.Instance.FindElement(
                    By.XPath("//div[contains(@class, 'ticket-selector') and contains (@id,'draw-') and contains(@id,'" + draw_number + "')]//div[@class='price' and contains(.,'" + tickets_to_book[draw_number] + "')]"));
                    Console.WriteLine("   Ticket selected for lottery " + draw_number + " is " + tickets_to_book[draw_number]);
                    link.Click();
                    Driver.Wait(TimeSpan.FromSeconds(2));
                }
                //Scroll left and right in case element is not visible
                catch (ElementNotVisibleException)
                {
                    //Scroll left first
                    try
                    {
                        //Scroll left code
                        IWebElement prevSwiper = Driver.Instance.FindElement(
                            By.XPath("//div[contains(@class, 'ticket-selector') and contains (@id,'draw-') and contains(@id,'" + draw_number + "')]//button[@class='slick-prev slick-arrow']"));
                        prevSwiper.Click();
                        Driver.Wait(TimeSpan.FromSeconds(1));
                        prevSwiper.Click();
                        Driver.Wait(TimeSpan.FromSeconds(1));
                        //Find element and click
                        IWebElement link = Driver.Instance.FindElement(
                        By.XPath("//div[contains(@class, 'ticket-selector') and contains (@id,'draw-') and contains(@id,'" + draw_number + "')]//div[@class='price' and contains(.,'" + tickets_to_book[draw_number] + "')]"));

                        Console.WriteLine("   Ticket link found");
                        Console.WriteLine("   Ticket selected for lottery " + draw_number + " is " + tickets_to_book[draw_number]);
                        link.Click();
                        Driver.Wait(TimeSpan.FromSeconds(2));
                    }
                    //Scroll right if element is not visible after scrolling left
                    catch (ElementNotVisibleException)
                    {
                        //Scroll right code
                        IWebElement nextSwiper = Driver.Instance.FindElement(
                            By.XPath("//div[contains(@class, 'ticket-selector') and contains (@id,'draw-') and contains(@id,'" + draw_number + "')]//button[@class='slick-next slick-arrow']"));
                        nextSwiper.Click();
                        Driver.Wait(TimeSpan.FromSeconds(1));
                        nextSwiper.Click();
                        Driver.Wait(TimeSpan.FromSeconds(1));
                        nextSwiper.Click();
                        Driver.Wait(TimeSpan.FromSeconds(1));
                        nextSwiper.Click();
                        Driver.Wait(TimeSpan.FromSeconds(1));
                        //Find element and click
                        IWebElement link = Driver.Instance.FindElement(
                        By.XPath("//div[contains(@class, 'ticket-selector') and contains (@id,'draw-') and contains(@id,'" + draw_number + "')]//div[@class='price' and contains(.,'" + tickets_to_book[draw_number] + "')]"));

                        Console.WriteLine("   Ticket link found");
                        Console.WriteLine("   Ticket selected for lottery " + draw_number + " is " + tickets_to_book[draw_number]);
                        link.Click();
                        Driver.Wait(TimeSpan.FromSeconds(2));
                    }
                }
            }
        }


        public static void CalcOrderTotalValue()
        {
            // Calculate the Order Total value 
            int firstOrdervalue = Convert.ToInt32(TestData.orderDetails[TestData.OrderDetailsKey.TicketValue].Substring(1));
            int secondOrdervalue = 0;
            string secondOrder = string.Empty;
            if (TestData.secondOrderDetails.TryGetValue(TestData.OrderDetailsKey.TicketValue, out secondOrder))
            {
                secondOrdervalue = Convert.ToInt32(secondOrder.Substring(1));
            }

            int totalOrderValue = firstOrdervalue + secondOrdervalue;
            string strTotalOrderValue = "$" + totalOrderValue.ToString();
            TestData.orderDetails[TestData.OrderDetailsKey.TotalOrderValue] = strTotalOrderValue;
            TestData.secondOrderDetails[TestData.OrderDetailsKey.TotalOrderValue] = strTotalOrderValue;

            //Store the Draw number in the dictionary object
            string webFirstDrawNumber = Driver.Instance.FindElement(By.XPath("id('js-order-summary')//tr[1]/td[1]/div[@class='title']")).Text;
            string webSecondDrawNumber = Driver.Instance.FindElement(By.XPath("id('js-order-summary')//tr[2]/td[1]/div[@class='title']")).Text;

            TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber] = webFirstDrawNumber;
            TestData.secondOrderDetails[TestData.OrderDetailsKey.DrawNumber] = webSecondDrawNumber;
        }

        public static string GetFinaliseOrderTotalValue()
        {
            // Order Total Value
            IWebElement orderTotalValueElement = Instance.FindElement(
                By.XPath("//*[@id='finalise']//td[@class='order-summary-total-value']"));
            string orderTotalValue = orderTotalValueElement.Text;
            return orderTotalValue;
        }

        public static int GetOrderTotalValue()
        {
            // Order Total Value
            IWebElement orderTotalValueElement = Instance.FindElement(
                By.XPath("//*[@id='js-order-summary']//td[@class='order-summary-total-value']"));
            string orderTotalValue = orderTotalValueElement.Text;
            return Convert.ToInt32(orderTotalValue.Replace("$", ""));
        }

        public static int GetPreOrderTotalValue()
        {
            // PreOrder Total Value
            try
            {
                IWebElement orderTotalValueElement = Instance.FindElement(
                By.XPath("//*[@id='js-order-summary']//td[@class='preorder-summary-total-value']"));
                string PreorderTotalValue = orderTotalValueElement.Text;
                return Convert.ToInt32(PreorderTotalValue.Replace("$", ""));
            }
            catch (Exception)
            {
                Console.WriteLine("   ---Error---.PreOrder total not displayed but was expected ");
                return 0;
            }

        }

        // Verify Line items in order summary
        public static void Verify_Order_Summary(Dictionary<string, string> tickets_to_book, string step)
        {
            Console.WriteLine("   Verifying Order Summary at " + step);
            string parent_xpath = "";
            if (step == "step1")
                parent_xpath = "//div[@id='js-order-summary']";
            else if (step == "step4")
                parent_xpath = "//form[@id='OrderSummaryStepForm']";

            if (Verify_Order_Summary_Displayed(parent_xpath, step))
            {
                //Verify line items count first
                Verify_Line_Items_Count(tickets_to_book, parent_xpath);

                //Verify line items values
                Verify_Line_Items_Values(tickets_to_book, parent_xpath);

                //Verify total order for live draw and preorder
                Verify_Order_total(tickets_to_book, parent_xpath);
            }
        }

        public static bool Verify_Order_Summary_Displayed(string parent_xpath, string step)
        {
            int order_summary_items_count = Instance.FindElements(
                By.XPath(parent_xpath + "//tr[contains(@class, 'order-summary-item')]")).Count;
            if (order_summary_items_count > 0)
            {
                Console.WriteLine("   Order Summary is displayed at " + step);
                return true;
            }
            else
            {
                Console.WriteLine("   ---Error---. Order Summary is not displayed at " + step);
                return false;
            }
        }

        public static void Verify_Line_Items_Count(Dictionary<string, string> tickets_to_book, string parent_xpath)
        {
            int expected_line_items = tickets_to_book.Count;

            int actual_line_items = Instance.FindElements(
                By.XPath(parent_xpath + "//tr[contains(@class, 'order-summary-item') and not(contains(@class,'empty'))]")).Count;
            if (expected_line_items == actual_line_items)
                Console.WriteLine("   Number of Line items as expected");
            else
                Console.WriteLine("   Error. Number of Line items not as expected. Please verify");
        }

        public static void Verify_Line_Items_Values(Dictionary<string, string> tickets_to_book, string parent_xpath)
        {
            Dictionary<string, string>.KeyCollection draw_numbers = tickets_to_book.Keys;

            foreach (string draw_number in draw_numbers)
            {
                //Get Web Element for $ value for selected draw in order summary
                IWebElement line_item_value_link = Driver.Instance.FindElement(
                By.XPath(parent_xpath + "//tr[contains(@class, 'order-summary-item') and contains(@class,'" + draw_number + "')]/td[@class='order-summary-item-value']"));
                string line_item_value = line_item_value_link.Text;
                //Verify if line item value is as expected from dictionary input
                if (line_item_value.Replace("$", "") == tickets_to_book[draw_number])
                {
                    Console.WriteLine("   Order Summary showing correct price " + tickets_to_book[draw_number] + " for draw " + draw_number);
                }
                else
                {
                    Console.WriteLine("   Error. Order Summary showing incorrect price " + line_item_value + " for draw " + draw_number + " .Please look");
                }
            }
        }

        public static void Verify_Order_total(Dictionary<string, string> tickets_to_book, string parent_xpath)
        {
            Dictionary<string, string>.KeyCollection draw_numbers = tickets_to_book.Keys;
            int expected_order_total = 0;
            //int expected_pre_order_total = 0;            

            int actual_order_total = GetOrderTotalValue();
            //if (TestData.draws_preorder.Count > 0)
            //  actual_preorder_total = GetPreOrderTotalValue();

            foreach (string draw_number in draw_numbers)
            {
                //Get Web Element for $ value for selected draw in order summary
                IWebElement line_item_value_link = Driver.Instance.FindElement(
                By.XPath(parent_xpath + "//tr[contains(@class, 'order-summary-item') and contains(@class,'" + draw_number + "')]/td[@class='order-summary-item-value']"));
                string line_item_value = line_item_value_link.Text;

                //Add value in order_total or preorder_total based on data setup in TestData
                if (TestData.draws_live.Contains(draw_number))
                {
                    //convert value in int and add in total
                    expected_order_total = expected_order_total + Convert.ToInt32(line_item_value.Replace("$", ""));
                }
                /*
                else if (TestData.draws_preorder.Contains(draw_number))
                {
                    expected_pre_order_total = expected_pre_order_total + Convert.ToInt32(line_item_value.Replace("$", ""));
                }
                */
            }

            //Verify totals are as expected
            if (actual_order_total == expected_order_total)
            {
                Console.WriteLine("   Totals match");
            }
            else
                Console.WriteLine("   Error. Totals dont match. Please have a look");

        }







        public static bool CheckOrderValueSelection(string firstOrderInput, IWebElement firstOrderSummaryLocator)
        {
            string actualOrderSummaryValue = firstOrderSummaryLocator.Text;
            if (firstOrderInput.Equals(actualOrderSummaryValue, StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("     " + actualOrderSummaryValue + " : is shown in the order summary value");
                Console.WriteLine("     " + firstOrderInput + " : is the Expected Order summary value");
                return true;
            }
            else { return false; }
        }





        public static bool SelectCheckOutButton([Optional] bool isGift)
        {
            IWebElement checkoutButton = Driver.Instance.FindElement(By.XPath("//*[@id='js-order-summary']//a[@href='#who']"));
            IWebElement newCustomerRadioButton = Driver.Instance.FindElement(By.XPath("//*[@id='js-sign-in-select']//label[@class='custom-control custom-radio']/span[@class='custom-control-description'][contains(text(),'New customer')]"));
            IWebElement webGiftOption = Driver.Instance.FindElement(By.XPath("//*[@id='js-order-summary']//span[contains(text(), 'This purchase is a gift')]"));

            if (isGift)
            {
                webGiftOption.Click();
            }

            if (checkoutButton.Enabled && checkoutButton.Displayed)
            {
                checkoutButton.Click();
                Console.WriteLine("   Checkout button is enabled and Clicked");

            }
            if (newCustomerRadioButton.Displayed && newCustomerRadioButton.Enabled)
            { return true; }
            else { return false; }

        }

        public static void FeedNewCustomerNameAndEmail()
        {
            //IWebElement Firstname = Instance.FindElement(By.XPath("//*[@id='First-name']"));

            // IWebElement NewCustomerEmail = Instance.FindElement(By.XPath("//*[@id='Email']"));
            // IWebElement NewCustomerContinuebtn = Instance.FindElement(By.XPath("//*[@id='js-sign-in-new']//a[@href='#'][@class='btn btn-rounded btn-action-right btn-navy js-btn-next-section']"));

            IWebElement Firstname = Instance.FindElement(By.Id("WhoFirstName"));
            IWebElement LastName = Instance.FindElement(By.Id("WhoLastName"));
            IWebElement NewCustomerEmail = Instance.FindElement(By.Id("WhoEmailAddress"));
            IWebElement NewCustomerContinuebtn = Instance.FindElement(By.Id("btnContinueWhoNew"));


            Firstname.SendKeys(TestData.CustomerDetails[TestData.CustomerDetailsKey.FirstName]);
            LastName.SendKeys(TestData.CustomerDetails[TestData.CustomerDetailsKey.LastName]);
            NewCustomerEmail.SendKeys(TestData.CustomerDetails[TestData.CustomerDetailsKey.Email]);
            Console.WriteLine("   Email for new customer is " + TestData.CustomerDetails[TestData.CustomerDetailsKey.Email]);
            Driver.Wait(TimeSpan.FromSeconds(2));

            //Add data in dynamicsdata dictionary to verify later
            TestData.DynamicsData[TestData.DynamicsDataKey.firstname] = TestData.CustomerDetails[TestData.CustomerDetailsKey.FirstName];
            TestData.DynamicsData[TestData.DynamicsDataKey.lastname] = TestData.CustomerDetails[TestData.CustomerDetailsKey.LastName];
            TestData.DynamicsData[TestData.DynamicsDataKey.email] = TestData.CustomerDetails[TestData.CustomerDetailsKey.Email];

            NewCustomerContinuebtn.Click();
            Driver.Wait(TimeSpan.FromSeconds(3));
        }

        public static void Add_International_Address_Customer()
        {
            Console.WriteLine("   Adding international address for customer");
            IWebElement Not_Australian_Link = Instance.FindElement(
                By.XPath("//div[contains(@class,'form-group')]/div[4]/div/p/span[text()='Not Australian?']"));

            Not_Australian_Link.Click();

            IWebElement address = Instance.FindElement(By.Id("AccountInternationalAddress"));
            IWebElement city = Instance.FindElement(By.Id("AccountAddressCity"));
            IWebElement state = Instance.FindElement(By.Id("AccountAddressState"));
            IWebElement postcode = Instance.FindElement(By.Id("AccountAddressPostCode"));
            IWebElement country = Instance.FindElement(By.Id("AccountAddressCountry"));
            IWebElement country_to_select = Instance.FindElement(By.XPath("//select[@id='AccountAddressCountry']/option[text()='Argentina']"));

            Utility.Utility.ScrollDown(country, Instance);
            address.SendKeys("89 George Street");
            Driver.Wait(TimeSpan.FromSeconds(1));
            city.SendKeys("Hamilton");
            state.SendKeys("North");
            postcode.SendKeys("43666");
            Driver.Wait(TimeSpan.FromSeconds(1));
            country.Click();
            Driver.Wait(TimeSpan.FromSeconds(1));
            country_to_select.Click();
        }
        public static void Add_International_Address_Gift()
        {
            Console.WriteLine("   Adding international address for gift recipient");
            IWebElement Not_Australian_Link = Instance.FindElement(
                By.XPath("//div[contains(@class,'gift')]/div[4]/div/p/span[text()='Not Australian?']"));

            Not_Australian_Link.Click();

            IWebElement address = Instance.FindElement(By.Id("GiftAccountInternationalAddress"));
            IWebElement city = Instance.FindElement(By.Id("GiftAccountAddressCity"));
            IWebElement state = Instance.FindElement(By.Id("GiftAccountAddressState"));
            IWebElement postcode = Instance.FindElement(By.Id("GiftAccountAddressPostCode"));
            IWebElement country = Instance.FindElement(By.Id("GiftAccountAddressCountry"));
            IWebElement country_to_select = Instance.FindElement(By.XPath("//select[@id='GiftAccountAddressCountry']/option[text()='Argentina']"));

            Utility.Utility.ScrollDown(country, Instance);
            address.SendKeys("89 George Street");
            Driver.Wait(TimeSpan.FromSeconds(1));
            city.SendKeys("Hamilton");
            state.SendKeys("North");
            postcode.SendKeys("43666");
            Driver.Wait(TimeSpan.FromSeconds(1));
            country.Click();
            Driver.Wait(TimeSpan.FromSeconds(1));
            country_to_select.Click();
        }

        public static bool FeedExistCustomerDetails()
        {
            IWebElement selectExist = Instance.FindElement(
                By.XPath("//span[contains(text(), 'Existing customer')]"));
            IWebElement emailElement = Instance.FindElement(
                By.XPath("//*[@id='LoginEmailAddress']"));
            IWebElement passwordElement = Instance.FindElement(
                By.XPath("//*[@id='LoginPassword']"));

            string existEmail = TestData.CustomerDetails[TestData.CustomerDetailsKey.Email];
            string existPassword = TestData.CustomerDetails[TestData.CustomerDetailsKey.Password];

            Driver.Wait(TimeSpan.FromSeconds(3));
            selectExist.Click();
            emailElement.SendKeys(existEmail);
            passwordElement.SendKeys(existPassword);

            IWebElement continue_button = Instance.FindElement(
                By.XPath("//input[@id='btnContinueWhoExisting']"));
            if (continue_button.Enabled)
            {
                continue_button.Click();

                return true;
            }
            else
            {
                Console.WriteLine("   Existing customer Continue button not enabled ");
                return false;
            }
        }

        public static bool FeedExistCustomerDetails(string email, string password)
        {
            Click_ExistCustomer_CheckBox();
            IWebElement emailElement = Instance.FindElement(
                By.XPath("//*[@id='LoginEmailAddress']"));
            IWebElement passwordElement = Instance.FindElement(
                By.XPath("//*[@id='LoginPassword']"));

            Driver.Wait(TimeSpan.FromSeconds(1));
            emailElement.SendKeys(email);
            passwordElement.SendKeys(password);

            IWebElement continue_button = Instance.FindElement(
                By.XPath("//input[@id='btnContinueWhoExisting']"));
            if (continue_button.Enabled)
            {
                continue_button.Click();

                return true;
            }
            else
            {
                Console.WriteLine("   Existing customer Continue button not enabled ");
                return false;
            }
        }

        public static void Click_ExistCustomer_CheckBox()
        {
            IWebElement selectExisting = Instance.FindElement(
                By.XPath("//span[contains(text(), 'Existing customer')]"));

            Driver.Wait(TimeSpan.FromSeconds(3));
            selectExisting.Click();
        }

        public static void LoginFacebook()
        {
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(15));

            IWebElement selectExist = Instance.FindElement(
                By.XPath("//span[contains(text(), 'Existing customer')]"));
            Driver.Wait(TimeSpan.FromSeconds(1));
            selectExist.Click();
            Driver.Wait(TimeSpan.FromSeconds(1));
            wait.Until(ExpectedConditions.ElementIsVisible(By.Id("checkoutfbloginbutton")));
            Driver.Instance.FindElement(By.Id("checkoutfbloginbutton")).Click();

            //Switch windows
            Driver.Instance.SwitchTo().Window(Driver.Instance.WindowHandles.Last());
            //Driver.Instance.SwitchTo().Frame(Driver.Instance.FindElement(By.TagName("iframe")));
            Utility.Utility.WaitforPageLoad();
            Driver.Wait(TimeSpan.FromSeconds(1));


            //Clear email and enter Email
            Driver.Instance.FindElement(By.Id("email")).Clear();
            Driver.Wait(TimeSpan.FromSeconds(1));
            Driver.Instance.FindElement(By.Id("email")).SendKeys("amar.rsltest@gmail.com");

            //Clear password and enter password
            Driver.Instance.FindElement(By.Id("pass")).Clear();
            Driver.Wait(TimeSpan.FromSeconds(1));
            Driver.Instance.FindElement(By.Id("pass")).SendKeys("p@ssw0rd");

            //Click on Signin button
            Driver.Instance.FindElement(By.Name("login")).Click();

            Driver.Wait(TimeSpan.FromSeconds(5));
            Driver.Instance.SwitchTo().Window(Driver.Instance.WindowHandles.First());

            wait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(text(),'Welcome')]")));
        }

        //Delete this method when id for payment method are synched on MyAccount and CheckOut page
        public static void PaymentMethod_MyAccount_Page_Check_RadioButton_CreditCard()
        {
            IWebElement CreditCardRadioButton = Instance.FindElement(
                By.XPath("//*[@id='Payment']//span[@class='custom-control-description'][contains(text(), 'Credit card')]"));

            Driver.Wait(TimeSpan.FromSeconds(1));
            WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(30));
            wait.Until(ExpectedConditions.ElementToBeClickable(
                By.XPath("//*[@id='Payment']//span[@class='custom-control-description'][contains(text(), 'Credit card')]")));
            CreditCardRadioButton.Click();
        }

        public static void PaymentMethod_Check_RadioButton_CreditCard()
        {
            try
            {
                IWebElement CreditCardRadioButton = Instance.FindElement(
                By.XPath("//*[@id='payment']//span[@class='custom-control-description'][contains(text(), 'Credit card')]"));

                Driver.Wait(TimeSpan.FromSeconds(2));
                WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(30));
                wait.Until(ExpectedConditions.ElementToBeClickable(
                    By.XPath("//*[@id='payment']//span[@class='custom-control-description'][contains(text(), 'Credit card')]")));
                CreditCardRadioButton.Click();
            }
            catch
            {
                Console.WriteLine("   Not able to click on Credit Card Radio button as id is Payment on MyAccount page but not payment");
                Console.WriteLine("   This method will be deleted when id for payment method are synched on MyAccount and CheckOut page");
            }
        }


        public static bool EnterPaymentDetails_CreditCard
            (string ccNumber,
            bool remember_payment = false,
            string ccName = null
            )
        {
            PaymentMethod_Check_RadioButton_CreditCard();

            IWebElement CreditCardName = Instance.FindElement(By.Id("credit_card_name"));
            IWebElement RememberPayment;

            string ccExpiry = TestData.CreditCardNumber[TestData.CreditCardNumbersKey.ExpiryDate];
            if (ccName == null)
                ccName = ("Test " + TestData.CustomerDetails[TestData.CustomerDetailsKey.FirstName]);

            Driver.Instance.SwitchTo().Frame(Instance.FindElement(By.Id("braintree-hosted-field-number")));
            IWebElement CreditCardNumber = Instance.FindElement(By.Id("credit-card-number"));

            CreditCardNumber.Click();
            CreditCardNumber.SendKeys(ccNumber);
            Driver.Instance.SwitchTo().DefaultContent();

            Driver.Instance.SwitchTo().Frame(Instance.FindElement(By.Id("braintree-hosted-field-expirationDate")));
            IWebElement CreditCardExpiry = Instance.FindElement(By.Id("expiration"));
            CreditCardExpiry.Click();
            CreditCardExpiry.SendKeys(ccExpiry);
            Driver.Instance.SwitchTo().DefaultContent();

            Driver.Wait(TimeSpan.FromSeconds(1));
            //CreditCardName.Click();
            CreditCardName.SendKeys(ccName);
            // If the customer selects to store his payment details click the check box
            if (remember_payment)
            {
                RememberPayment = Instance.FindElement(By.Id("IsStoreFundingSource"));
                Console.WriteLine("   Clicking remember payment checkbox");
                RememberPayment.Click();
            }
            try
            {
                IWebElement CreditCardContinueButton = Instance.FindElement(By.Id("btnContinuePaymentCreditCard"));
                CreditCardContinueButton.Click();
                Driver.Wait(TimeSpan.FromSeconds(2));
                try
                {
                    IWebElement TicketsForMeRadioButton = Instance.FindElement(
                    By.XPath("//span[contains(text(),'these tickets are for me')]"));
                }
                catch
                {
                    Console.WriteLine("   Trying to click on Continue button again");
                    CreditCardContinueButton.Click();
                }
                Driver.Wait(TimeSpan.FromSeconds(2));
            }
            catch
            {
                Console.WriteLine("   No Continue button and gift details in update payment scenario");
            }
            return true;
        }


        public static bool StoredPaymentMethod(string aPassword, bool bSkipLogin)
        {
            IWebElement CreditCardRadioButton = Instance.FindElement(By.XPath("//*[@id='payment']//span[@class='custom-control-description'][contains(text(), 'Stored payment method')]"));


            Driver.Wait(TimeSpan.FromSeconds(5));
            WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(30));
            wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("//*[@id='payment']//span[@class='custom-control-description'][contains(text(), 'Credit card')]")));
            CreditCardRadioButton.Click();

            IWebElement passwordElement = Instance.FindElement(By.Id("StoredPaymentPassword"));
            IWebElement skipLoginElement = Instance.FindElement(By.XPath("//*[@id='payment']/div/div[3]/div[2]/div/div[1]//label[@class='custom-control custom-radio custom-radio-no-padding']"));

            IWebElement CreditCardContinueButton = Instance.FindElement(By.XPath("//*[@id='payment']//div[@class='form-group-option-detail']//a[text()='Continue']"));

            if (CreditCardRadioButton.Enabled)
            {
                // CreditCardNumber.SendKeys(ccNumber);
                //CreditCardExpiry.SendKeys(ccExpiry);
                //CreditCardName.SendKeys(ccName);
                //CreditCardContinueButton.Click();
                return true;
            }
            else { return false; }
        }

        public static void ModifyPaymentMethod()
        {
            IWebElement webModifyPayment = Instance.FindElement(By.XPath("//*[@id='payment']//a[@class='step-summary-action checkout-action']"));
            webModifyPayment.Click();

        }



        //This method adds new customer details in step 3
        public static bool FeedNewCustomerContactDetails(bool is_gift_checkout_page = false, bool is_gift_details_section = false)
        {
            IWebElement TicketsForMeRadioButton = Instance.FindElement(
                By.XPath("//*[@id='details']//span[@class='custom-control-description'][text()='No, these tickets are for me']"));
            IWebElement GiftTicketRadioButton = Instance.FindElement(
                By.XPath("//span[contains(text(),'this is a gift')]"));

            //Verify expected radio button is selected based on previous selection
            Verify_Gift_Section_On_Details_Section(is_gift_checkout_page);

            if (is_gift_checkout_page && !is_gift_details_section)
            {
                //Select 'these tickets are for me' checkbox
                TicketsForMeRadioButton.Click();
            }
            else if (!is_gift_checkout_page && is_gift_details_section)
            {
                //Select 'this is a gift' checkbox
                GiftTicketRadioButton.Click();
            }

            WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(30));

            //wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("//*[@id='details']//a[@class='btn btn-rounded btn-action-right btn-navy js-btn-finalise'][text()='Continue']")));
            wait.Until(ExpectedConditions.ElementToBeClickable(By.Id("btnContinueDetails")));

            IWebElement firstName = Instance.FindElement(By.Id("AccountFirstName"));
            IWebElement lastName = Instance.FindElement(By.Id("AccountLastName"));
            IWebElement eMail = Instance.FindElement(By.Id("AccountEmailAddress"));
            IWebElement webPhone = Instance.FindElement(By.Id("AccountHomePhoneNumber"));
            IWebElement webAddress = Instance.FindElement(By.Id("AccountAddress"));
            IWebElement webDayDOB = Instance.FindElement(By.Id("AccountDOBDay"));
            IWebElement webMonthDOB = Instance.FindElement(By.Id("AccountDOBMonth"));
            IWebElement webYearDOB = Instance.FindElement(By.Id("AccountDOBYear"));
            IWebElement webPassword = Instance.FindElement(By.Id("AccountPassword"));

            IWebElement Continuebtn = Instance.FindElement(By.Id("btnContinueDetails"));

            string custFirstName = TestData.CustomerDetails[TestData.CustomerDetailsKey.FirstName];
            string custLastName = TestData.CustomerDetails[TestData.CustomerDetailsKey.LastName];
            string custEmailId = TestData.CustomerDetails[TestData.CustomerDetailsKey.Email];
            string custPhone = TestData.CustomerDetails[TestData.CustomerDetailsKey.PhoneNumber];
            string custAddr = "85 Rue ";
            string custDayDOB = TestData.CustomerDetails[TestData.CustomerDetailsKey.Day];
            string custMonthDOB = TestData.CustomerDetails[TestData.CustomerDetailsKey.Month];
            string custYearDOB = TestData.CustomerDetails[TestData.CustomerDetailsKey.Year];
            string custPassword = TestData.CustomerDetails[TestData.CustomerDetailsKey.Password];
            Console.WriteLine("Password is " + TestData.CustomerDetails[TestData.CustomerDetailsKey.Password]);


            if (Continuebtn.Enabled)
            {
                webPhone.Clear();
                webPhone.SendKeys(custPhone);
                //eMail.Clear();
                //eMail.SendKeys(custEmailId);
                webAddress.Clear();
                webAddress.SendKeys(custAddr);
                Driver.Wait(TimeSpan.FromSeconds(1));
                //Select address option with suburb Coorparoo in Customer Account Address suggestions
                selectOptionWithText("PETRIE", "Account");
                Driver.Wait(TimeSpan.FromSeconds(1));
                webDayDOB.SendKeys(custDayDOB);
                webMonthDOB.SendKeys(custMonthDOB);
                webYearDOB.SendKeys(custYearDOB);
                webPassword.SendKeys(custPassword);


                Utility.Utility.ScrollDown(Continuebtn, Instance);

                if (is_gift_details_section)
                {
                    SelectGiftRecipientAndAddDetails();
                }

                Continuebtn.Click();
                Driver.Wait(TimeSpan.FromSeconds(3));
                return true;
            }
            else { return false; }
        }

        //This method checks customer details in step 3 and click on Continue
        public static void Verify_CustomerContactDetails(bool is_gift_checkout_page, bool is_gift_details_section)
        {
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(10));
            IWebElement TicketsForMeRadioButton = Instance.FindElement(
                By.XPath("//span[contains(text(),'these tickets are for me')]"));
            IWebElement GiftTicketRadioButton = Instance.FindElement(
                By.XPath("//span[contains(text(),'this is a gift')]"));

            //Verify expected radio button is selected based on previous selection
            Verify_Gift_Section_On_Details_Section(is_gift_checkout_page);

            if (is_gift_checkout_page && !is_gift_details_section)
            {
                //Select 'these tickets are for me' checkbox
                TicketsForMeRadioButton.Click();
            }
            else if (!is_gift_checkout_page && is_gift_details_section)
            {
                //Select 'this is a gift' checkbox
                GiftTicketRadioButton.Click();
            }

            //Write a new method here to Verify Customer details are correct
            
            //if it is a gift, Add gift recipient details
            if (is_gift_details_section)
            {
                Driver.Wait(TimeSpan.FromSeconds(2));
                SelectGiftRecipientAndAddDetails();
            }
            //click Continue button
            click_Continue_Button();
            
            //Sometime address expire before clicking on continue button, adding international address then
            int lookup_expired = Instance.FindElements(
                By.XPath("//span[contains(text(),'The address Lookup has expired')]")).Count;
            if (lookup_expired > 0)
            {
                Add_International_Address_Customer();
                Add_International_Address_Gift();

                //Click on continue button again 
                click_Continue_Button();
            }
            else
            {
                Console.WriteLine("No address lookup expiry. So, continue as it is");
            }             
        }

        public static void click_Continue_Button()
        {
            WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(10));
            IWebElement Continuebtn = Instance.FindElement(By.Id("btnContinueDetails"));
            Continuebtn.Click();
            Wait(TimeSpan.FromSeconds(10));

            try
            {
                IWebElement order_summary = wait.Until(ExpectedConditions.ElementToBeClickable(By.XPath("//div[text()='Order summary']")));
                Console.WriteLine("   Order Summary found");
                order_summary.Click();
            }
            catch (Exception)
            {
                Console.WriteLine("   Clicking on Continue again");
                IJavaScriptExecutor js = (IJavaScriptExecutor)Instance;
                //In the line below use the object identification as required
                //IWebElement hiddenGuiElement = Instance.FindElement(By.XPath(value));
                String script = "arguments[0].click();";
                js.ExecuteScript(script, Continuebtn);
                //Continuebtn.Click();
                Wait(TimeSpan.FromSeconds(10));
            }
        }


        //This method is to select address from list of options for auto address suggestions
        public static void selectOptionWithText(string suburbToSelect, string address_for)
        {
            bool address_selected = false;
            //address_for is used as their are two address suggestions Account(Customer) and Gift(Gift recipient)
            try
            {
                //Find head element for auto addresses 
                IWebElement autoOptions = Instance.FindElement(
                    By.XPath("//input[@id='" + address_for + "Address']/following-sibling::ul[contains(@id,'ui-id')]"));
                WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(15));
                Driver.Wait(TimeSpan.FromSeconds(2));
                //Store all address options with tag li in a list
                IList<IWebElement> optionsToSelect = autoOptions.FindElements(By.TagName("li"));
                //Iterate through the list unless address has Suburb name/option as argument
                foreach (IWebElement option in optionsToSelect)
                {
                    Console.WriteLine("   Address option is " + option.Text);
                    if (option.Text.Contains(suburbToSelect))
                    {
                        Console.WriteLine("   Trying to select: " + suburbToSelect);
                        option.Click();
                        address_selected = true;
                        break;
                    }
                }
            }
            //international address in exception if webelement is not found at all
            catch (NoSuchElementException)
            {
                Console.WriteLine("   Address not found or address suggestor is not working. Entering international address");
                if (address_for == "Gift")
                {
                    IWebElement giftAddress = Instance.FindElement(By.Id("GiftAddress"));
                    Console.WriteLine("   Clear address in gift address suggestor befroe entering international address");
                    giftAddress.Clear();
                    Add_International_Address_Gift();
                    address_selected = true;
                }
                else
                {
                    IWebElement customerAddress = Instance.FindElement(By.Id("AccountAddress"));
                    Console.WriteLine("   Clear address in customer address suggestor befroe entering international address");
                    customerAddress.Clear();
                    Add_International_Address_Customer();
                    address_selected = true;
                }
            }
            //international address in exception if webelement is found but address not found in options or address suggestor not working
            if (address_selected == false)
            {
                Console.WriteLine("   Address not found or address suggestor is not working. Entering international address");
                if (address_for == "Gift")
                {
                    IWebElement giftAddress = Instance.FindElement(By.Id("GiftAddress"));
                    Console.WriteLine("   Clear address in gift address suggestor befroe entering international address");
                    giftAddress.Clear();
                    Add_International_Address_Gift();
                }
                else
                {
                    IWebElement customerAddress = Instance.FindElement(By.Id("AccountAddress"));
                    Console.WriteLine("   Clear address in customer address suggestor befroe entering international address");
                    customerAddress.Clear();
                    Add_International_Address_Customer();
                }

            }
        }

        public static string GetExistingCustomerContactDetails()
        {
            IWebElement ExistingCustomerDetails = Instance.FindElement(By.XPath("//*[@id='js-details-view']//strong"));
            return ExistingCustomerDetails.Text;

        }

        public static void ModifyDetails()
        {
            IWebElement webDetails = Instance.FindElement(
                By.XPath("//*[@id='details']//a[@class='step-summary-action checkout-action']"));
            webDetails.Click();
        }


        public static void Verify_Gift_Section_On_Details_Section(bool is_gift_checkout_page)
        {
            if (is_gift_checkout_page)
            {
                //Verify that 'this is a gift fro someone' checkbox is ticked
                try
                {
                    IWebElement gift_section_form_group_detail = Instance.FindElement(
                    By.XPath("//div[contains(@class,'gift-section')]//div[@class='form-group-option-detail' and contains(@style,'block')]"));
                    Console.WriteLine("   Gift section is displayed as expected");
                }
                catch
                {
                    Console.WriteLine("   Warning: Gift section is not displayed. Please check");
                }
            }
            else
            {
                //Verify that 'No, these tickets are for me' checkbox is ticked
                try
                {
                    IWebElement gift_section_form_group_detail = Instance.FindElement(
                    By.XPath("//div[contains(@class,'gift-section')]//div[@class='form-group-option-detail' and contains(@style,'none')]"));
                    Console.WriteLine("   Gift section is not displayed as expected");
                }
                catch
                {
                    Console.WriteLine("   Warning: Gift section is not displayed. Please check");
                }
            }
        }

        public static void SelectGiftRecipientAndAddDetails()
        {
            IWebElement yesGiftElement = Instance.FindElement(
                By.XPath("//div[contains(@class,'gift-section')]//span[contains(text(),'gift')]"));
            yesGiftElement.Click();
            try
            {
                //Click on the drop-down to select gift recipient
                SelectElement selectRecipient = new SelectElement(Instance.FindElement(By.Id("GiftContactSelection")));
                selectRecipient.SelectByValue("add");
                Driver.Wait(TimeSpan.FromSeconds(1));
            }
            catch (Exception)
            {
                Console.WriteLine("-       Error----------------Dropdown in gift section not available");
            }

            //Find all elements
            IWebElement giftFirstName = Instance.FindElement(By.Id("GiftFirstName"));
            IWebElement giftLastName = Instance.FindElement(By.Id("GiftLastName"));
            IWebElement giftPhone = Instance.FindElement(By.Id("GiftHomePhoneNumber"));
            IWebElement giftEmail = Instance.FindElement(By.Id("GiftEmailAddress"));
            IWebElement giftAddress = Instance.FindElement(By.Id("GiftAddress"));
            IWebElement giftMessage = Instance.FindElement(By.Id("GiftMessage"));

            //Fill in the gift details
            giftFirstName.SendKeys(TestData.giftDetails[TestData.GiftDetailKey.FirstName]);
            giftLastName.SendKeys(TestData.giftDetails[TestData.GiftDetailKey.LastName]);
            giftPhone.SendKeys(TestData.giftDetails[TestData.GiftDetailKey.PhoneNumber]);
            giftEmail.SendKeys(TestData.giftDetails[TestData.GiftDetailKey.Email]);


            //Add Address using address suggestor
            giftAddress.SendKeys(TestData.giftDetails[TestData.GiftDetailKey.Address]);
            Driver.Wait(TimeSpan.FromSeconds(1));
            //Select address option with suburb Petrie in Customer Gift Address suggestions
            selectOptionWithText("PETRIE", "Gift");
            Driver.Wait(TimeSpan.FromSeconds(1));

            giftMessage.SendKeys(TestData.giftDetails[TestData.GiftDetailKey.Message]);
            Driver.Wait(TimeSpan.FromSeconds(2));
        }

        public static void Click_ConfirmOrder()
        {
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(120));

            try
            {
                Wait(TimeSpan.FromSeconds(6));
                //Log Time
                DateTime tim = DateTime.Now;
                Console.WriteLine("-------------------");
                Console.WriteLine("Clicking on Confirm Order at " + tim.ToString("h:mm:ss tt"));
                Console.WriteLine("-------------------");
                IWebElement confirmOrderbtn = Instance.FindElement(By.Id("btnContinueSummary"));
                confirmOrderbtn.Click();
            }
            catch
            {
                IWebElement confirmOrderbtn = wait.Until(ExpectedConditions.ElementToBeClickable(By.Id("btnContinueSummary")));
                //Utility.Utility.ScrollDown(confirmOrderbtn, Instance);
                confirmOrderbtn.Click();

                //Log Time
                DateTime tim = DateTime.Now;
                Console.WriteLine("-------------------");
                Console.WriteLine("Failed to click. Clicking on Confirm Order again at " + tim.ToString("h:mm:ss tt"));
                Console.WriteLine("-------------------");
            }
        }

        public static bool If_Order_Created_succesfully()
        {
            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(120));

            IWebElement orderSuccessChk = wait.Until(ExpectedConditions.ElementIsVisible(
                By.XPath("//*[@id='confirmation']//h2[contains(text(), 'Thank you')]")));

            //Log Time
            DateTime tim = DateTime.Now;
            Console.WriteLine("-------------------");
            Console.WriteLine("Thanks You Message displayed and Order placed at " + tim.ToString("h:mm:ss tt"));
            Console.WriteLine("-------------------");

            if (orderSuccessChk.Displayed)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static void Store_Ticket_Numbers(Dictionary<string, string> tickets_to_book)
        {
            Dictionary<string, string>.KeyCollection draw_numbers = tickets_to_book.Keys;

            foreach (string draw_number in draw_numbers)
            {
                string confirmation_tickets_list_item_xpath = "//div[contains(text(),'" + draw_number + "')]/parent::div[@class='confirmation-tickets-list-item']";
                bool confirmation_ticket_displayed = false;
                //try catch block in case ticket numbers are not displayed
                try
                {
                    IWebElement confirmation_tickets_list_item = Instance.FindElement(
                        By.XPath(confirmation_tickets_list_item_xpath));
                    //string line_item_value = line_item_value_link.Text;
                    confirmation_ticket_displayed = true;
                }
                catch
                {
                    Console.WriteLine("Confirmation message including tickets not displayed for draw " + draw_number);
                }

                //Add value in order_total or preorder_total based on data setup in TestData
                if (TestData.draws_live.Contains(draw_number))
                {
                    if (confirmation_ticket_displayed)
                    {
                        IWebElement ticketNumbers = Instance.FindElement(
                            By.XPath(confirmation_tickets_list_item_xpath + "/div[@class='confirmation-tickets-list-numbers']"));

                        TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber] = ticketNumbers.Text.Split(':')[1];
                        TestData.DynamicsData[TestData.DynamicsDataKey.tickets] = ticketNumbers.Text.Split(':')[1];
                        Console.WriteLine("   Ticket numbers for draw " + draw_number + " are " + ticketNumbers.Text.Split(':')[1]);
                    }
                    else
                    {
                        Console.WriteLine("Saving dummy values for ticket numbers as ticket numbers not displayed");
                        TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber] = "11111111";
                        TestData.DynamicsData[TestData.DynamicsDataKey.tickets] = "11111111";
                    }
                }
                else if (TestData.draws_preorder.Contains(draw_number))
                {
                    if (confirmation_ticket_displayed)
                    {
                        IWebElement ticketNumbers = Instance.FindElement(
                            By.XPath(confirmation_tickets_list_item_xpath + "/div[@class='confirmation-tickets-list-numbers']"));

                        string pre_order_ticket_message = ticketNumbers.Text;

                        if (pre_order_ticket_message.Contains("Pre-order tickets will be sent when the draw opens"))
                            Console.WriteLine("   Pre-Order tickets showing expected text message :" + pre_order_ticket_message);
                        else
                            Console.WriteLine("   -----------Error.Pre-Order tickets not showing expected text message :" + pre_order_ticket_message);
                    }
                    else
                    {
                        Console.WriteLine("Confirmation tickets preorder section not displayed");
                    }
                }
            }
        }

        //Return the VIPOrder Summary Draw start date before confirmation       
        public static string VipOrderSummaryDate()
        {
            //VIP Order Summary Draw start Date
            IWebElement orderSummaryDateElement = Instance.FindElement(By.XPath("//*[@id='finalise']//div[@class='ticket-selector-vip-start-draw-message']/strong"));
            string orderSummaryDate = orderSummaryDateElement.Text;
            return orderSummaryDate;
        }

        //Return the VIPOrder Summary Ticket value before confirmation
        public static string VipOrderSummaryValue()
        {
            //string OrderValueSelected = orderDetails["Value"];

            IWebElement orderSummaryValueElement = Instance.FindElement(By.XPath("//*[@id='finalise']//span[@class='selection']"));
            string orderSummaryValue = (orderSummaryValueElement.Text).Split(' ')[0];
            return orderSummaryValue;
        }

        //Return the message from the confirmation Page
        public static string OrderConfirmationMessage()
        {
            IWebElement orderSummaryValueElement = Instance.FindElement(
                By.XPath("//*[@id='confirmation']//div[@class='confirmation-tickets-list']"));
            string orderSummaryValue = (orderSummaryValueElement.Text);
            Console.WriteLine("   Order Summary Value is " + orderSummaryValue);

            return orderSummaryValue;
        }

        //Return the message from the confirmation Page
        public static bool OrderFailureMessageDisplayed()
        {
            try
            {
                IWebElement orderFailureMessageElement = Instance.FindElement(
                By.XPath("//div[contains(text(),'It looks like something went wrong. Please try again or contact us')]"));
                Driver.Wait(TimeSpan.FromSeconds(2));
                return true;
            }
            catch
            {
                Driver.Wait(TimeSpan.FromSeconds(2));
                return false;
            }

        }

        //Delete this method when id for payment method are synched on MyAccount and CheckOut page
        public static void PaymentMethod_MyAccount_Page_Check_RadioButton_Paypal()
        {
            //Select Paypal radio button
            Driver.Wait(TimeSpan.FromSeconds(2));
            IWebElement PaypalRadioButton = Instance.FindElement(
                By.XPath("id('Payment')//img[@alt='PayPal']"));
            WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(30));
            wait.Until(ExpectedConditions.ElementToBeClickable(PaypalRadioButton));
            PaypalRadioButton.Click();
            Driver.Wait(TimeSpan.FromSeconds(2));
        }


        public static void PaymentMethod_Check_RadioButton_Paypal()
        {
            try
            {
                //Select Paypal radio button
                Driver.Wait(TimeSpan.FromSeconds(2));
                IWebElement PaypalRadioButton = Instance.FindElement(
                    By.XPath("id('payment')//img[@alt='PayPal']"));
                WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(30));
                wait.Until(ExpectedConditions.ElementToBeClickable(PaypalRadioButton));
                PaypalRadioButton.Click();
                Driver.Wait(TimeSpan.FromSeconds(2));
            }
            catch
            {
                Console.WriteLine("   Not able to click on Credit Card Radio button as id is Payment on MyAccount page but not payment");
                Console.WriteLine("   This method will be deleted when id for payment method are synched on MyAccount and CheckOut page");
            }
        }

        public static void EnterPaymentDetails_Paypal()
        {
            WebDriverWait wait = new WebDriverWait(Instance, TimeSpan.FromSeconds(10));
            PaymentMethod_Check_RadioButton_Paypal();
            //Now click on paypal checkout button after switching to iframe as button is located within iframe                        
            IWebElement PayPalCheckoutbutton = Instance.FindElement(By.XPath("//div[@id='paypal-button']"));
            PayPalCheckoutbutton.Click();

            //Switch windows
            Driver.Instance.SwitchTo().Window(Driver.Instance.WindowHandles.Last());
            //Driver.Instance.SwitchTo().Frame(Driver.Instance.FindElement(By.TagName("iframe")));

            Utility.Utility.WaitforPageLoad();

            Driver.Wait(TimeSpan.FromSeconds(2));
            //Enter email and password
            try
            {
                IWebElement emailAddrPaypal = Instance.FindElement(By.XPath("//*[@id='email']"));
                wait.Until(ExpectedConditions.ElementToBeClickable(emailAddrPaypal));
                emailAddrPaypal.SendKeys("it.support-buyer@rslqld.org");
                FunctionLibrary.ScreenGrab("Entered Paypal email address");
            }
            catch (Exception)
            {
                Console.WriteLine("    Paypal email skipped as customer has already booked through Paypal. Ask the team---");
            }
            try
            {
                IWebElement next_button = Instance.FindElement(By.XPath("//*[@id='btnNext']"));
                next_button.Click();
                Utility.Utility.WaitforPageLoad();
            }
            catch (Exception)
            {
                Console.WriteLine("    Paypal Next button doesn't come always. so catching exception");
            }
            try
            {
                IWebElement passwordPaypal = Instance.FindElement(By.XPath("//*[@id='password']"));
                wait.Until(ExpectedConditions.ElementToBeClickable(passwordPaypal));
                passwordPaypal.SendKeys("paypaltest");
                FunctionLibrary.ScreenGrab("Entered Paypal password");
            }
            catch
            {
                Console.WriteLine("    Paypal password skipped as customer has already booked through Paypal. Ask the team---");
            }
            try
            {
                IWebElement btnLoginPaypal = Instance.FindElement(By.Id("btnLogin"));
                FunctionLibrary.ScreenGrab("Clicking Paypal login button");
                btnLoginPaypal.Click();

                Driver.Wait(TimeSpan.FromSeconds(10));
            }
            catch (Exception)
            {
                Console.WriteLine("    Login button not there as customer has already booked. Directly navigates to Agree button");
            }

            try
            {
                IWebElement agreeAndContinue_btn = Instance.FindElement(By.Id("confirmButtonTop"));
                FunctionLibrary.ScreenGrab("Clicking Paypal agree and continue button");
                agreeAndContinue_btn.Click();
            }
            catch
            {
                Console.WriteLine("   Agree And Continue button is not there");
            }

            //Switch to first window
            Driver.Wait(TimeSpan.FromSeconds(20));
            Driver.Instance.SwitchTo().Window(Driver.Instance.WindowHandles.First());
        }


        public static void PaypalPaymentMethod(bool bSavePayPalFuture, bool bContinuePaypalOnly = false)
        {
            IWebElement selectPayPalPayment = Instance.FindElement(By.XPath("id('payment')//img[@alt='PayPal']"));

            IWebElement webSavePaypalFuture = Instance.FindElement(
                By.XPath("//*[@id='payment']//span[contains(text(), 'Save PayPal details for future payments ')]"));

            IWebElement paypalContinueButton = Instance.FindElement(By.Id("btnContinuePaymentPayPal"));

            //This option is the customer logs in through Paypal 
            if (bContinuePaypalOnly)
            {
                selectPayPalPayment.Click();
                Driver.Wait(TimeSpan.FromSeconds(2));
            }

            if (bSavePayPalFuture)
            {
                webSavePaypalFuture.Click();
            }
            paypalContinueButton.Click();
        }


        public static void PayPalCheckout()
        {
            Driver.Wait(TimeSpan.FromSeconds(3));
            IWebElement PayPalCheckoutbutton = Instance.FindElement(By.Id("paypal-button"));
            PayPalCheckoutbutton.Click();

            Driver.Instance.SwitchTo().Window(Driver.Instance.WindowHandles.Last());
            Driver.Instance.SwitchTo().Frame(Driver.Instance.FindElement(By.TagName("iframe")));

            Utility.Utility.WaitforPageLoad();

            Driver.Wait(TimeSpan.FromSeconds(20));
            //Driver.Instance.SwitchTo().Window(Driver.Instance.WindowHandles.Last());
            //Driver.Instance.SwitchTo().Frame(Driver.Instance.FindElement(By.TagName("iframe")));

            //WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(15));
            //wait.Until(ExpectedConditions.ElementExists(By.Id("email")));

            IWebElement emailAddrPaypal = Instance.FindElement(By.XPath("//*[@id='email']"));
            IWebElement passwordPaypal = Instance.FindElement(By.XPath("//*[@id='password']"));

            emailAddrPaypal.SendKeys("it.support-buyer@rslqld.org");
            passwordPaypal.SendKeys("numb-YWdfw=winter89");

            IWebElement btnLoginPaypal = Instance.FindElement(By.Id("btnLogin"));
            btnLoginPaypal.Click();

            Driver.Wait(TimeSpan.FromSeconds(10));

            IWebElement btnContinuePaypal = Instance.FindElement(By.Id("confirmButtonTop"));
            btnContinuePaypal.Click();

            Driver.Wait(TimeSpan.FromSeconds(12));
            Driver.Instance.SwitchTo().Window(Driver.Instance.WindowHandles.First());
        }
        //--End of Methods
        /* All methods not used put here for now

        public static string OpenRSLHomePage()
        {
            //Instance.Navigate().GoToUrl("http://rsl:r5lprototype@preview.sapientnitro.com.au/rsl/");
            Instance.Navigate().GoToUrl("https://rslau-cd.tst.rslqld.org");
           
            Instance.FindElement(By.LinkText("Home page")).Click();
            string getHomePageTitle = Driver.Instance.Title.ToString();
            return getHomePageTitle;
        }



         * */

    }


}
