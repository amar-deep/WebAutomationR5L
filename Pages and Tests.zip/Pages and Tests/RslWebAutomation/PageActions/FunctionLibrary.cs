﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using RslWebAutomation.Utility;
using System.Runtime.InteropServices;
using System.Linq;
using System.IO;
using System.Net;
using Excel = Microsoft.Office.Interop.Excel;
using OpenQA.Selenium.Support.UI;

namespace RslWebAutomation.PageActions
{
    public class FunctionLibrary : Driver
    {

        public FunctionLibrary(IWebDriver Instance) : base(Instance)
        {

        }


        //*********************  MEthod to book tickets end to end *******************************************8

        //Buy tickets for new customers (method 1)
        public static void BuyTicktes_NewCustomer_CreditCardDeclineCodes_Verification(string pay_method, string ccName, string testname)
        {
            HomePage.ClickBuyTickets();
            ScreenGrab("random_" + ccName + "_" + testname);
            //click on checkout and tick gift checkbox based on argument
            CheckoutPage.ClickBuyTickets();
            ScreenGrab("random_" + ccName + "_" + testname);

            //Enter New Customer Name and Email and continue
            CheckoutPage.FeedNewCustomerNameAndEmail();
            ScreenGrab("random_" + ccName + "_" + testname);

            bool rem_payment = false;
            //Select Payment method Credit card and enter credit card details           
            CheckoutPage.EnterPaymentDetails_CreditCard(TestData.ReturnCreditCardNumber(pay_method), rem_payment, ccName);
            ScreenGrab("random_" + ccName + "_" + testname);

            //Enter new customer contact details           
            CheckoutPage.FeedNewCustomerContactDetails();
            ScreenGrab("random_" + ccName + "_" + testname);

            //Confirm Order
            CheckoutPage.Click_ConfirmOrder();
            ScreenGrab("random_" + ccName + "_" + testname);

        }

        //Buy tickets for new customers (method 1)
        public static void BuyTicktes_NewCustomer(Dictionary<string, string> tickets_to_book, bool is_gift_checkout_page, bool is_gift_details_section, bool remember_payment_details, string pay_method, string testname)
        {
            ScreenGrab("random_" + testname);

            HomePage.ClickBuyTickets();
            ScreenGrab("random_" + testname);

            CheckoutPage.SelectTickets(tickets_to_book);
            ScreenGrab("random_" + testname);
            // Verify line items/tickets selected in order summary at Step 1
            CheckoutPage.Verify_Order_Summary(tickets_to_book, "step1");
            //click on checkout and tick gift checkbox based on argument
            CheckoutPage.ClickBuyTickets(is_gift_checkout_page);
            ScreenGrab("random_" + testname);

            //Enter New Customer Name and Email and continue
            CheckoutPage.FeedNewCustomerNameAndEmail();
            ScreenGrab("random_" + testname);

            if (pay_method == "p")
            {
                CheckoutPage.EnterPaymentDetails_Paypal();
            }
            else
            {
                //Select Payment method Credit card and enter credit card details           
                CheckoutPage.EnterPaymentDetails_CreditCard(TestData.ReturnCreditCardNumber(pay_method), remember_payment_details);
            }
            ScreenGrab("random_" + testname);

            //Enter new customer contact details           
            CheckoutPage.FeedNewCustomerContactDetails(is_gift_checkout_page, is_gift_details_section);
            ScreenGrab("random_" + testname);

            //Order Summary validation  at step 4 before confirming order  
            CheckoutPage.Verify_Order_Summary(tickets_to_book, "step4");

            //Confirm Order
            CheckoutPage.Click_ConfirmOrder();
            bool confirmOrderStatus = CheckoutPage.If_Order_Created_succesfully();
            if (confirmOrderStatus)
                CheckoutPage.Store_Ticket_Numbers(tickets_to_book);
            ScreenGrab("random_" + testname);

            //Validate the order confirmation page
            string OrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();
            ScreenGrab("random_" + testname);

            if (is_gift_details_section)
                TestData.DynamicsData[TestData.DynamicsDataKey.is_gift] = "is_gift";
            else
                TestData.DynamicsData[TestData.DynamicsDataKey.is_gift] = "not_gift";

            TestData.DynamicsData[TestData.DynamicsDataKey.pay_method] = pay_method;

            //Save order details in excel sheet
            Write_Confirmed_Live_Order_And_Pre_Order_In_Excel_Sheet(confirmOrderStatus, tickets_to_book);
        }

        public static void Save_Dynamics_Data_Dictionary(bool is_new_cust, bool is_gift_details_section, string pay_method, bool stored_payment)
        {
            //Add data in dynamicsdata dictionary to verify later
            if (is_new_cust)
            {
                TestData.DynamicsData[TestData.DynamicsDataKey.firstname] = TestData.CustomerDetails[TestData.CustomerDetailsKey.FirstName];
                TestData.DynamicsData[TestData.DynamicsDataKey.lastname] = TestData.CustomerDetails[TestData.CustomerDetailsKey.LastName];
                TestData.DynamicsData[TestData.DynamicsDataKey.email] = TestData.CustomerDetails[TestData.CustomerDetailsKey.Email];
            }
            else
            {
                TestData.DynamicsData[TestData.DynamicsDataKey.email] = TestData.ReturnEmailAddress(pay_method, stored_payment);
            }

            if (is_gift_details_section)
                TestData.DynamicsData[TestData.DynamicsDataKey.is_gift] = "is_gift";
            else
                TestData.DynamicsData[TestData.DynamicsDataKey.is_gift] = "not_gift";

            TestData.DynamicsData[TestData.DynamicsDataKey.pay_method] = pay_method;
            TestData.DynamicsData[TestData.DynamicsDataKey.tickets] = TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber];
        }

        //Buy tickets for existing customers (method 2)
        public static void BuyTicktes_ExistingCustomer(Dictionary<string, string> tickets_to_book, bool is_gift_checkout_page, bool is_gift_details_section, bool remember_payment, bool stored_payment, string pay_method, bool log_in_first, bool already_logged_in, string testname)
        {
            //Login if not already logged in and required to login before buy tickets button click
            if (log_in_first && !already_logged_in)
            {
                //First Login from Login page
                string email = TestData.ReturnEmailAddress(pay_method, stored_payment);
                string password = "password";
                LogInPage.SignIn(email, password);
                ScreenGrab("LoggedIn__" + testname);

                TestData.DynamicsData[TestData.DynamicsDataKey.email] = email;
            }

            HomePage.ClickBuyTickets();
            ScreenGrab("ClickedBuyTicketsHomePage___" + testname);
            //It will deselect all tickets and select tickets based on argument
            CheckoutPage.SelectTickets(tickets_to_book);
            ScreenGrab("SelectTickets___" + testname);
            // Verify line items/tickets selected in order summary
            CheckoutPage.Verify_Order_Summary(tickets_to_book, "step1");

            //click on buy tickets on CheckOut page
            CheckoutPage.ClickBuyTickets(is_gift_checkout_page);
            Driver.Wait(TimeSpan.FromSeconds(3));
            ScreenGrab("ClickedBuyTicketsCheckOut___" + testname);
            //If not logged in, login as existing customer
            if (!log_in_first && !already_logged_in)
            {
                //Enter username and password on CheckOut page after selecting tickets
                string email = TestData.ReturnEmailAddress(pay_method, stored_payment);
                string password = "password";
                CheckoutPage.FeedExistCustomerDetails(email, password);
                ScreenGrab("random_" + testname);
                Driver.Wait(TimeSpan.FromSeconds(3));

                TestData.DynamicsData[TestData.DynamicsDataKey.email] = email;
            }

            //if remember details not ticked, enter credit card details and action Contact details screen
            if (!stored_payment)
            {
                if (pay_method == "p")
                {
                    CheckoutPage.EnterPaymentDetails_Paypal();
                }
                else
                {
                    //Select Payment method Credit card and enter details --Step2--          
                    CheckoutPage.EnterPaymentDetails_CreditCard(TestData.ReturnCreditCardNumber(pay_method), remember_payment);
                }
                ScreenGrab("random_" + testname);
                //After step 2, it will also go through step 3   --Step 3--         
                CheckoutPage.Verify_CustomerContactDetails(is_gift_checkout_page, is_gift_details_section);
            }
            else if (stored_payment && is_gift_checkout_page)
            {
                //if gift checkbox is ticked initially and remember payment is true   --Step 3--         
                ScreenGrab("random_" + testname);
                CheckoutPage.Verify_CustomerContactDetails(is_gift_checkout_page, is_gift_details_section);
            }

            //Order Summary validation    
            CheckoutPage.Verify_Order_Summary(tickets_to_book, "step4");
            ScreenGrab("random_" + testname);
            CheckoutPage.Click_ConfirmOrder();
            bool confirmOrderStatus = CheckoutPage.If_Order_Created_succesfully();
            if (confirmOrderStatus)
                CheckoutPage.Store_Ticket_Numbers(tickets_to_book);            

            //Validate the order confirmation page
            string OrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();
            ScreenGrab("random_" + testname);
            Driver.Wait(TimeSpan.FromSeconds(3));
            //StringAssert.Contains(OrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");

            if (is_gift_details_section)
                TestData.DynamicsData[TestData.DynamicsDataKey.is_gift] = "is_gift";
            else
                TestData.DynamicsData[TestData.DynamicsDataKey.is_gift] = "not_gift";
            TestData.DynamicsData[TestData.DynamicsDataKey.pay_method] = pay_method;

            //Save order details in excel sheet
            Write_Confirmed_Live_Order_And_Pre_Order_In_Excel_Sheet(confirmOrderStatus, tickets_to_book);
        }

        //Buy tickets for existing customers using facebook credentials (method 3)
        public static void BuyTicktes_ExistingFacebookCustomer(
            Dictionary<string, string> tickets_to_book,
            bool is_gift_checkout_page,
            bool is_gift_details_section,
            bool remember_payment,
            bool stored_payment,
            string pay_method,
            bool log_in_first,
            string testname)
        {
            //Login if not already logged in and required to login before buy tickets button click
            if (log_in_first)
            {
                //First Login from Login page                
                LogInPage.LoginFacebook();
                ScreenGrab("LoggedIn__" + testname);
            }

            HomePage.ClickBuyTickets();
            ScreenGrab("ClickedBuyTicketsHomePage___" + testname);
            //It will deselect all tickets and select tickets based on argument
            CheckoutPage.SelectTickets(tickets_to_book);
            ScreenGrab("SelectTickets___" + testname);
            // Verify line items/tickets selected in order summary
            CheckoutPage.Verify_Order_Summary(tickets_to_book, "step1");
            //click on buy tickets on CheckOut page
            CheckoutPage.ClickBuyTickets(is_gift_checkout_page);
            Driver.Wait(TimeSpan.FromSeconds(3));
            ScreenGrab("ClickedBuyTicketsCheckOut___" + testname);
            //If not logged in, login as existing customer
            if (!log_in_first)
            {
                //Enter username and password on CheckOut page after selecting tickets

                CheckoutPage.LoginFacebook();
                ScreenGrab("random_" + testname);
                Driver.Wait(TimeSpan.FromSeconds(3));
            }

            //if remember details not ticked, enter credit card details and action Contact details screen
            if (!stored_payment)
            {
                if (pay_method == "p")
                {
                    CheckoutPage.EnterPaymentDetails_Paypal();
                }
                else
                {
                    //Select Payment method Credit card and enter details --Step2--          
                    CheckoutPage.EnterPaymentDetails_CreditCard(TestData.ReturnCreditCardNumber(pay_method), remember_payment);
                }
                ScreenGrab("random_" + testname);
                //After step 2, it will also go through step 3   --Step 3--         
                CheckoutPage.Verify_CustomerContactDetails(is_gift_checkout_page, is_gift_details_section);
            }
            else if (stored_payment && is_gift_checkout_page)
            {
                //if gift checkbox is ticked initially and remember payment is true   --Step 3--         
                ScreenGrab("random_" + testname);
                CheckoutPage.Verify_CustomerContactDetails(is_gift_checkout_page, is_gift_details_section);
            }

            //Order Summary validation    
            CheckoutPage.Verify_Order_Summary(tickets_to_book, "step4");
            ScreenGrab("random_" + testname);
            CheckoutPage.Click_ConfirmOrder();
            bool confirmOrderStatus = CheckoutPage.If_Order_Created_succesfully();
            if (confirmOrderStatus)
                CheckoutPage.Store_Ticket_Numbers(tickets_to_book);

            //Validate the order confirmation page
            string OrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();
            ScreenGrab("random_" + testname);
            Driver.Wait(TimeSpan.FromSeconds(3));

            if (is_gift_details_section)
                TestData.DynamicsData[TestData.DynamicsDataKey.is_gift] = "is_gift";
            else
                TestData.DynamicsData[TestData.DynamicsDataKey.is_gift] = "not_gift";
            TestData.DynamicsData[TestData.DynamicsDataKey.email] = "amar.rsltest@gmail.com";
            TestData.DynamicsData[TestData.DynamicsDataKey.pay_method] = pay_method;

            //Save order details in excel sheet
            Write_Confirmed_Live_Order_And_Pre_Order_In_Excel_Sheet(confirmOrderStatus, tickets_to_book);

        }

        //********   Quick Buy  *************************************************

        //Buy tickets for new customers (method 1)
        public static void QuickBuy_NewCustomer(Dictionary<string, string> tickets_to_book, bool is_gift_checkout_page, bool is_gift_details_section, bool remember_payment_details, string pay_method, string testname)
        {
            ScreenGrab("random_" + testname);

            HomePage.ClickQuickBuy();
            HomePage.QuickBuyConfirm();
            ScreenGrab("random_" + testname);
            
            // Verify line items/tickets selected in order summary at Step 1
            CheckoutPage.Verify_Order_Summary(tickets_to_book, "step1");
            //click on checkout and tick gift checkbox based on argument
            CheckoutPage.ClickBuyTickets(is_gift_checkout_page);
            ScreenGrab("random_" + testname);

            //Enter New Customer Name and Email and continue
            CheckoutPage.FeedNewCustomerNameAndEmail();
            ScreenGrab("random_" + testname);

            if (pay_method == "p")
            {
                CheckoutPage.EnterPaymentDetails_Paypal();
            }
            else
            {
                //Select Payment method Credit card and enter credit card details           
                CheckoutPage.EnterPaymentDetails_CreditCard(TestData.ReturnCreditCardNumber(pay_method), remember_payment_details);
            }
            ScreenGrab("random_" + testname);

            //Enter new customer contact details           
            CheckoutPage.FeedNewCustomerContactDetails(is_gift_checkout_page, is_gift_details_section);
            ScreenGrab("random_" + testname);

            //Order Summary validation  at step 4 before confirming order  
            CheckoutPage.Verify_Order_Summary(tickets_to_book, "step4");

            //Confirm Order
            CheckoutPage.Click_ConfirmOrder();
            bool confirmOrderStatus = CheckoutPage.If_Order_Created_succesfully();
            if (confirmOrderStatus)
                CheckoutPage.Store_Ticket_Numbers(tickets_to_book);
            ScreenGrab("random_" + testname);

            //Validate the order confirmation page
            string OrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();
            ScreenGrab("random_" + testname);

            if (is_gift_details_section)
                TestData.DynamicsData[TestData.DynamicsDataKey.is_gift] = "is_gift";
            else
                TestData.DynamicsData[TestData.DynamicsDataKey.is_gift] = "not_gift";

            TestData.DynamicsData[TestData.DynamicsDataKey.pay_method] = pay_method;

            //Save order details in excel sheet
            Write_Confirmed_Live_Order_And_Pre_Order_In_Excel_Sheet(confirmOrderStatus, tickets_to_book);
        }

        //Buy tickets for existing customers (method 2)
        public static void QuickBuy_ExistingCustomer(Dictionary<string, string> tickets_to_book, bool is_gift_checkout_page, bool is_gift_details_section, bool remember_payment, bool stored_payment, string pay_method, bool log_in_first, bool already_logged_in, string testname)
        {
            //Login if not already logged in and required to login before buy tickets button click
            if (log_in_first && !already_logged_in)
            {
                //First Login from Login page
                string email = TestData.ReturnEmailAddress(pay_method, stored_payment);
                string password = "password";
                LogInPage.SignIn(email, password);
                ScreenGrab("LoggedIn__" + testname);

                TestData.DynamicsData[TestData.DynamicsDataKey.email] = email;
            }

            HomePage.ClickQuickBuy();
            HomePage.QuickBuyConfirm();
            ScreenGrab("ClickedBuyTicketsHomePage___" + testname);
            //It will deselect all tickets and select tickets based on argument
            //CheckoutPage.SelectTickets(tickets_to_book);
            ScreenGrab("SelectTickets___" + testname);
            // Verify line items/tickets selected in order summary
            CheckoutPage.Verify_Order_Summary(tickets_to_book, "step1");

            //click on buy tickets on CheckOut page
            CheckoutPage.ClickBuyTickets(is_gift_checkout_page);
            Driver.Wait(TimeSpan.FromSeconds(3));
            ScreenGrab("ClickedBuyTicketsCheckOut___" + testname);
            //If not logged in, login as existing customer
            if (!log_in_first && !already_logged_in)
            {
                //Enter username and password on CheckOut page after selecting tickets
                string email = TestData.ReturnEmailAddress(pay_method, stored_payment);
                string password = "password";
                CheckoutPage.FeedExistCustomerDetails(email, password);
                ScreenGrab("random_" + testname);
                Driver.Wait(TimeSpan.FromSeconds(3));

                TestData.DynamicsData[TestData.DynamicsDataKey.email] = email;
            }

            //if remember details not ticked, enter credit card details and action Contact details screen
            if (!stored_payment)
            {
                if (pay_method == "p")
                {
                    CheckoutPage.EnterPaymentDetails_Paypal();
                }
                else
                {
                    //Select Payment method Credit card and enter details --Step2--          
                    CheckoutPage.EnterPaymentDetails_CreditCard(TestData.ReturnCreditCardNumber(pay_method), remember_payment);
                }
                ScreenGrab("random_" + testname);
                //After step 2, it will also go through step 3   --Step 3--         
                CheckoutPage.Verify_CustomerContactDetails(is_gift_checkout_page, is_gift_details_section);
            }
            else if (stored_payment && is_gift_checkout_page)
            {
                //if gift checkbox is ticked initially and remember payment is true   --Step 3--         
                ScreenGrab("random_" + testname);
                CheckoutPage.Verify_CustomerContactDetails(is_gift_checkout_page, is_gift_details_section);
            }

            //Order Summary validation    
            CheckoutPage.Verify_Order_Summary(tickets_to_book, "step4");
            ScreenGrab("random_" + testname);
            CheckoutPage.Click_ConfirmOrder();
            bool confirmOrderStatus = CheckoutPage.If_Order_Created_succesfully();
            if (confirmOrderStatus)
                CheckoutPage.Store_Ticket_Numbers(tickets_to_book);

            //Validate the order confirmation page
            string OrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();
            ScreenGrab("random_" + testname);
            Driver.Wait(TimeSpan.FromSeconds(3));
            //StringAssert.Contains(OrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");

            if (is_gift_details_section)
                TestData.DynamicsData[TestData.DynamicsDataKey.is_gift] = "is_gift";
            else
                TestData.DynamicsData[TestData.DynamicsDataKey.is_gift] = "not_gift";
            TestData.DynamicsData[TestData.DynamicsDataKey.pay_method] = pay_method;

            //Save order details in excel sheet
            Write_Confirmed_Live_Order_And_Pre_Order_In_Excel_Sheet(confirmOrderStatus, tickets_to_book);
        }


        //Buy tickets for existing customers using facebook credentials (method 3)
        public static void QuickBuy_ExistingFacebookCustomer(
            Dictionary<string, string> tickets_to_book,
            bool is_gift_checkout_page,
            bool is_gift_details_section,
            bool remember_payment,
            bool stored_payment,
            string pay_method,
            bool log_in_first,
            string testname)
        {
            //Login if not already logged in and required to login before buy tickets button click
            if (log_in_first)
            {
                //First Login from Login page                
                LogInPage.LoginFacebook();
                ScreenGrab("LoggedIn__" + testname);
            }

            HomePage.ClickQuickBuy();
            HomePage.QuickBuyConfirm();
            ScreenGrab("ClickedBuyTicketsHomePage___" + testname);
            //It will deselect all tickets and select tickets based on argument
            CheckoutPage.SelectTickets(tickets_to_book);
            ScreenGrab("SelectTickets___" + testname);
            // Verify line items/tickets selected in order summary
            CheckoutPage.Verify_Order_Summary(tickets_to_book, "step1");
            //click on buy tickets on CheckOut page
            CheckoutPage.ClickBuyTickets(is_gift_checkout_page);
            Driver.Wait(TimeSpan.FromSeconds(3));
            ScreenGrab("ClickedBuyTicketsCheckOut___" + testname);
            //If not logged in, login as existing customer
            if (!log_in_first)
            {
                //Enter username and password on CheckOut page after selecting tickets

                CheckoutPage.LoginFacebook();
                ScreenGrab("random_" + testname);
                Driver.Wait(TimeSpan.FromSeconds(3));
            }

            //if remember details not ticked, enter credit card details and action Contact details screen
            if (!stored_payment)
            {
                if (pay_method == "p")
                {
                    CheckoutPage.EnterPaymentDetails_Paypal();
                }
                else
                {
                    //Select Payment method Credit card and enter details --Step2--          
                    CheckoutPage.EnterPaymentDetails_CreditCard(TestData.ReturnCreditCardNumber(pay_method), remember_payment);
                }
                ScreenGrab("random_" + testname);
                //After step 2, it will also go through step 3   --Step 3--         
                CheckoutPage.Verify_CustomerContactDetails(is_gift_checkout_page, is_gift_details_section);
            }
            else if (stored_payment && is_gift_checkout_page)
            {
                //if gift checkbox is ticked initially and remember payment is true   --Step 3--         
                ScreenGrab("random_" + testname);
                CheckoutPage.Verify_CustomerContactDetails(is_gift_checkout_page, is_gift_details_section);
            }

            //Order Summary validation    
            CheckoutPage.Verify_Order_Summary(tickets_to_book, "step4");
            ScreenGrab("random_" + testname);
            CheckoutPage.Click_ConfirmOrder();
            bool confirmOrderStatus = CheckoutPage.If_Order_Created_succesfully();
            if (confirmOrderStatus)
                CheckoutPage.Store_Ticket_Numbers(tickets_to_book);

            //Validate the order confirmation page
            string OrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();
            ScreenGrab("random_" + testname);
            Driver.Wait(TimeSpan.FromSeconds(3));

            if (is_gift_details_section)
                TestData.DynamicsData[TestData.DynamicsDataKey.is_gift] = "is_gift";
            else
                TestData.DynamicsData[TestData.DynamicsDataKey.is_gift] = "not_gift";
            TestData.DynamicsData[TestData.DynamicsDataKey.email] = "amar.rsltest@gmail.com";
            TestData.DynamicsData[TestData.DynamicsDataKey.pay_method] = pay_method;

            //Save order details in excel sheet
            Write_Confirmed_Live_Order_And_Pre_Order_In_Excel_Sheet(confirmOrderStatus, tickets_to_book);

        }

        //************************ End of methods to buy tickets *****************************************



        //*********************  Methods to Join VIP Club end to end *******************************************8

        //Join VIP Club for new customers (method 4)
        public static void Join_VIP_Club_NewCustomer(string subscription, string pay_method, string testname)
        {
            ScreenGrab("random_" + testname);

            JoinVIPPage.Goto_Join_VIP_Club_Page();
            ScreenGrab("random_" + testname);

            JoinVIPPage.SelectSubscription(subscription);
            //select Subscription date
            ScreenGrab("random_" + testname);
            // Verify line items/tickets selected in order summary at Step 1
            JoinVIPPage.Verify_Order_Summary(subscription);

            JoinVIPPage.Click_JoinNow();
            ScreenGrab("random_" + testname);

            //Enter New Customer Name and Email and continue
            CheckoutPage.FeedNewCustomerNameAndEmail();
            ScreenGrab("random_" + testname);

            if (pay_method == "p")
            {
                CheckoutPage.EnterPaymentDetails_Paypal();
            }
            else
            {
                //Select Payment method Credit card and enter credit card details           
                JoinVIPPage.EnterPaymentDetails_CreditCard(TestData.ReturnCreditCardNumber(pay_method));
            }
            ScreenGrab("random_" + testname);

            //Enter new customer contact details           
            JoinVIPPage.FeedNewCustomerContactDetails();
            ScreenGrab("random_" + testname);

            //Order Summary validation  at step 4 before confirming order  
            JoinVIPPage.Verify_Order_Summary_Final(subscription);

            //Confirm Order
            JoinVIPPage.ConfirmOrder(subscription);
            ScreenGrab("random_" + testname);
        }


        //Join VIP Club for existing customers (method 5)
        public static void Join_VIP_Club_ExistingCustomer(string subscription, string pay_method, bool stored_payment, string testname)
        {
            //Customer will be already logged in before this
            ScreenGrab("random_" + testname);

            JoinVIPPage.Goto_Join_VIP_Club_Page();
            ScreenGrab("random_" + testname);

            JoinVIPPage.SelectSubscription(subscription);
            //select Subscription date
            ScreenGrab("random_" + testname);
            // Verify line items/tickets selected in order summary at Step 1
            JoinVIPPage.Verify_Order_Summary(subscription);

            JoinVIPPage.Click_JoinNow();
            ScreenGrab("random_" + testname);

            //if remember details not ticked, enter credit card details and action Contact details screen
            if (!stored_payment)
            {
                if (pay_method == "p")
                {
                    CheckoutPage.EnterPaymentDetails_Paypal();
                }
                else
                {
                    //Select Payment method Credit card and enter details --Step2--          
                    JoinVIPPage.EnterPaymentDetails_CreditCard(TestData.ReturnCreditCardNumber(pay_method));
                }
                ScreenGrab("random_" + testname);
                //After step 2, it will also go through step 3   --Step 3--         
                JoinVIPPage.Verify_CustomerContactDetails();
            }
            //Order Summary validation    
            //Order Summary validation  at step 4 before confirming order  
            JoinVIPPage.Verify_Order_Summary_Final(subscription);

            //Confirm Order
            JoinVIPPage.ConfirmOrder(subscription);
            ScreenGrab("random_" + testname);
        }


        //Join VIP Club for existing customers using facebook credentials (method 6)
        public static void Join_VIP_Club_ExistingFacebookCustomer(
            Dictionary<string,
            string> tickets_to_book,
            bool is_gift_checkout_page,
            bool is_gift_details_section,
            bool remember_payment,
            bool stored_payment,
            string pay_method,
            bool log_in_first,
            string testname)
        {
            //Login if not already logged in and required to login before buy tickets button click
            if (log_in_first)
            {
                //First Login from Login page                
                LogInPage.LoginFacebook();
                ScreenGrab("LoggedIn__" + testname);
            }

            HomePage.ClickBuyTickets();
            ScreenGrab("ClickedBuyTicketsHomePage___" + testname);
            //It will deselect all tickets and select tickets based on argument
            CheckoutPage.SelectTickets(tickets_to_book);
            ScreenGrab("SelectTickets___" + testname);
            // Verify line items/tickets selected in order summary
            CheckoutPage.Verify_Order_Summary(tickets_to_book, "step1");
            //click on buy tickets on CheckOut page
            CheckoutPage.ClickBuyTickets(is_gift_checkout_page);
            Driver.Wait(TimeSpan.FromSeconds(3));
            ScreenGrab("ClickedBuyTicketsCheckOut___" + testname);
            //If not logged in, login as existing customer
            if (!log_in_first)
            {
                //Enter username and password on CheckOut page after selecting tickets

                CheckoutPage.LoginFacebook();
                ScreenGrab("random_" + testname);
                Driver.Wait(TimeSpan.FromSeconds(3));
            }

            //if remember details not ticked, enter credit card details and action Contact details screen
            if (!stored_payment)
            {
                if (pay_method == "p")
                {
                    CheckoutPage.EnterPaymentDetails_Paypal();
                }
                else
                {
                    //Select Payment method Credit card and enter details --Step2--          
                    CheckoutPage.EnterPaymentDetails_CreditCard(TestData.ReturnCreditCardNumber(pay_method), remember_payment);
                }
                ScreenGrab("random_" + testname);
                //After step 2, it will also go through step 3   --Step 3--         
                CheckoutPage.Verify_CustomerContactDetails(is_gift_checkout_page, is_gift_details_section);
            }
            else if (stored_payment && is_gift_checkout_page)
            {
                //if gift checkbox is ticked initially and remember payment is true   --Step 3--         
                ScreenGrab("random_" + testname);
                CheckoutPage.Verify_CustomerContactDetails(is_gift_checkout_page, is_gift_details_section);
            }

            //Order Summary validation    
            CheckoutPage.Verify_Order_Summary(tickets_to_book, "step4");
            ScreenGrab("random_" + testname);
            CheckoutPage.Click_ConfirmOrder();
            bool confirmOrderStatus = CheckoutPage.If_Order_Created_succesfully();
            if (confirmOrderStatus)
                CheckoutPage.Store_Ticket_Numbers(tickets_to_book);

            //Verify that a Ticket Number is allocated            
            //  Assert.IsNotNull(TestData.orderDetails[TestData.OrderDetailsKey.TicketNumber]);
            //Assert.IsNotNull(TestData.secondOrderDetails[TestData.OrderDetailsKey.TicketNumber]);

            //Validate the order confirmation page
            string OrderConfirmationMessage = CheckoutPage.OrderConfirmationMessage();
            ScreenGrab("random_" + testname);
            Driver.Wait(TimeSpan.FromSeconds(3));
            //StringAssert.Contains(OrderConfirmationMessage, TestData.orderDetails[TestData.OrderDetailsKey.DrawNumber], "The Draw number in the confirmation page is  different to what it is selected ");
        }

        //************************ End of methods to Join VIP Club *****************************************

        public static string ScreenGrab(string test)
        {
            string baseDirectory = "C:\\WebAutomationTestsScreenshots";
            string screenGrabs = Path.Combine(baseDirectory, $"{DateTime.Now:yyyy-MM-dd}");

            //Create these folders if not present
            if (!Directory.Exists(baseDirectory))
            {
                Console.WriteLine("   Creating directory");
                Directory.CreateDirectory(baseDirectory);
            }

            if (!Directory.Exists(screenGrabs))
            {
                Console.WriteLine("   Creating folder with date in directory");
                Directory.CreateDirectory(screenGrabs);
            }

            string screenshotname = Path.Combine(screenGrabs, $"{test}-{DateTime.Now:yyyy-MM-dd_hh-mm-ss-tt}.png");

            try
            {
                Screenshot ss = ((ITakesScreenshot)Instance).GetScreenshot();
                //ss.SaveAsFile(filename, System.Drawing.Imaging.ImageFormat.Png);
                ss.SaveAsFile(screenshotname, ScreenshotImageFormat.Png);
            }
            catch (Exception)
            {
                Console.WriteLine("   Error in taking screenshot");
                //We swallow the exception because we want the tests to coninue anyway. Taking a screen shot was just a nice to have.
                return string.Empty;
            }
            return screenshotname;
        }

        public static void CheckLinks(string linkURL)
        {
            HttpWebRequest re = null;
            var urls = Instance.FindElements(By.TagName("a")).Take(10);

            Console.WriteLine("   Looking at all URLs of ExecuteAutomation site :");
            //Loop through all the urls
            foreach (var url in urls)
            {
                Console.WriteLine("   URl Text is " + url.Text);
                if (!(url.Text.Contains("Email") || url.Text == ""))
                {
                    //Get the url
                    re = (HttpWebRequest)WebRequest.Create(url.GetAttribute("href"));
                    try
                    {
                        var response = (HttpWebResponse)re.GetResponse();
                        Console.WriteLine($"URL: {url.GetAttribute("href")} status is :{response.StatusCode}");
                    }
                    catch (WebException e)
                    {
                        try
                        {
                            var errorResponse = (HttpWebResponse)e.Response;
                            Console.WriteLine("   Error response is " + errorResponse);
                            Console.WriteLine($"URL: {url.GetAttribute("href")} status is :{errorResponse.StatusCode}");
                        }
                        catch (Exception)
                        {
                            Console.WriteLine("   Error response is NULL");
                        }
                    }
                }
            }
            Console.Read();
        }

        public static void Join_VIP_Club_CheckLinks()
        {
            ScreenGrab("random_");
            CheckLinks("abc");
            /*
            JoinVIPPage.Goto_Join_VIP_Club_Page();
            ScreenGrab("random_" + testname);

            JoinVIPPage.SelectSubscription(subscription);
            //select Subscription date
            ScreenGrab("random_" + testname);
            // Verify line items/tickets selected in order summary at Step 1
            JoinVIPPage.Verify_Order_Summary(subscription);

            JoinVIPPage.Click_JoinNow();
            ScreenGrab("random_" + testname);

            //Enter New Customer Name and Email and continue
            CheckoutPage.FeedNewCustomerNameAndEmail();
            ScreenGrab("random_" + testname);

            if (pay_method == "p")
            {
                CheckoutPage.EnterPaymentDetails_Paypal();
            }
            else
            {
                //Select Payment method Credit card and enter credit card details           
                JoinVIPPage.EnterPaymentDetails_CreditCard(TestData.ReturnCreditCardNumber(pay_method));
            }
            ScreenGrab("random_" + testname);

            //Enter new customer contact details           
            JoinVIPPage.FeedNewCustomerContactDetails();
            ScreenGrab("random_" + testname);

            //Order Summary validation  at step 4 before confirming order  
            JoinVIPPage.Verify_Order_Summary_Final(subscription);

            //Confirm Order
            JoinVIPPage.ConfirmOrder(subscription);
            */
            ScreenGrab("random_");
        }


        public static void Write_Content_To_Excel_File()
        {
            var FilePath = "C:\\Testing\\Web_Test_Data.xlsx";
            bool worksheetcreated = false;
            Excel.Application xlApp = new Excel.Application();
            //Open excel Workbook
            Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(FilePath);
            string sheetname = (DateTime.Now.Day.ToString() + "_" + DateTime.Now.Month.ToString());
            try
            {
                Excel.Worksheet xlWorksheet = xlWorkbook.Sheets[sheetname];
                Console.WriteLine("Opened worksheet");
                worksheetcreated = true;
            }
            catch (COMException)
            {
                Console.WriteLine("Worksheet does not exist. Creating new");

                Excel.Worksheet newWorksheet;
                newWorksheet = xlWorkbook.Worksheets.Add();
                newWorksheet.Name = sheetname;
                newWorksheet.Cells[1, 1] = "email";
                newWorksheet.Cells[1, 2] = "firstname";
                newWorksheet.Cells[1, 3] = "lastname";
                newWorksheet.Cells[1, 4] = "is_gift";
                newWorksheet.Cells[1, 5] = "pay_method";
                newWorksheet.Cells[1, 6] = "tickets";
                xlWorkbook.Save();
                worksheetcreated = true;
            }



            if (!worksheetcreated)
                Console.WriteLine("Worksheet not created or opened. So not saving data");
            else
            {
                Excel.Worksheet xlWorksheet = xlWorkbook.Sheets[sheetname];
                Excel.Range xlRange = xlWorksheet.UsedRange;
                int rowCount = xlRange.Rows.Count;
                Console.WriteLine("User Range is " + rowCount);

                //Entering values in sheet
                xlWorksheet.Cells[(rowCount + 1), "A"] = TestData.DynamicsData[TestData.DynamicsDataKey.email];
                xlWorksheet.Cells[(rowCount + 1), "D"] = TestData.DynamicsData[TestData.DynamicsDataKey.is_gift];
                xlWorksheet.Cells[(rowCount + 1), "E"] = TestData.DynamicsData[TestData.DynamicsDataKey.pay_method];
                xlWorksheet.Cells[(rowCount + 1), "F"] = TestData.DynamicsData[TestData.DynamicsDataKey.tickets];

                xlWorkbook.Save();
                //May10 shared the excel document, so that multiple test cases can update the spreadsheet when tests are executed in parallel
                //Release com objects to fully kill excel process from running in the background. 
                //If we don't do this, then excel sheet might endup in readonly mode for a different test trying to access the same spreadsheet
                Marshal.ReleaseComObject(xlRange);
                Marshal.ReleaseComObject(xlWorksheet);

                xlWorkbook.Close();
                Marshal.ReleaseComObject(xlWorkbook);

                //quit and release
                xlApp.Quit();
                Marshal.ReleaseComObject(xlApp);
            }

        }

        public static void Write_Content_To_Excel_File_For_Preorder()
        {
            var FilePath = "C:\\Testing\\Web_Test_Data.xlsx";
            bool worksheetcreated = false;
            Excel.Application xlApp = new Excel.Application();
            //Open excel Workbook
            Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(FilePath);
            string sheetname = (DateTime.Now.Day.ToString() + "_" + DateTime.Now.Month.ToString() + "_pre");
            try
            {
                Excel.Worksheet xlWorksheet = xlWorkbook.Sheets[sheetname];
                Console.WriteLine("Opened worksheet");
                worksheetcreated = true;
            }
            catch (COMException)
            {
                Console.WriteLine("Worksheet does not exist for preorder. Creating new");

                Excel.Worksheet newWorksheet;
                newWorksheet = xlWorkbook.Worksheets.Add();
                newWorksheet.Name = sheetname;
                newWorksheet.Cells[1, 1] = "email";
                newWorksheet.Cells[1, 2] = "firstname";
                newWorksheet.Cells[1, 3] = "lastname";
                newWorksheet.Cells[1, 4] = "is_gift";
                newWorksheet.Cells[1, 5] = "pay_method";
                newWorksheet.Cells[1, 6] = "tickets";
                xlWorkbook.Save();
                worksheetcreated = true;
            }



            if (!worksheetcreated)
                Console.WriteLine("Worksheet not created or opened. So not saving data");
            else
            {
                Excel.Worksheet xlWorksheet = xlWorkbook.Sheets[sheetname];
                Excel.Range xlRange = xlWorksheet.UsedRange;
                int rowCount = xlRange.Rows.Count;
                Console.WriteLine("User Range is " + rowCount);

                //Entering values in sheet
                xlWorksheet.Cells[(rowCount + 1), "A"] = TestData.DynamicsData[TestData.DynamicsDataKey.email];
                xlWorksheet.Cells[(rowCount + 1), "D"] = TestData.DynamicsData[TestData.DynamicsDataKey.is_gift];
                xlWorksheet.Cells[(rowCount + 1), "E"] = TestData.DynamicsData[TestData.DynamicsDataKey.pay_method];
                xlWorksheet.Cells[(rowCount + 1), "F"] = "preorder";

                xlWorkbook.Save();
                //May10 shared the excel document, so that multiple test cases can update the spreadsheet when tests are executed in parallel
                //Release com objects to fully kill excel process from running in the background. 
                //If we don't do this, then excel sheet might endup in readonly mode for a different test trying to access the same spreadsheet
                Marshal.ReleaseComObject(xlRange);
                Marshal.ReleaseComObject(xlWorksheet);

                xlWorkbook.Close();
                Marshal.ReleaseComObject(xlWorkbook);

                //quit and release
                xlApp.Quit();
                Marshal.ReleaseComObject(xlApp);
            }

        }

        public static void Write_Confirmed_Live_Order_And_Pre_Order_In_Excel_Sheet(bool confirmOrderStatus, Dictionary<string, string> tickets_to_book)
        {
            //Save order details in excel sheet
            try
            {
                if (confirmOrderStatus && (tickets_to_book.ContainsKey(TestData.draws_live[0])))
                    Write_Content_To_Excel_File();
            }
            catch
            {
                Console.WriteLine("Some error came while saving live order data in excel");
            }

            try
            {
                if (confirmOrderStatus && (tickets_to_book.ContainsKey(TestData.draws_live[1])))
                    Write_Content_To_Excel_File();
            }
            catch
            {
                Console.WriteLine("Second draw does not exist.");
            }
            try
            {
                if (confirmOrderStatus && tickets_to_book.ContainsKey(TestData.draws_preorder[0]))
                    Write_Content_To_Excel_File_For_Preorder();
            }
            catch
            {
                Console.WriteLine("Some error came while saving pre order data in excel");
            }
        }

        /*  */
        public static void Read_Content_From_Excel_File()
        {
            var FilePath = "C:\\Testing\\Web_Test_Data.xlsx";
            Excel.Application xlApp = new Excel.Application();
            try
            {
                Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(FilePath);
                Excel._Worksheet xlWorksheet = xlWorkbook.Sheets["1508"];
                //Excel._Worksheet xlWorksheet = xlApp.ActiveSheet;
                Excel.Range xlRange = xlWorksheet.UsedRange;
                int rowCount = xlRange.Rows.Count;
                Console.WriteLine("Iterate through all rows");
                for (int i = 2; i <= rowCount; i++)
                {
                    TestData.RetrieveExcelData[TestData.RetrieveExcelDataKey.email] = xlWorksheet.Cells[i, 1].Text;
                    Console.WriteLine("Email value is " + TestData.RetrieveExcelData[TestData.RetrieveExcelDataKey.email]);
                }
                Marshal.ReleaseComObject(xlRange);
                Marshal.ReleaseComObject(xlWorksheet);

                xlWorkbook.Close();
                Marshal.ReleaseComObject(xlWorkbook);

                //quit and release
                xlApp.Quit();
                Marshal.ReleaseComObject(xlApp);
                //Console.WriteLine("   Excel content is: " +cell_content); 
            }
            catch
            {
                //quit and release
                Console.WriteLine("Closing excel in case of any error in between");
                xlApp.Quit();
                Marshal.ReleaseComObject(xlApp);
                //Console.WriteLine("   Excel content is: " +cell_content); 

            }
        }

        public static void Wait_For_Page_Load_To_Complete()
        {

            WebDriverWait wait = new WebDriverWait(Driver.Instance, TimeSpan.FromSeconds(60));
            wait.Until((x) =>
            {
                return ((IJavaScriptExecutor)Driver.Instance).ExecuteScript("return document.readyState").Equals("complete");
            });
        }

        public static void WaitForAjaxComplete(int maxSeconds)
        {
            bool is_ajax_compete = false;
            for (int i = 1; i <= maxSeconds; i++)
            {
                is_ajax_compete = (bool)((IJavaScriptExecutor)Instance).ExecuteScript("return jQuery.active == 0");
                if (is_ajax_compete)
                {
                    return;
                }
                System.Threading.Thread.Sleep(2000);
            }
            Console.WriteLine("Waited for Ajax loading to finish");
            throw new Exception("Timed out waiting for AJAX call after " + maxSeconds + " seconds");
        }

        public static bool IsElementPresent(By by)
        {
            try
            {
                Instance.FindElement(by);

                return true;
            }
            catch (NoSuchElementException)
            {
                return false;
            }
        }
    }


}
