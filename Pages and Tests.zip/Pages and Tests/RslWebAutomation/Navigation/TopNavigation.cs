﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System.Threading;

namespace RslWebAutomation
{
    public class TopNavigation
    {

        public static void SelectSubMenu(string Menu, string subMenu)
        {

            if (Menu == "VIPClub")
                Menu = "VIPClub";
            else if (Menu == "AboutUs")
                Menu = "AboutUs";
            else if (Menu == "MyAccount")
                Menu = "myaccount";

            if (subMenu == "JoinVIPClub")
                subMenu = "Join-VIP-Club";
            else if (subMenu == "DrawWinner")
                subMenu = "Draw-Winner";

            Thread.Sleep(500);
            Actions action = new Actions(Driver.Instance);

            if (Menu == "Hi" && subMenu == "Your Details")
            {
                var menu_element = Driver.Instance.FindElement(By.XPath("//*[@class='addon-menu']//a[contains(text(),'" + Menu + "')]"));
                action.MoveToElement(menu_element).Build().Perform();
                Thread.Sleep(1000);

                var subMenu_element = Driver.Instance.FindElement(By.XPath("//*[@class='addon-menu']//a[contains(text(),'" + subMenu + "')]"));
                subMenu_element.Click();

                Driver.Instance.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(20);
            }
            else
            {
                var menu_element = Driver.Instance.FindElement(By.XPath("//*[@class='primary-menu']//a[@href='/" + Menu + "']"));
                action.MoveToElement(menu_element).Build().Perform();
                Thread.Sleep(1000);

                var subMenu_element = Driver.Instance.FindElement(By.XPath("//*[@class='primary-menu']//a[@href='/" + Menu + "/" + subMenu + "']"));
                subMenu_element.Click();

                Driver.Instance.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(20);
            }

        }

        public static void SelectMenu(string Menu)
        {
            if (Menu == "MyAccount")
                Menu = "myaccount";

            var menu_element = Driver.Instance.FindElement(
                By.XPath("//*[@class='primary-menu']//a[@href='/" + Menu + "']"));
            menu_element.Click();

            Driver.Instance.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(20);
            Driver.Wait(TimeSpan.FromSeconds(2));
        }
    }

}
