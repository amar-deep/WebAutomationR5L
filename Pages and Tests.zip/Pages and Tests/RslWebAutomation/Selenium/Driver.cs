﻿//using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;

namespace RslWebAutomation
{
    public class Driver
    {
        public static IWebDriver Instance { get; set; }
        public static string BaseUrl
        {
            get { return "https://rslau-cd.stg.rslqld.org"; }            
            
        }

        public Driver(IWebDriver Instance)
        {
            Driver.Instance = Instance;
        }


        public static void Initialize()
        {
            Instance = new ChromeDriver();
            Instance.Manage().Window.Maximize();
            Instance.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            Instance.Navigate().GoToUrl(BaseUrl);
        }

        public static void Wait(TimeSpan timeSpan)
        {
            System.Threading.Thread.Sleep((int)(timeSpan.TotalSeconds * 1000));
        }

        public static void Close()
        {
            Instance.Close();
            Driver.Wait(TimeSpan.FromSeconds(3));
            Instance.Quit();
        }
    }
}