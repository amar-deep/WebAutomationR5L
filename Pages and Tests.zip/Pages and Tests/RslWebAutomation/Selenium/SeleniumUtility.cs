﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support;

namespace RslWebAutomation
{
    public abstract class SeleniumUtility
    {

        protected IWebDriver driver = null;

        public SeleniumUtility(IWebDriver driver)
        {
            this.driver = driver;
        }

        protected IWebElement findElementByAnyLocator(String elementlocator)
        {
            if (elementlocator.StartsWith("xpath"))
            {
                return driver.FindElement(By.XPath(elementlocator.Replace("xpath_", "")));
            }
            else if (elementlocator.StartsWith("css"))
            {
                return driver.FindElement(By.CssSelector(elementlocator.Replace("css_", "")));
            }
            else if (elementlocator.StartsWith("linktext"))
            {
                return driver.FindElement(By.LinkText(elementlocator.Replace("linktext_", "")));
            }
            else if (elementlocator.StartsWith("partiallinktext"))
            {
                return driver.FindElement(By.PartialLinkText(elementlocator.Replace("partiallinktext_", "")));
            }
            else if (elementlocator.StartsWith("id"))
            {
                return driver.FindElement(By.Id(elementlocator.Replace("id_", "")));
            }
            else if (elementlocator.StartsWith("name"))
            {
                return driver.FindElement(By.Name(elementlocator.Replace("name_", "")));
            }
            else if (elementlocator.StartsWith("class"))
            {
                return driver.FindElement(By.ClassName(elementlocator.Replace("class_", "")));
            }
            else if (elementlocator.StartsWith("tagname"))
            {
                return driver.FindElement(By.TagName(elementlocator.Replace("tagname_", "")));
            }
            else
            {
                return null;
            }
        }


    }
}
